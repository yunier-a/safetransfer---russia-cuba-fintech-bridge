
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Layout } from '../components/Layout';
import { getBotResponse } from '../services/geminiService';
import { NotificationService } from '../services/notificationService';

const FAQ_TOPICS = [
  { q: "¿Cuánto demoran las remesas?", a: "Las transferencias locales suelen ser instantáneas, mientras que las internacionales pueden tomar de 2 a 24 horas dependiendo del nodo receptor." },
  { q: "¿Es seguro depositar con QvaPay?", a: "Sí, QvaPay actúa como nuestro nodo maestro de liquidación con cifrado de grado militar y fondos respaldados 1:1." },
  { q: "¿Cómo recupero el acceso si pierdo mi token?", a: "Debes contactar al administrador con tu ID de operador para iniciar el protocolo de recuperación biométrica." },
  { q: "¿Puedo cancelar un intercambio?", a: "Una vez autorizada la liquidación en el bridge, la operación es irreversible debido a la naturaleza de los protocolos blockchain y bancarios." }
];

const Support: React.FC = () => {
  const navigate = useNavigate();
  const [activeView, setActiveView] = useState<'MAIN' | 'FAQ' | 'REPORT'>('MAIN');
  const [searchQuery, setSearchQuery] = useState('');
  const [aiAnswer, setAiAnswer] = useState<string | null>(null);
  const [isAskingAi, setIsAskingAi] = useState(false);
  const [reportText, setReportText] = useState('');
  const [isReporting, setIsReporting] = useState(false);

  const handleAiSearch = async () => {
    if (!searchQuery.trim()) return;
    setIsAskingAi(true);
    setAiAnswer(null);
    const response = await getBotResponse(`Actúa como agente de soporte técnico de SafeTransfer. El usuario tiene esta duda: ${searchQuery}. Responde de forma concisa y profesional.`);
    setAiAnswer(response.text);
    setIsAskingAi(false);
  };

  const handleReportProblem = async () => {
    if (!reportText.trim()) return;
    setIsReporting(true);
    const result = await NotificationService.notifyAdmin('TECHNICAL_ISSUE_REPORT', {
      details: reportText,
      recipient: 'Technical Core Team'
    });
    window.open(result.whatsappLink, '_blank');
    setIsReporting(false);
    setReportText('');
    setActiveView('MAIN');
  };

  const supportOptions = [
    { title: 'Centro de Ayuda', desc: 'Preguntas frecuentes e IA.', icon: 'help_center', action: () => setActiveView('FAQ') },
    { title: 'Chat en Vivo', desc: 'Habla con SafeNeural Support.', icon: 'forum', action: () => navigate('/bot', { state: { initialPrompt: 'Necesito asistencia técnica con mi cuenta.' } }) },
    { title: 'Reportar Problema', desc: 'Envía un ticket técnico.', icon: 'bug_report', action: () => setActiveView('REPORT') },
    { title: 'Contacto Directo', desc: 'WhatsApp y Redes.', icon: 'alternate_email', action: () => {
      const msg = "Hola, soy un operador de SafeTransfer y necesito asistencia directa.";
      window.open(`https://wa.me/16892564329?text=${encodeURIComponent(msg)}`, '_blank');
    }}
  ];

  return (
    <Layout hideNav>
      <header className="px-4 py-8 glass-header sticky top-0 z-50 flex items-center justify-between">
        <button 
          onClick={() => activeView === 'MAIN' ? navigate(-1) : setActiveView('MAIN')} 
          className="size-11 flex items-center justify-center rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-500 shadow-sm active:scale-90 transition-all"
        >
          <span className="material-symbols-outlined text-[20px]">
            {activeView === 'MAIN' ? 'arrow_back_ios_new' : 'close'}
          </span>
        </button>
        <div className="text-center flex-1">
          <h2 className="text-[10px] font-black text-slate-900 dark:text-white uppercase tracking-widest italic">
            {activeView === 'MAIN' ? 'Centro de Soporte' : activeView === 'FAQ' ? 'Base de Conocimiento' : 'Reportar Incidencia'}
          </h2>
          <p className="text-[8px] font-black text-primary uppercase tracking-[0.2em] mt-0.5">Asistencia al Operador</p>
        </div>
        <div className="size-11"></div>
      </header>

      <main className="p-6 space-y-8 pb-32 animate-in fade-in duration-300">
        {activeView === 'MAIN' && (
          <>
            <div className="bg-primary/5 border border-primary/20 rounded-[2.5rem] p-8 text-center space-y-4 shadow-inner">
              <div className="size-16 bg-primary/10 rounded-3xl flex items-center justify-center mx-auto text-primary border border-primary/20 shadow-lg">
                <span className="material-symbols-outlined text-3xl font-black">support_agent</span>
              </div>
              <div className="space-y-1">
                <h3 className="text-lg font-black text-slate-900 dark:text-white uppercase italic tracking-tighter">¿Cómo podemos ayudarte?</h3>
                <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest leading-relaxed px-4">
                  Soporte garantizado 24/7 para el corredor Rusia-Cuba.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4">
              {supportOptions.map((opt, i) => (
                <button key={i} onClick={opt.action} className="bg-white dark:bg-app-card-dark border border-slate-200 dark:border-white/5 p-6 rounded-3xl flex items-center gap-5 active:scale-[0.98] transition-all hover:border-primary/30 group shadow-sm">
                  <div className="size-14 rounded-2xl bg-slate-50 dark:bg-slate-900 flex items-center justify-center text-slate-400 group-hover:text-primary transition-colors border border-slate-100 dark:border-white/5">
                    <span className="material-symbols-outlined text-2xl font-black">{opt.icon}</span>
                  </div>
                  <div className="text-left flex-1">
                    <h4 className="text-sm font-black text-slate-900 dark:text-white uppercase tracking-tight">{opt.title}</h4>
                    <p className="text-[10px] text-slate-500 font-medium uppercase mt-0.5">{opt.desc}</p>
                  </div>
                  <span className="material-symbols-outlined text-slate-300 group-hover:text-primary transition-all">chevron_right</span>
                </button>
              ))}
            </div>
          </>
        )}

        {activeView === 'FAQ' && (
          <div className="space-y-6 animate-in slide-in-from-bottom-4">
            <div className="relative">
              <input 
                type="text" 
                className="w-full bg-slate-100 dark:bg-slate-900 border-none rounded-2xl py-5 px-6 pr-14 text-sm font-bold text-slate-900 dark:text-white placeholder:text-slate-400"
                placeholder="Pregunta a la IA de Soporte..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAiSearch()}
              />
              <button 
                onClick={handleAiSearch}
                disabled={isAskingAi}
                className="absolute right-2 top-1/2 -translate-y-1/2 size-11 bg-primary text-white rounded-xl flex items-center justify-center shadow-lg active:scale-90 disabled:opacity-50"
              >
                {isAskingAi ? <span className="size-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></span> : <span className="material-symbols-outlined font-black">auto_awesome</span>}
              </button>
            </div>

            {aiAnswer && (
              <div className="bg-primary/5 border border-primary/20 p-6 rounded-[2rem] animate-in zoom-in">
                 <p className="text-[10px] font-black text-primary uppercase tracking-widest mb-3 flex items-center gap-2">
                   <span className="material-symbols-outlined text-sm">psychology</span> Respuesta de IA
                 </p>
                 <p className="text-xs text-slate-600 dark:text-slate-300 font-medium leading-relaxed italic">"{aiAnswer}"</p>
              </div>
            )}

            <div className="space-y-4">
              <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-4">Temas Comunes</h3>
              {FAQ_TOPICS.map((topic, i) => (
                <details key={i} className="group bg-white dark:bg-app-card-dark border border-slate-200 dark:border-white/5 rounded-2xl overflow-hidden">
                  <summary className="list-none p-5 flex justify-between items-center cursor-pointer">
                    <span className="text-xs font-black text-slate-800 dark:text-white uppercase tracking-tight">{topic.q}</span>
                    <span className="material-symbols-outlined text-slate-400 group-open:rotate-180 transition-transform">expand_more</span>
                  </summary>
                  <div className="px-5 pb-5">
                    <p className="text-[11px] text-slate-500 font-medium leading-relaxed">{topic.a}</p>
                  </div>
                </details>
              ))}
            </div>
          </div>
        )}

        {activeView === 'REPORT' && (
          <div className="space-y-6 animate-in slide-in-from-bottom-4">
             <div className="bg-amber-500/5 border border-amber-500/10 p-6 rounded-2xl flex items-start gap-4">
                <span className="material-symbols-outlined text-amber-500">warning</span>
                <p className="text-[10px] text-slate-500 font-bold uppercase tracking-tight leading-relaxed">
                  Los reportes técnicos son revisados por el equipo de seguridad de nivel 5. Proporciona detalles precisos.
                </p>
             </div>
             
             <div className="space-y-4">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-4">Detalle del Incidente</label>
                <textarea 
                  className="w-full h-40 bg-slate-100 dark:bg-slate-900 border-none rounded-3xl p-6 text-sm text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary/20 transition-all resize-none"
                  placeholder="Describe qué sucedió, cuándo y si hay algún ID de transacción involucrado..."
                  value={reportText}
                  onChange={(e) => setReportText(e.target.value)}
                ></textarea>
                <button 
                  onClick={handleReportProblem}
                  disabled={!reportText.trim() || isReporting}
                  className="w-full py-5 bg-primary text-white rounded-2xl text-[11px] font-black uppercase tracking-[0.2em] shadow-lg active:scale-95 disabled:opacity-30 transition-all flex items-center justify-center gap-3"
                >
                  {isReporting ? <span className="size-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span> : <>Generar Ticket Directo <span className="material-symbols-outlined text-sm">confirmation_number</span></>}
                </button>
             </div>
          </div>
        )}

        <section className="bg-slate-950 rounded-[2rem] p-8 border border-white/5 text-center space-y-4">
           <p className="text-[8px] font-black text-slate-600 uppercase tracking-[0.4em]">Protocolo de Respuesta Garantizado</p>
           <p className="text-[11px] text-slate-400 leading-relaxed font-medium">
             Toda consulta técnica es procesada en menos de <span className="text-primary font-black">15 minutos</span> por nuestros nodos de atención especializada.
           </p>
        </section>
      </main>
    </Layout>
  );
};

export default Support;
