
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Layout } from '../components/Layout';
import { WebhookService } from '../services/webhookService';
import { supabase } from '../services/supabase';

const MASTER_ACCESS_TOKEN = "ST-99-PRO";

const AdminNode: React.FC = () => {
  const navigate = useNavigate();
  const [logs, setLogs] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<'AUDIT' | 'SIMULATOR'>('AUDIT');
  const [statusMsg, setStatusMsg] = useState('');
  const [isAuthorized, setIsAuthorized] = useState(false);
  
  const [accessToken, setAccessToken] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);

  useEffect(() => {
    if (isAuthorized) fetchData();
  }, [isAuthorized]);

  const fetchData = async () => {
    const { data: webhookLogs } = await supabase
      .from('webhook_logs')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(15);
    if (webhookLogs) setLogs(webhookLogs);
  };

  const handleIdentityHandshake = async () => {
    setIsVerifying(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    if (accessToken === MASTER_ACCESS_TOKEN) {
      setIsAuthorized(true);
    } else {
      alert("TOKEN INVÁLIDO: No tienes autorización para acceder a los controles maestros.");
    }
    setIsVerifying(false);
  };

  const simulateDirectDeposit = async () => {
    setStatusMsg('Simulando señal de depósito directo...');
    const result = await WebhookService.handleIncomingSignal({
      provider: 'SBP_RUSSIA',
      data: {
        id: `sim_${Math.random().toString(36).substring(7)}`,
        status: 'completed',
        amount: 5000,
        currency: 'RUB'
      }
    });

    if (result.success) setStatusMsg('Depósito simulado con éxito.');
    else setStatusMsg(`Fallo: ${result.error}`);
    fetchData();
  };

  if (!isAuthorized) {
    return (
      <Layout hideNav>
        <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-6 animate-in fade-in duration-700">
           <div className="w-full max-w-[380px] space-y-10">
              <header className="text-center space-y-4">
                 <div className="size-24 rounded-[2.5rem] bg-amber-500/10 border-2 border-amber-500/20 flex items-center justify-center mx-auto shadow-[0_0_50px_rgba(245,158,11,0.1)]">
                    <span className="material-symbols-outlined text-5xl text-amber-500 font-black">terminal</span>
                 </div>
                 <div>
                    <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter">Terminal Maestra</h2>
                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.4em] mt-1">Requiere Token de Acceso Nivel 5</p>
                 </div>
              </header>

              <div className="bg-white/5 border border-white/10 rounded-[3rem] p-8 space-y-6 shadow-2xl backdrop-blur-xl">
                 <div className="space-y-2">
                    <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest px-4">Master Access Token</label>
                    <input 
                      type="password" 
                      className="w-full bg-slate-900 border border-slate-800 rounded-2xl py-4 px-6 text-lg text-white focus:border-primary outline-none transition-all placeholder:text-slate-800 font-mono tracking-widest"
                      placeholder="••••••••"
                      value={accessToken}
                      onChange={e => setAccessToken(e.target.value)}
                    />
                 </div>
                 
                 <button 
                  onClick={handleIdentityHandshake}
                  disabled={isVerifying || !accessToken}
                  className="w-full py-5 bg-primary text-white rounded-2xl font-black text-[11px] uppercase tracking-[0.3em] shadow-xl active:scale-95 transition-all flex items-center justify-center gap-3 disabled:opacity-30"
                 >
                   {isVerifying ? (
                     <span className="size-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                   ) : (
                     <>Desbloquear Consola <span className="material-symbols-outlined text-sm">security</span></>
                   )}
                 </button>
              </div>

              <button onClick={() => navigate('/')} className="w-full text-[9px] font-black text-slate-600 uppercase tracking-widest hover:text-white transition-colors">
                 Volver al Panel de Usuario
              </button>
           </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout hideNav>
      <header className="p-6 pt-10 border-b border-slate-800 flex justify-between items-center bg-background-dark/95 sticky top-0 z-50 backdrop-blur-md">
        <button onClick={() => navigate('/profile')} className="size-11 flex items-center justify-center rounded-2xl bg-slate-800/50 hover:bg-slate-800 transition-all text-white">
          <span className="material-symbols-outlined text-[20px]">arrow_back_ios_new</span>
        </button>
        <div className="text-center">
            <h2 className="text-xl font-black text-white uppercase tracking-tighter italic">Consola de Control</h2>
            <p className="text-[10px] font-black text-primary uppercase tracking-[0.2em] mt-0.5">Admin Bridge Console</p>
        </div>
        <button onClick={() => setIsAuthorized(false)} className="text-slate-500 hover:text-red-500 transition-colors">
          <span className="material-symbols-outlined">logout</span>
        </button>
      </header>

      <div className="p-6 space-y-8 pb-32 animate-in fade-in duration-500">
        <div className="flex p-1.5 bg-slate-900 border border-slate-800 rounded-[2rem]">
          <button 
            onClick={() => setActiveTab('AUDIT')}
            className={`flex-1 py-4 rounded-[1.5rem] text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'AUDIT' ? 'bg-primary text-white' : 'text-slate-500'}`}
          >
            Auditoría
          </button>
          <button 
            onClick={() => setActiveTab('SIMULATOR')}
            className={`flex-1 py-4 rounded-[1.5rem] text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'SIMULATOR' ? 'bg-primary text-white' : 'text-slate-500'}`}
          >
            Simulador
          </button>
        </div>

        {activeTab === 'SIMULATOR' && (
           <div className="space-y-6">
              <button 
                onClick={simulateDirectDeposit}
                className="w-full p-8 bg-card-dark border border-slate-800 rounded-[2.5rem] flex items-center justify-between hover:border-primary/50 transition-all active:scale-[0.98] group shadow-xl"
              >
                <div className="flex items-center gap-5">
                  <div className="size-14 rounded-2xl bg-blue-500/10 text-blue-500 flex items-center justify-center border border-blue-500/20">
                    <span className="material-symbols-outlined font-black text-3xl">bolt</span>
                  </div>
                  <div className="text-left">
                    <h4 className="text-base font-black text-white uppercase tracking-tight">Simular Depósito SBP</h4>
                    <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Señal desde Nodo Ruso</p>
                  </div>
                </div>
                <span className="material-symbols-outlined text-slate-700 group-hover:text-primary transition-colors text-3xl">broadcast_on_personal</span>
              </button>
              {statusMsg && <p className="text-center text-[10px] font-black text-primary uppercase tracking-widest animate-pulse">{statusMsg}</p>}
           </div>
        )}

        {activeTab === 'AUDIT' && (
           <div className="space-y-4">
              <div className="flex justify-between items-center px-2">
                 <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Logs de Señales de Red</h3>
              </div>
              {logs.map(log => (
                <div key={log.id} className="bg-card-dark border border-slate-800 p-6 rounded-[2.5rem] flex items-center justify-between shadow-lg">
                   <div className="flex items-center gap-5">
                      <div className={`size-12 rounded-2xl flex items-center justify-center ${log.processed ? 'bg-green-500/10 text-green-500' : 'bg-red-500/10 text-red-500'}`}>
                         <span className="material-symbols-outlined text-2xl font-black">{log.processed ? 'verified' : 'pending'}</span>
                      </div>
                      <div>
                         <p className="text-sm font-black text-white uppercase">{log.provider}</p>
                         <p className="text-[9px] text-slate-500 font-mono mt-1">REF: {log.id.slice(0, 8)}</p>
                      </div>
                   </div>
                </div>
              ))}
           </div>
        )}
      </div>
    </Layout>
  );
};

export default AdminNode;
