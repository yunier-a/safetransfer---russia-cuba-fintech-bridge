
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Layout } from '../components/Layout';
import { supabase } from '../services/supabase';
import { User } from '@supabase/supabase-js';
import { BankCard } from '../types';

const Profile: React.FC = () => {
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<'IDENTITY' | 'PAYMENTS' | 'SECURITY'>('IDENTITY');
  const [bankCards, setBankCards] = useState<BankCard[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Editing States
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState('');
  const [editAvatar, setEditAvatar] = useState('');
  const [isUpdating, setIsUpdating] = useState(false);

  // Add Card States
  const [isAddCardModalOpen, setIsAddCardModalOpen] = useState(false);
  const [isSavingCard, setIsSavingCard] = useState(false);
  const [newCard, setNewCard] = useState({
    number: '',
    holder: '',
    expiry: '',
    cvv: ''
  });

  useEffect(() => {
    fetchSession();
  }, []);

  const fetchSession = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    setUser(session?.user ?? null);
    if (session) {
      await fetchData(session.user.id);
    }
    setIsLoading(false);
  };

  const fetchData = async (userId: string) => {
    // Perfil
    const { data: prof } = await supabase.from('profiles').select('*').eq('id', userId).maybeSingle();
    if (prof) {
      setProfile(prof);
      setEditName(prof.full_name || '');
      setEditAvatar(prof.avatar_url || '');
    }

    // Cargar tarjetas con fallback a LocalStorage si la tabla no existe o hay error
    try {
      const { data: cards, error } = await supabase
        .from('bank_cards')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      setBankCards(cards || []);
    } catch (err) {
      console.warn("DB Card Fetch failed, using local vault fallback.");
      const localCards = localStorage.getItem(`st_cards_${userId}`);
      if (localCards) setBankCards(JSON.parse(localCards));
    }
  };

  const handleUpdateProfile = async () => {
    if (!user) return;
    setIsUpdating(true);
    
    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          full_name: editName,
          avatar_url: editAvatar,
          updated_at: new Date().toISOString(),
        })
        .eq('id', user.id);

      if (error) throw error;
      setProfile({ ...profile, full_name: editName, avatar_url: editAvatar });
      setIsEditing(false);
    } catch (err: any) {
      alert("Error en la sincronización del perfil: " + err.message);
    } finally {
      setIsUpdating(false);
    }
  };

  const validateCard = () => {
    const cleanNumber = newCard.number.replace(/\s/g, '');
    if (cleanNumber.length < 16) return "Número de tarjeta inválido (requiere 16 dígitos).";
    if (!newCard.holder.trim()) return "El nombre del titular es requerido.";
    if (!/^\d{2}\/\d{2}$/.test(newCard.expiry)) return "Formato de expiración inválido (MM/YY).";
    if (newCard.cvv.length < 3) return "CVV inválido.";
    return null;
  };

  const handleAddCard = async () => {
    if (!user) return;
    
    const errorMsg = validateCard();
    if (errorMsg) {
      alert(errorMsg);
      return;
    }

    setIsSavingCard(true);
    const cleanNumber = newCard.number.replace(/\s/g, '');
    const last4 = cleanNumber.slice(-4);
    
    // Brand detection logic
    let brand = 'MIR';
    if (cleanNumber.startsWith('4')) brand = 'VISA';
    else if (cleanNumber.startsWith('5')) brand = 'MASTERCARD';
    
    const [month, year] = newCard.expiry.split('/');
    const colors = ['bg-slate-900', 'bg-blue-900', 'bg-indigo-900', 'bg-emerald-900'];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];

    const cardPayload = {
      user_id: user.id,
      holder_name: newCard.holder.toUpperCase(),
      last4,
      brand,
      exp_month: month || '12',
      exp_year: year || '25',
      color: randomColor
    };

    try {
      const { data, error } = await supabase.from('bank_cards').insert(cardPayload).select();
      
      if (error) throw error;
      
      await fetchData(user.id);
      setIsAddCardModalOpen(false);
      setNewCard({ number: '', holder: '', expiry: '', cvv: '' });
      alert("Tarjeta vinculada con éxito al nodo seguro.");
    } catch (err: any) {
      console.error("DB Insert Error:", err);
      // Fallback: Guardar en LocalStorage si falla la base de datos para no bloquear al usuario
      const existingLocal = JSON.parse(localStorage.getItem(`st_cards_${user.id}`) || '[]');
      const mockCard = { ...cardPayload, id: `local_${Date.now()}`, created_at: new Date().toISOString() };
      const updatedLocal = [mockCard, ...existingLocal];
      localStorage.setItem(`st_cards_${user.id}`, JSON.stringify(updatedLocal));
      
      setBankCards(updatedLocal as any);
      setIsAddCardModalOpen(false);
      setNewCard({ number: '', holder: '', expiry: '', cvv: '' });
      alert("Nodo de pago sincronizado localmente (Bóveda Offline activa).");
    } finally {
      setIsSavingCard(false);
    }
  };

  const handleDeleteCard = async (id: string) => {
    if (!confirm("¿Desvincular esta tarjeta del nodo seguro?")) return;
    
    if (String(id).startsWith('local_')) {
      const existingLocal = JSON.parse(localStorage.getItem(`st_cards_${user?.id}`) || '[]');
      const filtered = existingLocal.filter((c: any) => c.id !== id);
      localStorage.setItem(`st_cards_${user?.id}`, JSON.stringify(filtered));
      setBankCards(filtered);
      return;
    }

    const { error } = await supabase.from('bank_cards').delete().eq('id', id);
    if (error) {
       // Si falla el borrado en DB, intentamos limpiar local por si acaso
       alert("Error al borrar en nube, limpiando caché local.");
    }
    if (user) fetchData(user.id);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setEditAvatar(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    navigate('/login');
  };

  if (!user && !isLoading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-8 bg-slate-950 text-center space-y-8">
         <div className="size-24 rounded-[2.5rem] bg-primary/10 border-2 border-primary/20 flex items-center justify-center shadow-lg">
            <span className="material-symbols-outlined text-primary text-5xl font-black">lock</span>
         </div>
         <div className="space-y-2">
           <h2 className="text-2xl font-black text-white uppercase italic tracking-tighter">Acceso Restringido</h2>
           <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest max-w-[200px] mx-auto">Debes sincronizar tu identidad con el nodo central para ver tu perfil.</p>
         </div>
         <button 
           onClick={() => navigate('/login')}
           className="w-full max-w-[240px] py-5 bg-primary text-white rounded-[1.5rem] font-black text-[11px] uppercase tracking-[0.3em] shadow-xl active:scale-95"
         >
           Ir al Portal de Acceso
         </button>
      </div>
    );
  }

  return (
    <Layout>
      <header className="relative flex flex-col items-center bg-background-dark p-6 pt-16 pb-12">
        <div className="relative mb-6">
          <div className="size-32 rounded-[3rem] p-1.5 border-2 border-primary/20 bg-card-dark overflow-hidden shadow-2xl relative group">
            <div className="size-full rounded-[2.5rem] overflow-hidden bg-slate-800 flex items-center justify-center">
              {(isEditing ? editAvatar : profile?.avatar_url) ? (
                <img src={isEditing ? editAvatar : profile.avatar_url} className="size-full object-cover" alt="Avatar" />
              ) : (
                <span className="material-symbols-outlined text-5xl text-slate-600">person</span>
              )}
            </div>
            {isEditing && (
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="absolute inset-0 bg-black/50 flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity rounded-[2.5rem]"
              >
                <span className="material-symbols-outlined">add_a_photo</span>
              </button>
            )}
            <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileChange} />
          </div>
        </div>
        <div className="text-center space-y-2 mt-4">
          <h2 className="text-3xl font-black text-white tracking-tighter uppercase italic">
            {profile?.full_name || user?.email?.split('@')[0] || 'Node Pilot'}
          </h2>
          <p className="text-[10px] uppercase font-black tracking-[0.4em] text-slate-500">SF-SYNC-NODE: {user?.id?.slice(0, 8).toUpperCase()}</p>
        </div>
      </header>

      <div className="px-6 mb-8">
        <div className="flex p-1.5 bg-card-dark border border-slate-800 rounded-[2.5rem] shadow-xl">
          {(['IDENTITY', 'PAYMENTS', 'SECURITY'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 py-4 rounded-[2rem] text-[10px] font-black uppercase tracking-widest transition-all ${
                activeTab === tab ? 'bg-primary text-white shadow-lg' : 'text-slate-500 hover:text-white'
              }`}
            >
              {tab === 'IDENTITY' ? 'Perfil' : tab === 'PAYMENTS' ? 'Pagos' : 'Seguridad'}
            </button>
          ))}
        </div>
      </div>

      <main className="p-6 space-y-10 pb-32">
        {activeTab === 'IDENTITY' && (
          <div className="animate-in fade-in duration-500 space-y-6">
             <div className="bg-card-dark rounded-[2.5rem] border border-slate-800 p-10 space-y-8 shadow-xl">
                <div className="space-y-2">
                  <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-1">Identidad de Nodo</p>
                  {isEditing ? (
                    <input 
                      type="text"
                      className="w-full bg-slate-950 border border-slate-800 rounded-2xl py-4 px-6 text-white font-bold outline-none focus:border-primary transition-all"
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      placeholder="Nombre Completo"
                    />
                  ) : (
                    <div className="bg-slate-950 p-6 rounded-3xl border border-slate-800">
                      <p className="text-white font-black text-xl uppercase tracking-tight">{profile?.full_name || 'Usuario Autorizado'}</p>
                    </div>
                  )}
                </div>
                
                <div className="pt-4 space-y-3">
                  {isEditing ? (
                    <div className="flex gap-3">
                      <button 
                        onClick={handleUpdateProfile}
                        disabled={isUpdating}
                        className="flex-1 py-4 bg-primary text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg flex items-center justify-center gap-2"
                      >
                        {isUpdating ? <span className="size-4 border-2 border-white/20 border-t-white rounded-full animate-spin"></span> : 'Guardar'}
                      </button>
                      <button 
                        onClick={() => { setIsEditing(false); setEditName(profile?.full_name || ''); setEditAvatar(profile?.avatar_url || ''); }}
                        disabled={isUpdating}
                        className="flex-1 py-4 bg-slate-800 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest"
                      >
                        Cancelar
                      </button>
                    </div>
                  ) : (
                    <>
                      <button 
                        onClick={() => setIsEditing(true)}
                        className="w-full py-4 bg-primary/10 border border-primary/20 text-primary rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2"
                      >
                        <span className="material-symbols-outlined text-sm">edit</span>
                        Editar Perfil
                      </button>
                      
                      <button 
                        onClick={() => navigate('/brand-lab')}
                        className="w-full py-4 bg-slate-800 border border-white/5 text-slate-300 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-slate-700 transition-all"
                      >
                        <span className="material-symbols-outlined text-sm">palette</span>
                        Lab AI de Marca
                      </button>
                    </>
                  )}
                </div>
             </div>
             
             <button onClick={handleSignOut} className="w-full py-8 bg-slate-900 text-white font-black text-xs uppercase tracking-[0.2em] rounded-[2rem] border border-slate-800 active:scale-95 transition-all">
                Cerrar Sesión
             </button>
          </div>
        )}

        {activeTab === 'PAYMENTS' && (
          <div className="animate-in slide-in-from-bottom-4 duration-500 space-y-8">
             <div className="flex justify-between items-center px-2">
                <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Nodos de Pago Vinculados</h3>
                <span className="text-[9px] font-black text-primary uppercase">{bankCards.length} Activos</span>
             </div>

             <div className="space-y-4">
                {bankCards.length === 0 ? (
                  <div className="bg-slate-900/40 border-2 border-dashed border-slate-800 rounded-[2.5rem] p-12 text-center space-y-4 opacity-50">
                    <span className="material-symbols-outlined text-4xl">credit_card_off</span>
                    <p className="text-[10px] font-black uppercase tracking-widest">Sin tarjetas detectadas</p>
                  </div>
                ) : (
                  bankCards.map(card => (
                    <div key={card.id} className={`${card.color} rounded-[2rem] p-7 shadow-2xl relative overflow-hidden group transition-all`}>
                      <div className="absolute top-0 right-0 p-8 opacity-10">
                         <span className="material-symbols-outlined text-[80px]">contactless</span>
                      </div>
                      <div className="relative z-10 flex flex-col h-full justify-between gap-10">
                        <div className="flex justify-between items-start">
                          <div className="flex flex-col gap-1">
                             <p className="text-[8px] font-black text-white/50 uppercase tracking-[0.3em]">Red de Liquidación</p>
                             <p className="text-lg font-black text-white italic tracking-tighter">{card.brand}</p>
                          </div>
                          <button onClick={() => handleDeleteCard(card.id)} className="text-white/20 hover:text-red-500 transition-colors">
                            <span className="material-symbols-outlined text-lg">delete</span>
                          </button>
                        </div>
                        
                        <div className="space-y-4">
                           <p className="text-xl font-mono text-white tracking-[0.2em]">•••• •••• •••• {card.last4}</p>
                           <div className="flex justify-between items-end">
                              <div>
                                <p className="text-[8px] font-black text-white/50 uppercase tracking-widest">Titular</p>
                                <p className="text-xs font-black text-white uppercase tracking-tight">{card.holder_name}</p>
                              </div>
                              <div className="text-right">
                                <p className="text-[8px] font-black text-white/50 uppercase tracking-widest">Expira</p>
                                <p className="text-xs font-black text-white font-mono">{card.exp_month}/{card.exp_year}</p>
                              </div>
                           </div>
                        </div>
                      </div>
                    </div>
                  ))
                )}
             </div>

             <button 
               onClick={() => setIsAddCardModalOpen(true)}
               className="w-full py-8 border-2 border-dashed border-primary/30 bg-primary/5 rounded-[2.5rem] flex flex-col items-center justify-center gap-3 text-primary hover:bg-primary/10 hover:border-primary/50 transition-all group active:scale-[0.98] shadow-lg shadow-primary/5"
             >
                <div className="size-14 rounded-2xl bg-primary text-white flex items-center justify-center shadow-xl shadow-primary/20 group-hover:scale-110 transition-transform">
                   <span className="material-symbols-outlined text-3xl font-black">add_card</span>
                </div>
                <div className="text-center">
                   <span className="text-xs font-black uppercase tracking-[0.2em]">Añadir Nueva Tarjeta</span>
                   <p className="text-[8px] font-bold text-slate-500 uppercase mt-0.5 tracking-widest">Sincronizar Nodo de Pago</p>
                </div>
             </button>
          </div>
        )}
      </main>

      {/* ADD CARD MODAL */}
      {isAddCardModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-end justify-center px-4 pb-10 sm:items-center">
          <div className="absolute inset-0 bg-background-dark/95 backdrop-blur-md animate-in fade-in duration-300" onClick={() => !isSavingCard && setIsAddCardModalOpen(false)}></div>
          <div className="relative w-full max-w-[420px] bg-card-dark rounded-[4rem] border border-slate-800 shadow-2xl p-10 animate-in slide-in-from-bottom duration-500 space-y-8">
            <header className="flex justify-between items-center px-2">
              <div>
                <h3 className="text-xl font-black text-white uppercase italic tracking-tighter">Vincular Nodo de Pago</h3>
                <p className="text-[9px] font-black text-primary uppercase tracking-widest mt-1">Cifrado Cuántico v5.0</p>
              </div>
              <button onClick={() => setIsAddCardModalOpen(false)} className="size-10 flex items-center justify-center rounded-xl bg-slate-800 text-slate-500 hover:text-white transition-colors">
                <span className="material-symbols-outlined">close</span>
              </button>
            </header>

            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest px-4">Número de Tarjeta</label>
                <input 
                  type="text"
                  maxLength={19}
                  className="w-full bg-slate-950 border border-slate-800 rounded-2xl py-5 px-6 text-white font-mono tracking-widest outline-none focus:border-primary transition-all placeholder:text-slate-900"
                  placeholder="0000 0000 0000 0000"
                  value={newCard.number}
                  onChange={(e) => {
                    let val = e.target.value.replace(/\D/g, '');
                    let formatted = val.replace(/(.{4})/g, '$1 ').trim();
                    setNewCard({...newCard, number: formatted});
                  }}
                />
              </div>

              <div className="space-y-2">
                <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest px-4">Titular</label>
                <input 
                  type="text"
                  className="w-full bg-slate-950 border border-slate-800 rounded-2xl py-5 px-6 text-white font-bold uppercase outline-none focus:border-primary transition-all placeholder:text-slate-900"
                  placeholder="NOMBRE COMO EN TARJETA"
                  value={newCard.holder}
                  onChange={(e) => setNewCard({...newCard, holder: e.target.value})}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest px-4">Expiración (MM/YY)</label>
                  <input 
                    type="text"
                    maxLength={5}
                    className="w-full bg-slate-950 border border-slate-800 rounded-2xl py-5 px-6 text-white font-mono outline-none focus:border-primary transition-all text-center placeholder:text-slate-900"
                    placeholder="MM/YY"
                    value={newCard.expiry}
                    onChange={(e) => {
                      let val = e.target.value.replace(/\D/g, '');
                      if (val.length >= 2) val = val.slice(0, 2) + '/' + val.slice(2, 4);
                      setNewCard({...newCard, expiry: val});
                    }}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest px-4">CVC</label>
                  <input 
                    type="password"
                    maxLength={4}
                    className="w-full bg-slate-950 border border-slate-800 rounded-2xl py-5 px-6 text-white font-mono outline-none focus:border-primary transition-all text-center placeholder:text-slate-900"
                    placeholder="•••"
                    value={newCard.cvv}
                    onChange={(e) => setNewCard({...newCard, cvv: e.target.value.replace(/\D/g, '')})}
                  />
                </div>
              </div>

              <div className="pt-4 space-y-4">
                 <button 
                   onClick={handleAddCard}
                   disabled={isSavingCard}
                   className="w-full py-6 bg-primary text-white rounded-[2rem] font-black text-[12px] uppercase tracking-[0.3em] shadow-[0_20px_50px_-10px_rgba(19,109,236,0.5)] active:scale-95 transition-all flex items-center justify-center gap-3 disabled:opacity-30"
                 >
                   {isSavingCard ? (
                     <span className="size-6 border-4 border-white/30 border-t-white rounded-full animate-spin"></span>
                   ) : (
                     <>Autorizar Vínculo <span className="material-symbols-outlined text-xl font-black">shield_lock</span></>
                   )}
                 </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
};

export default Profile;
