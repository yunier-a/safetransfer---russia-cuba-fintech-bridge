
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://swkdukumxibmzqjfbzan.supabase.co';
const supabaseAnonKey = 'sb_publishable_dVptJrKhkJFpQtvv8qxa4g_GsFrMJkJ';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
