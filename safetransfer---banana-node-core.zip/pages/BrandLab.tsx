
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Layout } from '../components/Layout';
import { GoogleGenAI } from "@google/genai";

const BrandLab: React.FC = () => {
  const navigate = useNavigate();
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedLogo, setGeneratedLogo] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const generateLogo = async () => {
    setIsGenerating(true);
    setError(null);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateImages({
        model: 'imagen-4.0-generate-001',
        prompt: 'A modern, professional and secure minimalist logo for a financial app called SafeTransfer. The logo features a sleek, stylized banana silhouette integrated with an upward-pointing financial arrow or a minimalist stock graph. Professional fintech style, navy blue and vibrant yellow-gold colors, flat vector design, clean white background, high-end and trustworthy feel.',
        config: {
          numberOfImages: 1,
          aspectRatio: '1:1',
          outputMimeType: 'image/jpeg',
        },
      });

      if (response.generatedImages && response.generatedImages.length > 0) {
        const base64 = response.generatedImages[0].image.imageBytes;
        setGeneratedLogo(`data:image/jpeg;base64,${base64}`);
      } else {
        throw new Error("No se pudo generar la imagen.");
      }
    } catch (err: any) {
      console.error("Imagen Generation Error:", err);
      setError("Error al conectar con el motor Imagen 4.0. Verifica la conexión del nodo.");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <Layout hideNav>
      <header className="p-6 pt-10 border-b border-slate-200 dark:border-white/5 bg-white dark:bg-app-bg-dark sticky top-0 z-50 backdrop-blur-md">
        <div className="flex items-center justify-between">
          <button onClick={() => navigate(-1)} className="size-11 flex items-center justify-center rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-500 shadow-sm active:scale-90">
            <span className="material-symbols-outlined text-[20px]">arrow_back_ios_new</span>
          </button>
          <div className="text-center">
            <h2 className="text-xl font-black text-slate-900 dark:text-white uppercase tracking-tighter italic">Laboratorio de Marca</h2>
            <p className="text-[10px] font-black text-primary uppercase tracking-[0.2em] mt-0.5">Imagen 4.0 Creative Suite</p>
          </div>
          <div className="size-11"></div>
        </div>
      </header>

      <main className="p-6 space-y-10 pb-32 animate-in fade-in duration-500">
        <section className="bg-slate-900 rounded-[3rem] p-10 shadow-2xl relative overflow-hidden text-center space-y-6">
           <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_var(--tw-gradient-stops))] from-primary/20 via-transparent to-transparent"></div>
           <div className="relative z-10 size-24 bg-primary/10 rounded-[2rem] border border-primary/20 flex items-center justify-center mx-auto shadow-inner">
              <span className="material-symbols-outlined text-5xl text-primary font-black animate-pulse">auto_awesome</span>
           </div>
           <div className="relative z-10 space-y-2">
              <h3 className="text-white font-black text-xl uppercase tracking-tight italic">Identidad Visual Generativa</h3>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest leading-relaxed">
                Utiliza redes neuronales profundas para sintetizar el logo oficial de tu terminal SafeTransfer.
              </p>
           </div>
        </section>

        <section className="space-y-6">
           <div className="flex justify-between items-center px-2">
              <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Resultado de Síntesis</h3>
              {generatedLogo && (
                <button onClick={() => setGeneratedLogo(null)} className="text-[9px] font-black text-primary uppercase tracking-widest">Reiniciar</button>
              )}
           </div>

           <div className="w-full aspect-square rounded-[3.5rem] border-4 border-dashed border-slate-200 dark:border-slate-800 bg-white dark:bg-app-card-dark flex flex-col items-center justify-center relative overflow-hidden shadow-inner group">
              {isGenerating ? (
                <div className="flex flex-col items-center gap-6 animate-pulse">
                   <div className="size-20 border-4 border-primary/10 border-t-primary rounded-full animate-spin"></div>
                   <div className="text-center space-y-1">
                      <p className="text-[11px] font-black text-slate-900 dark:text-white uppercase tracking-[0.3em]">Procesando Píxeles...</p>
                      <p className="text-[8px] text-slate-500 font-black uppercase tracking-widest">Imagen 4.0 Neural Bridge</p>
                   </div>
                </div>
              ) : generatedLogo ? (
                <img src={generatedLogo} className="size-full object-cover animate-in zoom-in duration-700" alt="Logo SafeTransfer" />
              ) : (
                <div className="text-center p-12 space-y-6 opacity-40 group-hover:opacity-60 transition-opacity">
                   <span className="material-symbols-outlined text-7xl text-slate-400">palette</span>
                   <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest max-w-[200px] mx-auto">
                      Presiona el botón inferior para iniciar el protocolo de diseño basado en plátanos y activos financieros.
                   </p>
                </div>
              )}
           </div>

           {error && (
             <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-2xl text-center">
                <p className="text-[9px] text-red-500 font-black uppercase tracking-tight">{error}</p>
             </div>
           )}

           <button 
             onClick={generateLogo}
             disabled={isGenerating}
             className={`w-full py-8 rounded-[2.5rem] font-black text-sm uppercase tracking-[0.3em] transition-all active:scale-95 shadow-2xl flex items-center justify-center gap-5 ${
               isGenerating ? 'bg-slate-200 dark:bg-slate-800 text-slate-400' : 'bg-primary text-white shadow-primary/30'
             }`}
           >
              {isGenerating ? 'Generando Identidad...' : (
                <>
                  Generar Logo SafeTransfer
                  <span className="material-symbols-outlined font-black">rocket_launch</span>
                </>
              )}
           </button>
        </section>

        <section className="bg-primary/5 border border-primary/20 rounded-[2.5rem] p-8 flex gap-6 items-start shadow-inner">
           <div className="size-14 rounded-3xl bg-primary/10 flex items-center justify-center text-primary shrink-0 border border-primary/10 shadow-lg">
             <span className="material-symbols-outlined text-3xl font-black">brush</span>
           </div>
           <div className="space-y-1">
             <h4 className="text-[10px] font-black text-slate-900 dark:text-white uppercase tracking-widest">Especificaciones del Prompt</h4>
             <p className="text-[10px] text-slate-500 leading-relaxed font-bold uppercase tracking-tight italic">
               "Diseño minimalista moderno: Plátano profesional fusionado con flecha financiera ascendente. Colores: Azul Marino y Oro-Amarillo. Estilo Vectorial."
             </p>
           </div>
        </section>
      </main>
    </Layout>
  );
};

export default BrandLab;
