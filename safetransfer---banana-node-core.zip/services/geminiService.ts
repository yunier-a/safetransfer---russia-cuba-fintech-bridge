
import { GoogleGenAI, Type } from "@google/genai";

const SYSTEM_INSTRUCTION = `
Eres "SafeTransfer Financial Core v5.0", un motor de inteligencia artificial de grado institucional.
Tu especialidad es el corredor financiero Rusia-Cuba.
Misión: Analizar discrepancias entre la tasa del Banco Central de Rusia (CBR), el mercado informal en Cuba (CUP) y la liquidez en USDT.
Objetivo: Identificar ventanas de oportunidad (arbitraje) y riesgos de volatilidad.
Si el usuario envía una imagen (recibo, factura, documento), analízala visualmente para extraer datos relevantes como montos, números de tarjeta o estados de transacción.
`;

export const translateFinancialText = async (text: string, targetLang: 'ES' | 'RU' | 'EN' = 'ES') => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Traduce el siguiente texto financiero al ${targetLang === 'ES' ? 'Español' : targetLang === 'RU' ? 'Ruso' : 'Inglés'}. Mantén la precisión de términos bancarios: "${text}"`,
      config: {
        systemInstruction: "Eres un traductor financiero experto especializado en el mercado de divisas y cripto.",
        temperature: 0.1
      }
    });
    return response.text || text;
  } catch (error) {
    return text;
  }
};

export const getNeuralMarketSignal = async () => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: "Realiza un análisis profundo del par RUB/CUP y USD/RUB. Busca noticias recientes sobre sanciones, acuerdos comerciales Rusia-Cuba o cambios en la tasa informal de El Toque. Determina si es un momento 'Premium' para enviar remesas. Devuelve un JSON estructurado.",
      config: {
        systemInstruction: "Eres un analista de arbitraje cuantitativo. Tu tono es ejecutivo y preciso. Identifica oportunidades de ahorro de más del 5% para el usuario.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            opportunity_score: { type: Type.NUMBER, description: "0-100 score of how good the timing is" },
            headline: { type: Type.STRING },
            analysis: { type: Type.STRING },
            suggested_action: { type: Type.STRING, description: "e.g., SWAP_RUB_TO_CUP" },
            confidence_level: { type: Type.STRING, description: "HIGH, MEDIUM, LOW" },
            estimated_saving: { type: Type.STRING, description: "e.g., 5.4%" }
          },
          required: ["opportunity_score", "headline", "analysis", "suggested_action"]
        },
        tools: [{ googleSearch: {} }]
      }
    });

    const text = response.text || '{}';
    const jsonStr = text.replace(/```json/g, '').replace(/```/g, '').trim();
    return JSON.parse(jsonStr);
  } catch (error) {
    console.error("Neural Signal Error:", error);
    return null;
  }
};

export const getBotResponse = async (userMessage: string, contextData?: any, fileData?: { data: string, mimeType: string }) => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    let textPrompt = userMessage;
    if (contextData) {
      textPrompt = `[CONTEXTO: Balances: ${JSON.stringify(contextData.balances)}. Transacciones: ${JSON.stringify(contextData.transactions)}]\n\nCONSULTA: ${userMessage}`;
    }

    const parts: any[] = [{ text: textPrompt }];
    
    if (fileData) {
      parts.push({
        inlineData: {
          data: fileData.data,
          mimeType: fileData.mimeType
        }
      });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: { parts },
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.1,
        thinkingConfig: { thinkingBudget: 16000 },
        tools: [{ googleSearch: {} }],
      },
    });
    
    return {
      text: response.text || "Sincronizando con los nodos bancarios...",
      groundingChunks: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
    };
  } catch (error) {
    console.error("Gemini Core Failure:", error);
    return { 
      text: "El nodo de IA está experimentando alta latencia. Reintentando conexión segura...", 
      groundingChunks: [] 
    };
  }
};

export const getDailyBriefing = async () => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: 'Resume brevemente 3 noticias financieras de Rusia y Cuba hoy. Incluye tasas USD/RUB y USD/CUP.',
      config: {
        tools: [{ googleSearch: {} }],
        systemInstruction: "Analista de datos bancarios neutro.",
      },
    });
    
    return {
      text: response.text || "No hay boletines disponibles.",
      links: response.candidates?.[0]?.groundingMetadata?.groundingChunks?.filter((c: any) => c.web).map((c: any) => ({
        title: c.web.title,
        uri: c.web.uri
      })) || []
    };
  } catch (error) {
    return { text: "Sincronizando boletines...", links: [] };
  }
};

export const getMarketUpdate = async () => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: "Tasas actuales: USD/RUB, USD/CUP, RUB/CUP. BTC/USD, ETH/USD. Devuelve solo JSON.",
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            USD_RUB: { type: Type.NUMBER },
            EUR_RUB: { type: Type.NUMBER },
            RUB_CUP: { type: Type.NUMBER },
            USD_CUP: { type: Type.NUMBER },
            BTC_USD: { type: Type.NUMBER },
            ETH_USD: { type: Type.NUMBER },
            USDT_RUB: { type: Type.NUMBER },
            DYNAMIC_COMMISSION: { type: Type.NUMBER }
          },
          required: ["USD_RUB", "RUB_CUP"]
        }
      }
    });

    return { 
      rates: JSON.parse(response.text || '{}'), 
      source: 'SafeTransfer Interbank Feed' 
    };
  } catch (error) {
    return null;
  }
};

export const getMapsIntelligence = async (prompt: string, latitude: number, longitude: number) => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        tools: [{ googleMaps: {} }],
        toolConfig: {
          retrievalConfig: {
            latLng: {
              latitude: latitude,
              longitude: longitude,
            },
          },
        },
      },
    });

    return {
      text: response.text || "No se pudo obtener información de ubicación.",
      groundingChunks: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
    };
  } catch (error) {
    console.error("Maps Intelligence Error:", error);
    return { 
      text: "Error al sincronizar con el nodo de mapas.", 
      groundingChunks: [] 
    };
  }
};
