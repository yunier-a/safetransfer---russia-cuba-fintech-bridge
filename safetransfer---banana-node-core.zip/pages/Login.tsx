
import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { supabase } from '../services/supabase';
import { Layout } from '../components/Layout';
import { AudioService } from '../services/audioService';

const Login: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSignUp, setIsSignUp] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  // Capturar referido de la URL
  const referralId = searchParams.get('ref');

  useEffect(() => {
    const checkSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session) navigate('/');
    };
    checkSession();
  }, [navigate]);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;
    
    AudioService.playClick();
    setIsLoading(true);
    setError(null);
    setMessage(null);

    try {
      if (isSignUp) {
        // Registro con metadata de referido
        const { data, error: signUpError } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: {
              full_name: fullName || email.split('@')[0],
              referrer_id: referralId // Se guarda en user_metadata inicialmente
            }
          }
        });

        if (signUpError) throw signUpError;
        
        if (data.user) {
          // Crear perfil explícitamente para asegurar que el referrer_id se guarde
          await supabase.from('profiles').upsert({
            id: data.user.id,
            full_name: fullName || email.split('@')[0],
            referrer_id: referralId
          });

          if (data.session) {
            AudioService.playSuccess();
            navigate('/');
          } else {
            setMessage("Identidad creada. Verifica tu correo para activar el nodo.");
          }
        }
      } else {
        const { data, error: signInError } = await supabase.auth.signInWithPassword({
          email,
          password,
        });

        if (signInError) {
          if (signInError.message.includes("Email not confirmed")) {
            throw new Error("Identidad no activada. Por favor, confirma tu correo electrónico.");
          }
          throw signInError;
        }
        
        if (data.session) {
          AudioService.playSuccess();
          navigate('/');
        }
      }
    } catch (err: any) {
      setError(err.message || "Error en el protocolo de autenticación.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    AudioService.playClick();
    setIsLoading(true);
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: { redirectTo: window.location.origin }
      });
      if (error) throw error;
    } catch (err: any) {
      setError(err.message);
      setIsLoading(false);
    }
  };

  const handleFacebookLogin = async () => {
    AudioService.playClick();
    setIsLoading(true);
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'facebook',
        options: { redirectTo: window.location.origin }
      });
      if (error) throw error;
    } catch (err: any) {
      setError(err.message);
      setIsLoading(false);
    }
  };

  return (
    <Layout hideNav>
      <div className="flex flex-col items-center justify-center min-h-screen px-8 py-12 bg-slate-950">
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
          <div className="absolute top-[-10%] right-[-10%] w-[50%] h-[50%] bg-primary/20 rounded-full blur-[120px] animate-pulse"></div>
          <div className="absolute bottom-[-10%] left-[-10%] w-[50%] h-[50%] bg-blue-900/20 rounded-full blur-[120px]"></div>
        </div>

        <header className="text-center mb-10 relative z-10">
          <div className="size-20 bg-primary rounded-[2.5rem] flex items-center justify-center mx-auto mb-6 shadow-[0_0_50px_rgba(19,109,236,0.3)] border border-white/20">
            <span className="material-symbols-outlined text-white text-4xl font-black">hub</span>
          </div>
          <h1 className="text-3xl font-black text-white uppercase tracking-tighter italic">SafeTransfer</h1>
          <p className="text-[10px] font-black text-primary uppercase tracking-[0.4em] mt-2">
            {referralId ? 'Invitación de Nodo Activa' : 'Acceso Seguro al Nodo v5.2'}
          </p>
        </header>

        <main className="w-full max-w-[340px] space-y-6 relative z-10">
          {referralId && !isSignUp && (
            <div className="bg-primary/10 border border-primary/20 p-4 rounded-2xl text-center mb-4">
              <p className="text-[9px] text-primary font-black uppercase tracking-widest">Has sido invitado por un operador verificado</p>
            </div>
          )}

          <form onSubmit={handleAuth} className="space-y-4">
            {isSignUp && (
              <div className="space-y-1 animate-in slide-in-from-top-2">
                <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest px-4">Nombre de Operador</label>
                <input 
                  type="text" 
                  required
                  className="w-full bg-slate-900/50 border border-slate-800 rounded-2xl py-4 px-6 text-sm text-white focus:border-primary outline-none transition-all placeholder:text-slate-800"
                  placeholder="Ej. Yunier Montoya"
                  value={fullName}
                  onChange={e => setFullName(e.target.value)}
                />
              </div>
            )}
            
            <div className="space-y-1">
              <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest px-4">Identificador (Email)</label>
              <input 
                type="email" 
                required
                className="w-full bg-slate-900/50 border border-slate-800 rounded-2xl py-4 px-6 text-sm text-white focus:border-primary outline-none transition-all placeholder:text-slate-700"
                placeholder="operador@safetransfer.com"
                value={email}
                onChange={e => setEmail(e.target.value)}
              />
            </div>

            <div className="space-y-1">
              <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest px-4">Token (Contraseña)</label>
              <input 
                type="password" 
                required
                className="w-full bg-slate-900/50 border border-slate-800 rounded-2xl py-4 px-6 text-sm text-white focus:border-primary outline-none transition-all placeholder:text-slate-700 tracking-widest"
                placeholder="••••••••"
                value={password}
                onChange={e => setPassword(e.target.value)}
              />
            </div>

            {error && (
              <div className="bg-red-500/10 border border-red-500/20 p-4 rounded-2xl text-center animate-in shake duration-300">
                <p className="text-[10px] text-red-500 font-black uppercase tracking-tight">{error}</p>
              </div>
            )}

            {message && (
              <div className="bg-primary/10 border border-primary/20 p-4 rounded-2xl text-center animate-in zoom-in duration-300">
                <p className="text-[10px] text-primary font-black uppercase tracking-tight leading-relaxed">{message}</p>
              </div>
            )}

            <div className="flex flex-col gap-3 pt-4">
              <button 
                type="submit"
                disabled={isLoading}
                className="w-full py-5 bg-primary text-white rounded-[1.5rem] font-black text-[11px] uppercase tracking-[0.3em] shadow-[0_20px_40px_-10px_rgba(19,109,236,0.4)] active:scale-95 transition-all flex items-center justify-center gap-3 disabled:opacity-30"
              >
                {isLoading ? <span className="size-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span> : (isSignUp ? 'Registrar Identidad' : 'Sincronizar Nodo')}
              </button>

              <div className="flex items-center gap-4 my-2 px-4">
                <div className="flex-1 h-px bg-slate-800"></div>
                <span className="text-[8px] font-black text-slate-600 uppercase tracking-widest">O continuar con</span>
                <div className="flex-1 h-px bg-slate-800"></div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <button type="button" onClick={handleGoogleLogin} disabled={isLoading} className="w-full py-4 bg-white text-slate-900 rounded-[1.5rem] font-black text-[10px] uppercase tracking-[0.2em] shadow-xl active:scale-95 transition-all flex items-center justify-center gap-2 disabled:opacity-30">
                  <img src="https://img.icons8.com/color/48/google-logo.png" className="size-5" alt="Google" />
                  Google
                </button>
                <button type="button" onClick={handleFacebookLogin} disabled={isLoading} className="w-full py-4 bg-[#1877F2] text-white rounded-[1.5rem] font-black text-[10px] uppercase tracking-[0.2em] shadow-xl active:scale-95 transition-all flex items-center justify-center gap-2 disabled:opacity-30">
                  <img src="https://img.icons8.com/color/48/facebook-new.png" className="size-5 brightness-200" alt="Facebook" />
                  Facebook
                </button>
              </div>
              
              <button 
                type="button"
                onClick={() => { AudioService.playClick(); setIsSignUp(!isSignUp); setError(null); setMessage(null); }}
                className="w-full py-4 bg-transparent text-slate-500 rounded-[1.5rem] font-black text-[9px] uppercase tracking-[0.2em] hover:text-white transition-all"
              >
                {isSignUp ? 'Ya tengo una cuenta • Iniciar Sesión' : '¿Nuevo Operador? • Crear Cuenta'}
              </button>
            </div>
          </form>
        </main>

        <footer className="mt-16 text-center opacity-20 relative z-10">
           <p className="text-[8px] font-black text-slate-500 uppercase tracking-[0.5em]">Túnel de Acceso Seguro • SafeTransfer Network</p>
        </footer>
      </div>
    </Layout>
  );
};

export default Login;
