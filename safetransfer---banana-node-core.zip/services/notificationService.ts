
import { supabase } from './supabase';
import { AppNotification } from '../types';

const ADMIN_WHATSAPP = "16892564329";

export const NotificationService = {
  /**
   * Obtiene las notificaciones del usuario actual
   */
  async getMyNotifications(): Promise<AppNotification[]> {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return [];

    const { data, error } = await supabase
      .from('notifications')
      .select('*')
      .eq('user_id', session.user.id)
      .order('created_at', { ascending: false });

    if (error) return [];
    return data.map(n => ({
      ...n,
      timestamp: new Date(n.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }));
  },

  /**
   * Marca una notificación como leída
   */
  async markAsRead(id: string) {
    await supabase.from('notifications').update({ read: true }).eq('id', id);
  },

  /**
   * Crea una notificación manual (para el usuario)
   */
  async sendManualNotification(type: AppNotification['type'], title: string, message: string, status: AppNotification['status'] = 'SUCCESS') {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return;

    await supabase.from('notifications').insert({
      user_id: session.user.id,
      title,
      message,
      type,
      status
    });
    
    // Disparar evento nativo
    window.dispatchEvent(new CustomEvent('new-notification', { detail: { title, message } }));
  },

  /**
   * Notifica al administrador sobre una operación crítica
   */
  async notifyAdmin(operationType: string, details: any) {
    const { data: { session } } = await supabase.auth.getSession();
    const timestamp = new Date().toLocaleString();
    const txId = details.txId || `ST-${Math.random().toString(36).substring(7).toUpperCase()}`;

    // 1. Log en admin_alerts (System Notification for Admin)
    try {
      await supabase.from('admin_alerts').insert({
        operation_type: operationType,
        details: details,
        user_id: session?.user.id,
        user_email: session?.user.email,
        processed: false
      });
    } catch (err) {
      console.error("Admin alert logging failed:", err);
    }

    // 2. Log en notificaciones del usuario (Audit Trail personal)
    await supabase.from('notifications').insert({
      user_id: session?.user.id,
      title: `ADMIN NOTIFIED: ${operationType}`,
      message: `Ref: ${txId} | Se ha generado un reporte de auditoría para el administrador.`,
      type: 'SYSTEM',
      status: 'INFO'
    });

    // 3. Generar mensaje para WhatsApp (Reporting Bridge)
    const isDeposit = operationType.toLowerCase().includes('deposit');
    const isWithdraw = operationType.toLowerCase().includes('withdraw');
    const emoji = isDeposit ? '💰' : isWithdraw ? '💸' : '⚡';
    const label = isWithdraw ? 'RETIRO' : 'OPERACIÓN';
    
    const message = `${emoji} *OPERACIÓN SAFETRANSFER - REPORTE DE NODO*\n\n` +
                    `📌 *Evento:* ${operationType}\n` +
                    `🆔 *Ref:* ${txId}\n` +
                    `👤 *Usuario:* ${session?.user.email || 'Identidad Oculta'}\n` +
                    `💵 *Monto Bruto:* ${details.amount} ${details.currency}\n` +
                    `🎯 *Destino:* ${details.recipient}\n` +
                    `⏰ *Timestamp:* ${timestamp}\n\n` +
                    `⚡ _Acción requerida: Verificar fondos y procesar liquidación manual._`;

    return {
      whatsappLink: `https://wa.me/${ADMIN_WHATSAPP}?text=${encodeURIComponent(message)}`,
      txId
    };
  }
};
