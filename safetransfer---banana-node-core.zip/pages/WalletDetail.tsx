
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Layout } from '../components/Layout';
import { getBotResponse } from '../services/geminiService';

const WalletDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [expandedTxId, setExpandedTxId] = useState<string | null>(null);
  const [aiSummary, setAiSummary] = useState<string | null>(null);
  const [groundingLinks, setGroundingLinks] = useState<{ title: string; uri: string }[]>([]);
  const [isGeneratingAi, setIsGeneratingAi] = useState(false);
  const [isAddressCopied, setIsAddressCopied] = useState(false);
  
  const [fiatPreference, setFiatPreference] = useState<'RUB' | 'USD'>('RUB');
  const [scrubIndex, setScrubIndex] = useState<number | null>(null);
  const chartRef = useRef<SVGSVGElement>(null);

  // Asset Metadata and Mock Data
  const walletData: Record<string, any> = {
    btc: {
      id: 'btc',
      name: 'Bitcoin',
      symbol: 'BTC',
      balance: '0.0084219',
      fiatRub: '48,250.00',
      price: '$67,420.12',
      high24h: '$68,210.45',
      low24h: '$65,100.20',
      change: '+2.45%',
      perf: { h1: '+0.12%', d1: '+2.45%', d7: '-1.20%', m1: '+12.40%', y1: '+142.1%' },
      address: 'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh',
      color: 'text-orange-500',
      bgColor: 'bg-orange-500/10',
      icon: 'currency_bitcoin',
      chartPoints: [65100, 65400, 65200, 65800, 66300, 66100, 66800, 67200, 67420],
      history: [
        { id: 'tx1', type: 'Buy', amount: '+0.0015 BTC', fiatAmount: '10,113.01 RUB', date: 'Oct 24, 2024', time: '11:42 AM', status: 'Confirmed' },
        { id: 'tx2', type: 'Receive', amount: '+0.0028 BTC', fiatAmount: '18,877.63 RUB', date: 'Oct 24, 2024', time: '09:15 AM', status: 'Confirmed' }
      ]
    },
    usdt: {
      id: 'usdt',
      name: 'Tether (TRC-20)',
      symbol: 'USDT',
      balance: '124.50',
      fiatRub: '11,205.00',
      price: '$1.00',
      high24h: '$1.01',
      low24h: '$0.99',
      change: '+0.01%',
      address: 'TX58pXU4vT1p2zG8N7mH6qS9vR2eA1bC4d',
      color: 'text-green-500',
      bgColor: 'bg-green-500/10',
      icon: 'attach_money',
      chartPoints: [0.99, 1.00, 1.01, 1.00, 1.00, 0.99, 1.00, 1.00, 1.00],
      history: []
    },
    eth: {
      id: 'eth',
      name: 'Ethereum',
      symbol: 'ETH',
      balance: '0.1245',
      fiatRub: '28,440.00',
      price: '$2,850.40',
      high24h: '$2,910.15',
      low24h: '$2,780.60',
      change: '+1.82%',
      address: '0x71C7656EC7ab88b098defB751B7401B5f6d8976F',
      color: 'text-blue-400',
      bgColor: 'bg-blue-400/10',
      icon: 'token',
      chartPoints: [2780, 2810, 2850, 2830, 2890, 2910, 2870, 2840, 2850.4],
      history: []
    }
  };

  const data = walletData[id || 'btc'] || walletData.btc;

  const usdValue = useMemo(() => {
    const amount = parseFloat(data.balance);
    const usdPrice = parseFloat(data.price.replace('$', '').replace(/,/g, ''));
    return (amount * usdPrice).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }, [data]);

  const getYCoordinate = (value: number, min: number, max: number, height: number) => {
    return height - ((value - min) / (max - min)) * height;
  };

  const chartPath = useMemo(() => {
    const points = data.chartPoints;
    const min = Math.min(...points);
    const max = Math.max(...points);
    const width = 300;
    const height = 100;
    return points.map((p: number, i: number) => {
      const x = (i / (points.length - 1)) * width;
      const y = getYCoordinate(p, min, max, height);
      return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
    }).join(' ');
  }, [data.chartPoints]);

  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement> | React.TouchEvent<SVGSVGElement>) => {
    if (!chartRef.current) return;
    const rect = chartRef.current.getBoundingClientRect();
    let clientX;
    if ('touches' in e) clientX = e.touches[0].clientX;
    else clientX = e.clientX;
    const x = clientX - rect.left;
    const width = rect.width;
    const index = Math.round((x / width) * (data.chartPoints.length - 1));
    setScrubIndex(Math.max(0, Math.min(index, data.chartPoints.length - 1)));
  };

  const generateAiReport = async () => {
    if (isGeneratingAi) return;
    setIsGeneratingAi(true);
    const prompt = `Actúa como un analista de inteligencia financiera. Analiza el activo ${data.name} (${data.symbol}). 
    Precio actual: ${data.price}. Cambio 24h: ${data.change}. 
    Proporciona un resumen ejecutivo de 3 frases que incluya: 
    1. El sentimiento actual del mercado.
    2. Una tendencia proyectada basada en eventos recientes.
    3. Una recomendación técnica para usuarios del bridge SafeTransfer.`;
    
    const response = await getBotResponse(prompt);
    setAiSummary(response.text);
    
    if (response.groundingChunks) {
      const links = response.groundingChunks
        .filter((chunk: any) => chunk.web)
        .map((chunk: any) => ({
          title: chunk.web.title,
          uri: chunk.web.uri
        }));
      setGroundingLinks(links);
    }
    
    setIsGeneratingAi(false);
  };

  useEffect(() => {
    setIsLoading(true);
    const timer = setTimeout(() => {
      setIsLoading(false);
      generateAiReport();
    }, 800);
    return () => clearTimeout(timer);
  }, [id]);

  const handleExchangeAction = (action: 'buy' | 'sell') => {
    navigate('/exchange', { state: { asset: data.symbol, action } });
  };

  const handleCopyAddress = () => {
    if (isLoading) return;
    navigator.clipboard.writeText(data.address);
    setIsAddressCopied(true);
    setTimeout(() => setIsAddressCopied(false), 2000);
  };

  return (
    <Layout hideNav>
      <header className="flex items-center p-4 pt-10 bg-background-dark/80 backdrop-blur-md sticky top-0 z-50 border-b border-slate-800 justify-between">
        <button onClick={() => navigate(-1)} className="size-10 flex items-center justify-center rounded-full hover:bg-slate-800 transition-colors">
          <span className="material-symbols-outlined text-white">arrow_back_ios_new</span>
        </button>
        <div className="flex-1 text-center">
          <h1 className="text-lg font-bold text-white tracking-tight">{data.name}</h1>
          <p className="text-[10px] font-black text-primary uppercase tracking-[0.2em]">Node Terminal</p>
        </div>
        <button 
          onClick={generateAiReport}
          disabled={isGeneratingAi}
          className={`size-10 flex items-center justify-center rounded-xl bg-primary/10 text-primary border border-primary/20 transition-all ${isGeneratingAi ? 'animate-spin' : 'active:scale-90'}`}
        >
          <span className="material-symbols-outlined font-black">sync</span>
        </button>
      </header>

      <div className="p-4 space-y-6 pb-40 animate-in fade-in duration-500">
        
        {/* HERO BALANCE CARD */}
        <div className="bg-card-dark rounded-[2.5rem] border border-slate-800 p-8 shadow-2xl relative overflow-hidden group">
          <div className={`absolute -right-20 -top-20 size-64 ${data.bgColor} rounded-full blur-3xl opacity-30`}></div>
          
          <div className="relative z-10 flex flex-col items-center text-center">
            <div className={`size-16 rounded-[1.5rem] flex items-center justify-center mb-6 border border-white/5 ${data.bgColor} ${data.color} shadow-2xl`}>
              <span className="material-symbols-outlined text-4xl">{data.icon}</span>
            </div>
            
            <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] mb-1">Portfolio Position</p>
            <div className="flex flex-col items-center gap-1 mb-8">
              <h2 className="text-5xl font-black text-white tracking-tighter">
                {isLoading ? '---' : data.balance} <span className="text-xl font-bold text-slate-400">{data.symbol}</span>
              </h2>
              
              <div className="flex items-center gap-3 mt-3">
                <div className="flex items-center gap-2 bg-slate-900/60 py-1.5 px-4 rounded-full border border-slate-800 transition-all">
                  <span className="text-slate-500 text-xs font-bold">≈</span>
                  <span className="text-white font-black text-sm tracking-tight">
                    {fiatPreference === 'RUB' ? `${data.fiatRub} ₽` : `$ ${usdValue}`}
                  </span>
                </div>
                
                <div className="flex p-0.5 bg-slate-800 border border-slate-700 rounded-lg">
                  <button onClick={() => setFiatPreference('RUB')} className={`px-2 py-1 rounded-md text-[9px] font-black ${fiatPreference === 'RUB' ? 'bg-primary text-white' : 'text-slate-500'}`}>RUB</button>
                  <button onClick={() => setFiatPreference('USD')} className={`px-2 py-1 rounded-md text-[9px] font-black ${fiatPreference === 'USD' ? 'bg-primary text-white' : 'text-slate-500'}`}>USD</button>
                </div>
              </div>
            </div>

            <div className="w-full grid grid-cols-2 gap-4 mb-8">
              <button 
                onClick={() => handleExchangeAction('buy')}
                className="bg-green-600 hover:bg-green-500 h-16 rounded-2xl flex flex-col items-center justify-center gap-1 font-black text-xs uppercase tracking-[0.1em] transition-all active:scale-95 text-white shadow-lg shadow-green-900/20"
              >
                <span className="material-symbols-outlined text-[24px]">shopping_cart</span>
                Buy {data.symbol}
              </button>
              <button 
                onClick={() => handleExchangeAction('sell')}
                className="bg-red-600 hover:bg-red-500 h-16 rounded-2xl flex flex-col items-center justify-center gap-1 font-black text-xs uppercase tracking-[0.1em] transition-all active:scale-95 text-white shadow-lg shadow-red-900/20"
              >
                <span className="material-symbols-outlined text-[24px]">sell</span>
                Sell {data.symbol}
              </button>
            </div>

            <div className="w-full grid grid-cols-2 gap-3 mb-6">
                <button onClick={() => navigate('/send', { state: { asset: data.symbol } })} className="bg-primary/10 hover:bg-primary/20 text-primary border border-primary/20 h-14 rounded-2xl flex items-center justify-center gap-2 font-black text-xs uppercase tracking-widest transition-all active:scale-[0.97]">
                  <span className="material-symbols-outlined font-black text-[20px]">send</span>
                  Send
                </button>
                <button onClick={() => navigate('/deposit', { state: { asset: data.symbol } })} className="bg-slate-800 hover:bg-slate-700 h-14 rounded-2xl flex items-center justify-center gap-2 font-black text-xs uppercase tracking-widest transition-all active:scale-[0.97] text-white border border-slate-700">
                  <span className="material-symbols-outlined font-black text-[20px]">call_received</span>
                  Receive
                </button>
            </div>

            <div className="w-full mt-8 pt-6 border-t border-slate-800/50">
                <div className="flex justify-between items-center mb-3">
                  <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Protocol Receiver Node</p>
                  {isAddressCopied && <div className="text-green-500 text-[8px] font-black uppercase">Copied!</div>}
                </div>
                <button onClick={handleCopyAddress} className="w-full bg-slate-900/50 border border-slate-800 rounded-2xl p-4 flex items-center justify-between group/address hover:border-primary/40 transition-all">
                  <code className="text-[10px] text-slate-400 font-mono truncate mr-4 uppercase">{isLoading ? 'Scanning...' : data.address}</code>
                  <span className="material-symbols-outlined text-[18px] text-slate-600 group-hover/address:text-primary">content_copy</span>
                </button>
            </div>
          </div>
        </div>

        {/* NEURAL MARKET INSIGHTS SECTION */}
        <section className="bg-card-dark border-2 border-primary/20 rounded-[2.5rem] p-8 shadow-2xl relative overflow-hidden group">
          <div className="absolute -right-4 -top-4 opacity-5 group-hover:rotate-12 transition-transform duration-1000">
             <span className="material-symbols-outlined text-7xl text-primary font-black">psychology</span>
          </div>
          
          <div className="flex items-center gap-4 mb-6 relative z-10">
            <div className="size-12 rounded-2xl bg-primary/10 flex items-center justify-center text-primary border border-primary/20 shadow-inner">
              <span className="material-symbols-outlined text-2xl font-black">monitoring</span>
            </div>
            <div>
              <h3 className="text-sm font-black text-white uppercase tracking-tight italic">Neural Market Insight</h3>
              <p className="text-[9px] font-black text-primary uppercase tracking-widest">Powered by Gemini 3 Pro</p>
            </div>
          </div>

          <div className="relative z-10">
            {isGeneratingAi ? (
              <div className="space-y-4 animate-pulse">
                <div className="h-2.5 w-full bg-slate-800 rounded-full"></div>
                <div className="h-2.5 w-11/12 bg-slate-800 rounded-full"></div>
                <div className="h-2.5 w-4/5 bg-slate-800 rounded-full"></div>
                <p className="text-[8px] text-slate-600 font-black uppercase tracking-widest text-center mt-4">Analizando bloques de mercado...</p>
              </div>
            ) : aiSummary ? (
              <div className="space-y-6 animate-in fade-in duration-500">
                <p className="text-xs text-slate-300 leading-relaxed font-medium italic">
                  {aiSummary}
                </p>
                
                {groundingLinks.length > 0 && (
                  <div className="pt-4 border-t border-slate-800/50 space-y-3">
                    <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest">Nodos de Verdad (Fuentes):</p>
                    <div className="flex flex-wrap gap-2">
                      {groundingLinks.map((link, idx) => (
                        <a 
                          key={idx} 
                          href={link.uri} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="bg-slate-900 hover:bg-primary/10 border border-slate-800 hover:border-primary/50 px-3 py-1.5 rounded-xl text-[9px] font-black text-primary uppercase flex items-center gap-2 transition-all shadow-lg group"
                        >
                          <span className="material-symbols-outlined text-[14px]">link</span>
                          {link.title.slice(0, 20)}...
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <p className="text-[10px] text-slate-500 text-center font-black uppercase tracking-widest py-4">Error al sincronizar con el nodo de IA.</p>
            )}
          </div>
        </section>

        {/* MARKET PERFORMANCE CHART CARD */}
        <div className="bg-card-dark rounded-[2.5rem] border border-slate-800 p-6 space-y-6 shadow-xl relative group">
          <div className="flex justify-between items-center relative z-10">
            <div>
              <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Live Performance</h3>
              <div className="flex items-center gap-2 mt-1">
                <p className="text-xl font-black text-white">{data.price}</p>
                <span className={`text-[11px] font-black px-2 py-0.5 rounded-lg ${data.change.startsWith('+') ? 'text-green-500 bg-green-500/10' : 'text-red-500 bg-red-500/10'}`}>{data.change}</span>
              </div>
            </div>
            <div className="flex flex-col items-end">
               <p className="text-[8px] font-black text-slate-600 uppercase tracking-widest mb-1 italic">H1 Change</p>
               <span className="text-[11px] font-black text-white">{data.perf.h1}</span>
            </div>
          </div>
          
          <div className="relative h-48 w-full touch-none relative z-10" onMouseLeave={() => setScrubIndex(null)}>
            <svg ref={chartRef} viewBox="0 0 300 120" className="w-full h-full overflow-visible" onMouseMove={handleMouseMove}>
              <path d={chartPath} fill="none" stroke="#136dec" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
              {scrubIndex !== null && (
                <line 
                  x1={(scrubIndex / (data.chartPoints.length - 1)) * 300} 
                  y1="0" 
                  x2={(scrubIndex / (data.chartPoints.length - 1)) * 300} 
                  y2="120" 
                  stroke="rgba(19, 109, 236, 0.4)" 
                  strokeWidth="1" 
                  strokeDasharray="4 2" 
                />
              )}
            </svg>
          </div>
          
          <div className="grid grid-cols-2 gap-4 pt-4 relative z-10">
              <div className="bg-slate-900/50 p-4 rounded-2xl border border-white/5">
                 <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest mb-1">High 24h</p>
                 <p className="text-sm font-black text-white font-mono">{data.high24h}</p>
              </div>
              <div className="bg-slate-900/50 p-4 rounded-2xl border border-white/5 text-right">
                 <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest mb-1">Low 24h</p>
                 <p className="text-sm font-black text-white font-mono">{data.low24h}</p>
              </div>
          </div>
        </div>

        {/* PERFORMANCE STATS */}
        <div className="bg-card-dark rounded-[2.5rem] border border-slate-800 p-8 space-y-6 shadow-xl">
           <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Protocol Stats</h3>
           <div className="space-y-5">
              {[
                { label: '7 Day Change', val: data.perf.d7, color: data.perf.d7.startsWith('+') ? 'text-green-500' : 'text-red-500' },
                { label: '30 Day Change', val: data.perf.m1, color: 'text-green-500' },
                { label: '1 Year Return', val: data.perf.y1, color: 'text-green-500' }
              ].map((stat, i) => (
                <div key={i} className="flex justify-between items-center">
                   <p className="text-xs font-black text-slate-300 uppercase tracking-tight">{stat.label}</p>
                   <p className={`text-sm font-black ${stat.color}`}>{stat.val}</p>
                </div>
              ))}
           </div>
        </div>
      </div>
    </Layout>
  );
};

export default WalletDetail;
