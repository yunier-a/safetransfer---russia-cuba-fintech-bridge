
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Layout } from '../components/Layout';

interface Node {
  id: string;
  name: string;
  type: 'BANK' | 'P2P';
  identifier: string; // Card or @Handle
  avatar: string;
  lastTransfer: string;
}

const Beneficiaries: React.FC = () => {
  const navigate = useNavigate();
  const [nodes, setNodes] = useState<Node[]>([
    { id: '1', name: 'Maria Gonzalez', type: 'P2P', identifier: '@mariacuba', avatar: 'https://i.pravatar.cc/150?u=maria', lastTransfer: 'Oct 24, 2024' },
    { id: '2', name: 'Juan Perez', type: 'BANK', identifier: '9200...4491', avatar: 'https://i.pravatar.cc/150?u=juan', lastTransfer: 'Oct 21, 2024' },
    { id: '3', name: 'Leticia Diaz', type: 'P2P', identifier: '@letidiaz', avatar: 'https://i.pravatar.cc/150?u=leti', lastTransfer: 'Oct 15, 2024' }
  ]);

  const handleSend = (node: Node) => {
    navigate('/send', { 
      state: { 
        recipient: { 
          name: node.name, 
          account: node.type === 'BANK' ? node.identifier : '', 
          handle: node.type === 'P2P' ? node.identifier : '',
          phone: ''
        } 
      } 
    });
  };

  return (
    <Layout hideNav>
      <header className="flex items-center px-4 py-6 justify-between bg-background-dark sticky top-0 z-50 border-b border-slate-800/50 backdrop-blur-md">
        <button onClick={() => navigate(-1)} className="flex items-center justify-center w-10 h-10 rounded-full hover:bg-slate-800 transition-colors">
          <span className="material-symbols-outlined text-white">arrow_back_ios_new</span>
        </button>
        <div className="text-center">
          <h2 className="text-lg font-bold text-white tracking-tight">Node Vault</h2>
          <p className="text-[9px] font-black text-primary uppercase tracking-widest">Beneficiary Inventory</p>
        </div>
        <button className="size-10 flex items-center justify-center bg-primary/10 rounded-xl text-primary border border-primary/20">
          <span className="material-symbols-outlined">person_add</span>
        </button>
      </header>

      <main className="p-6 space-y-6">
        <div className="relative">
          <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 text-[20px]">search</span>
          <input 
            type="text" 
            placeholder="Search saved nodes..." 
            className="w-full bg-card-dark border border-slate-800 rounded-2xl py-4 pl-12 pr-4 text-sm text-white focus:border-primary transition-all outline-none"
          />
        </div>

        <div className="space-y-4">
          <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-1">Registered Secure Nodes</h3>
          <div className="space-y-3">
            {nodes.map(node => (
              <div key={node.id} className="bg-card-dark border border-slate-800 rounded-3xl p-5 flex items-center justify-between group hover:border-primary/30 transition-all">
                <div className="flex items-center gap-4">
                  <div className="size-14 rounded-full p-0.5 border-2 border-primary/20">
                    <img src={node.avatar} className="size-full rounded-full object-cover" alt={node.name} />
                  </div>
                  <div>
                    <h4 className="font-black text-white text-base tracking-tight leading-none mb-1">{node.name}</h4>
                    <div className="flex items-center gap-2">
                      <span className={`text-[8px] font-black px-1.5 py-0.5 rounded uppercase ${node.type === 'P2P' ? 'bg-primary/20 text-primary' : 'bg-slate-800 text-slate-400'}`}>
                        {node.type}
                      </span>
                      <span className="text-[10px] text-slate-500 font-mono">{node.identifier}</span>
                    </div>
                  </div>
                </div>
                <button 
                  onClick={() => handleSend(node)}
                  className="size-11 rounded-xl bg-slate-800 flex items-center justify-center text-slate-400 group-hover:bg-primary group-hover:text-white transition-all active:scale-90"
                >
                  <span className="material-symbols-outlined text-[20px]">send</span>
                </button>
              </div>
            ))}
          </div>
        </div>

        <button className="w-full py-8 border-2 border-dashed border-slate-800 rounded-[2.5rem] flex flex-col items-center justify-center gap-3 text-slate-600 hover:text-primary hover:border-primary/50 transition-all group">
           <span className="material-symbols-outlined text-4xl group-hover:scale-110 transition-transform">add_circle</span>
           <span className="text-[11px] font-black uppercase tracking-widest">Initialize New Secure Node</span>
        </button>
      </main>
    </Layout>
  );
};

export default Beneficiaries;
