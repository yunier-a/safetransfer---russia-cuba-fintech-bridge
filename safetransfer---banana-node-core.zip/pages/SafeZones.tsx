
import React, { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Layout } from '../components/Layout';
import { getMapsIntelligence } from '../services/geminiService';

interface SafeZone {
  id: string;
  name: string;
  radius: number;
  location: string;
  timestamp: string;
}

const SafeZones: React.FC = () => {
  const navigate = useNavigate();
  const [locationStatus, setLocationStatus] = useState('Esperando Señal...');
  const [currentCoords, setCurrentCoords] = useState<{lat: number, lng: number} | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [isLocating, setIsLocating] = useState(false);
  const [scanResult, setScanResult] = useState<{ text: string, links: any[] } | null>(null);
  
  // Load zones from localStorage on mount
  const [zones, setZones] = useState<SafeZone[]>(() => {
    const saved = localStorage.getItem('st_safe_zones');
    return saved ? JSON.parse(saved) : [
      { id: '1', name: 'Nodo Principal - Vedado', radius: 850, location: '23.1330, -82.3833', timestamp: new Date().toISOString() }
    ];
  });

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newName, setNewName] = useState('');
  const [newRadius, setNewRadius] = useState(500);

  // Save zones whenever they change
  useEffect(() => {
    localStorage.setItem('st_safe_zones', JSON.stringify(zones));
  }, [zones]);

  const detectLocation = useCallback(() => {
    if (!("geolocation" in navigator)) {
      setLocationStatus('GPS No Soportado');
      return;
    }

    setIsLocating(true);
    setLocationStatus('Sincronizando Satélites...');

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const lat = position.coords.latitude;
        const lng = position.coords.longitude;
        setCurrentCoords({ lat, lng });
        setLocationStatus(`Sincronizado: ${lat.toFixed(6)}, ${lng.toFixed(6)}`);
        setIsLocating(false);
      },
      (error) => {
        console.error("Geolocation Error:", error);
        let errorMsg = 'Fallo de Señal';
        if (error.code === 1) errorMsg = 'Permiso Denegado';
        else if (error.code === 2) errorMsg = 'Posición No Disponible';
        else if (error.code === 3) errorMsg = 'Tiempo Agotado';
        
        setLocationStatus(errorMsg);
        setIsLocating(false);
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
    );
  }, []);

  useEffect(() => {
    detectLocation();
  }, [detectLocation]);

  const runLocationScan = async () => {
    if (!currentCoords) return;
    setIsScanning(true);
    setScanResult(null);
    
    try {
      const prompt = `Evalúa la seguridad financiera de la ubicación actual. Encuentra 3 bancos o cajeros cercanos donde un usuario pueda retirar remesas de forma segura. Menciona nombres y detalles. Ubicación aproximada: ${currentCoords.lat}, ${currentCoords.lng}.`;
      const result = await getMapsIntelligence(prompt, currentCoords.lat, currentCoords.lng);
      
      const links = result.groundingChunks
        .filter((chunk: any) => chunk.maps)
        .map((chunk: any) => ({
          title: chunk.maps.title,
          uri: chunk.maps.uri
        }));

      setScanResult({
        text: result.text,
        links: links
      });
    } catch (err) {
      console.error(err);
    } finally {
      setIsScanning(false);
    }
  };

  const handleAddZone = () => {
    if (!newName.trim()) return;
    
    const newZone: SafeZone = {
      id: Date.now().toString(),
      name: newName,
      radius: newRadius,
      location: currentCoords ? `${currentCoords.lat.toFixed(4)}, ${currentCoords.lng.toFixed(4)}` : 'Entrada Manual',
      timestamp: new Date().toISOString()
    };

    setZones([newZone, ...zones]);
    setNewName('');
    setNewRadius(500);
    setIsModalOpen(false);
  };

  const removeZone = (id: string) => {
    setZones(zones.filter(z => z.id !== id));
  };

  return (
    <Layout hideNav>
      <header className="p-6 pt-10 border-b border-slate-800 bg-background-dark/95 backdrop-blur-md sticky top-0 z-50">
        <div className="flex items-center justify-between mb-2">
          <button onClick={() => navigate(-1)} className="size-11 flex items-center justify-center rounded-2xl bg-slate-800/50 hover:bg-slate-800 transition-all active:scale-90 text-white">
            <span className="material-symbols-outlined text-[20px]">arrow_back_ios_new</span>
          </button>
          <div className="text-center">
            <h2 className="text-xl font-black text-white uppercase tracking-tighter italic">Geofencing de Red</h2>
            <p className="text-[10px] font-black text-primary uppercase tracking-[0.2em] mt-0.5">Global Position Registry</p>
          </div>
          <div className="size-11"></div>
        </div>
      </header>
      
      <div className="p-6 space-y-8 pb-40 animate-in fade-in duration-500">
        
        {/* LIVE LOCATION CARD */}
        <section className="bg-card-dark border border-slate-800 rounded-[2.5rem] p-8 space-y-6 shadow-2xl relative overflow-hidden group">
          <div className="flex justify-between items-start relative z-10">
             <div className="flex flex-col">
                <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Nodo de Ubicación Vivo</h3>
                <div className="flex items-center gap-2">
                   <div className={`size-2 rounded-full ${isLocating ? 'bg-primary animate-ping' : currentCoords ? 'bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.6)]' : 'bg-red-500'}`}></div>
                   <span className={`text-xs font-black uppercase tracking-tight ${isLocating ? 'text-primary' : currentCoords ? 'text-white' : 'text-red-500'}`}>
                      {locationStatus}
                   </span>
                </div>
             </div>
             <div className="flex items-center gap-2 bg-slate-900/80 px-3 py-1.5 rounded-full border border-white/5">
                <span className="text-[8px] font-black text-slate-500 uppercase">Hardware:</span>
                <span className="text-[8px] font-black text-green-500 uppercase">Online</span>
             </div>
          </div>

          {currentCoords && (
            <div className="grid grid-cols-2 gap-4 pt-4 relative z-10 animate-in slide-in-from-top-2">
               <div className="bg-slate-950/50 p-5 rounded-2xl border border-white/5 shadow-inner group/coord">
                  <p className="text-[8px] font-black text-slate-600 uppercase tracking-widest mb-1 group-hover/coord:text-primary transition-colors">Latitud</p>
                  <p className="text-base font-mono font-black text-white">{currentCoords.lat.toFixed(6)}</p>
               </div>
               <div className="bg-slate-950/50 p-5 rounded-2xl border border-white/5 shadow-inner group/coord">
                  <p className="text-[8px] font-black text-slate-600 uppercase tracking-widest mb-1 group-hover/coord:text-primary transition-colors">Longitud</p>
                  <p className="text-base font-mono font-black text-white">{currentCoords.lng.toFixed(6)}</p>
               </div>
            </div>
          )}

          <div className="pt-2 relative z-10">
            <button 
                onClick={detectLocation}
                disabled={isLocating}
                className={`w-full py-5 rounded-[1.5rem] flex items-center justify-center gap-3 transition-all shadow-xl active:scale-95 ${isLocating ? 'bg-slate-800 text-slate-600 cursor-not-allowed' : 'bg-primary text-white hover:bg-blue-600 shadow-primary/20'}`}
            >
                <span className={`material-symbols-outlined text-xl font-black ${isLocating ? 'animate-spin' : ''}`}>sync</span>
                <span className="text-[10px] font-black uppercase tracking-[0.2em]">Re-detectar Ubicación</span>
            </button>
          </div>

          <div className="absolute -bottom-10 -right-10 opacity-[0.03] group-hover:rotate-12 transition-transform duration-1000">
             <span className="material-symbols-outlined text-[150px]">radar</span>
          </div>
        </section>

        {/* MAP DISPLAY AREA */}
        <section className="space-y-4">
          <div className="flex justify-between items-center px-1">
             <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Visualización Satelital</h3>
             {currentCoords && (
                <button 
                  onClick={runLocationScan}
                  disabled={isScanning}
                  className="flex items-center gap-2 bg-primary/10 px-4 py-1.5 rounded-full border border-primary/20 text-primary text-[9px] font-black uppercase tracking-widest hover:bg-primary/20 transition-all"
                >
                   {isScanning ? 'Procesando Scan...' : 'Escaneo AI de Seguridad'}
                   <span className="material-symbols-outlined text-[14px]">psychology</span>
                </button>
             )}
          </div>

          <div className="relative w-full aspect-[4/3] rounded-[3rem] overflow-hidden shadow-2xl border-2 border-slate-800 group bg-slate-900">
            {/* Background Placeholder Map */}
            <div className={`absolute inset-0 bg-center bg-cover transition-all duration-1000 grayscale opacity-30 group-hover:opacity-50 ${isLocating ? 'blur-sm scale-110' : ''}`} 
              style={{backgroundImage: 'url("https://picsum.photos/seed/mapnode/800/600")'}}>
            </div>
            
            {/* Overlay Grid */}
            <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:30px_30px]"></div>

            <div className="absolute inset-0 flex items-center justify-center">
              <div className="relative">
                <div className={`absolute -inset-16 bg-primary/10 rounded-full border border-primary/20 animate-pulse-slow ${isLocating ? 'scale-150 opacity-0 transition-all duration-1000' : ''}`}></div>
                <div className="relative bg-primary p-6 rounded-[2rem] border-4 border-white/10 shadow-[0_0_50px_rgba(19,109,236,0.4)] z-10 transition-transform active:scale-90 group-hover:scale-110 duration-500">
                  <span className="material-symbols-outlined text-white text-4xl font-black">my_location</span>
                </div>
              </div>
            </div>

            <div className="absolute top-6 left-6 flex items-center gap-2 bg-background-dark/80 backdrop-blur-xl px-4 py-2 rounded-full border border-white/10 shadow-lg">
               <div className="size-1.5 bg-green-500 rounded-full animate-pulse"></div>
               <span className="text-[8px] font-black text-white uppercase tracking-[0.2em] font-mono">GPS_HARDWARE_LOCK</span>
            </div>
          </div>
        </section>

        {/* AI Scan Result (Maps Grounding) */}
        {scanResult && (
          <section className="bg-card-dark border border-primary/30 rounded-[2.5rem] p-8 space-y-5 animate-in slide-in-from-top-4 duration-500 shadow-2xl relative overflow-hidden group">
            <div className="flex items-center gap-4 relative z-10">
              <div className="size-12 rounded-2xl flex items-center justify-center bg-primary/10 text-primary border border-primary/20">
                <span className="material-symbols-outlined text-2xl font-black">assistant</span>
              </div>
              <div>
                <h3 className="text-sm font-black text-white uppercase tracking-tight">Reporte de Seguridad Local</h3>
                <p className="text-[9px] font-black text-primary uppercase tracking-widest">Maps Intelligence Pro</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed font-medium italic relative z-10">
              {scanResult.text}
            </p>

            {scanResult.links.length > 0 && (
              <div className="pt-5 border-t border-slate-800 space-y-3 relative z-10">
                <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Nodos Verificados en Perímetro:</p>
                <div className="grid grid-cols-1 gap-2">
                  {scanResult.links.map((link, idx) => (
                    <a 
                      key={idx} 
                      href={link.uri} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="flex items-center justify-between bg-slate-900/50 hover:bg-primary/10 border border-slate-800 hover:border-primary/50 px-5 py-4 rounded-2xl transition-all group/link shadow-lg"
                    >
                      <div className="flex items-center gap-3">
                        <span className="material-symbols-outlined text-slate-600 group-hover/link:text-primary transition-colors">location_on</span>
                        <span className="text-[10px] font-black text-white tracking-tight uppercase truncate max-w-[180px]">{link.title}</span>
                      </div>
                      <span className="material-symbols-outlined text-slate-700 text-sm">open_in_new</span>
                    </a>
                  ))}
                </div>
              </div>
            )}
          </section>
        )}
        
        {/* REGISTERED NODES LIST */}
        <section className="space-y-4">
          <div className="flex justify-between items-center px-1">
            <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Nodos de Confianza Registrados</h3>
            <span className="text-[9px] font-black text-primary uppercase">{zones.length} Activos</span>
          </div>
          <div className="grid grid-cols-1 gap-4">
            {zones.map(zone => (
              <div key={zone.id} className="bg-card-dark rounded-[2.5rem] border border-slate-800 p-7 space-y-1 group hover:border-primary/30 transition-all shadow-xl relative overflow-hidden">
                <div className="flex items-center justify-between relative z-10">
                  <div className="flex items-center gap-5">
                    <div className="size-14 rounded-2xl bg-slate-800 flex items-center justify-center text-slate-500 group-hover:bg-primary group-hover:text-white transition-all shadow-inner">
                      <span className="material-symbols-outlined text-3xl">{zone.name.toLowerCase().includes('nodo') ? 'hub' : 'home'}</span>
                    </div>
                    <div>
                      <p className="font-black text-white text-base uppercase tracking-tight">{zone.name}</p>
                      <p className="text-[9px] text-slate-500 font-mono mt-1 tracking-widest uppercase bg-slate-950 px-2 py-0.5 rounded border border-white/5">{zone.location}</p>
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    <div className="text-right">
                      <p className="text-xl font-black text-primary tracking-tighter">{zone.radius}m</p>
                      <p className="text-[8px] text-slate-500 uppercase font-black tracking-widest">Umbral</p>
                    </div>
                    {zone.id !== '1' && (
                      <button onClick={() => removeZone(zone.id)} className="text-red-500/50 hover:text-red-500 transition-colors">
                        <span className="material-symbols-outlined text-sm">delete</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
        
        {/* PROTOCOL WARNING */}
        <section className="bg-amber-500/5 border border-amber-500/20 rounded-[2.5rem] p-8 flex gap-6 items-start shadow-inner">
          <div className="size-14 rounded-3xl bg-amber-500/10 flex items-center justify-center text-amber-500 shrink-0 border border-amber-500/10">
            <span className="material-symbols-outlined font-black text-3xl">gpp_maybe</span>
          </div>
          <p className="text-[10px] text-slate-400 leading-relaxed font-bold uppercase tracking-tight">
            <span className="text-amber-500 font-black">Aviso de Protocolo:</span> Toda operación iniciada fuera de un Nodo de Confianza activará un retardo de auditoría y requerirá validación biométrica de hardware.
          </p>
        </section>

        <button 
          onClick={() => setIsModalOpen(true)}
          className="w-full py-9 border-2 border-dashed border-slate-800 rounded-[3rem] text-slate-600 font-black text-[12px] uppercase tracking-[0.25em] hover:border-primary/50 hover:text-primary hover:bg-primary/5 transition-all flex items-center justify-center gap-5 active:scale-[0.98]"
        >
          <span className="material-symbols-outlined text-[28px] font-black">add_circle</span>
          Provisionar Nuevo Nodo
        </button>
      </div>

      {/* REGISTER ZONE MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-end justify-center px-4 pb-12">
          <div className="absolute inset-0 bg-background-dark/95 backdrop-blur-md animate-in fade-in duration-300" onClick={() => setIsModalOpen(false)}></div>
          <div className="relative w-full max-w-[420px] bg-card-dark rounded-[4rem] border border-slate-800 shadow-2xl p-12 animate-in slide-in-from-bottom duration-500">
            <div className="flex justify-between items-center mb-10">
              <div>
                <h3 className="text-2xl font-black text-white uppercase tracking-tight italic">Provisionar Nodo</h3>
                <p className="text-[10px] font-black text-primary uppercase tracking-widest mt-1">Sincronización GPS Local</p>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="size-12 flex items-center justify-center rounded-full bg-slate-800 text-slate-500 hover:text-white transition-colors">
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>
            
            <div className="space-y-10">
              <div className="space-y-4">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-4">Identificador de Zona</label>
                <input 
                  type="text" 
                  placeholder="E.g., Oficina HQ, Bóveda Hogar"
                  className="w-full bg-slate-900 border border-slate-800 rounded-[2rem] px-8 py-6 text-sm text-white placeholder:text-slate-800 focus:border-primary outline-none transition-all shadow-inner uppercase font-black tracking-tight"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  autoFocus
                />
              </div>

              <div className="space-y-6">
                <div className="flex justify-between px-4">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Radio del Geofence</label>
                  <span className="text-[11px] font-black text-primary uppercase tracking-tighter">{newRadius} METROS</span>
                </div>
                <input 
                  type="range" 
                  min="100" 
                  max="5000" 
                  step="50"
                  className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-primary"
                  value={newRadius}
                  onChange={(e) => setNewRadius(parseInt(e.target.value))}
                />
                <div className="flex justify-between text-[9px] text-slate-700 font-black uppercase tracking-widest px-2">
                  <span>100m (Alta Sec)</span>
                  <span>5km (Área)</span>
                </div>
              </div>

              <div className="bg-primary/5 rounded-[2rem] p-8 border border-primary/10 flex items-center gap-6 shadow-inner">
                <div className="size-12 bg-primary/20 rounded-2xl flex items-center justify-center text-primary animate-pulse shadow-lg">
                  <span className="material-symbols-outlined font-black text-2xl">my_location</span>
                </div>
                <div className="flex-1">
                   <p className="text-[10px] text-slate-400 font-bold leading-relaxed uppercase tracking-tight">
                    Vinculación a coordenadas hardware <span className="text-white">({currentCoords?.lat.toFixed(4) || 'SCANNING...'})</span>.
                  </p>
                </div>
              </div>

              <button 
                onClick={handleAddZone}
                disabled={!newName.trim() || !currentCoords}
                className={`w-full py-8 rounded-[2.5rem] font-black text-sm uppercase tracking-[0.25em] transition-all shadow-2xl flex items-center justify-center gap-5 ${
                  newName.trim() && currentCoords
                    ? 'bg-primary text-white hover:bg-blue-600 shadow-primary/30' 
                    : 'bg-slate-800 text-slate-600 cursor-not-allowed opacity-40'
                }`}
              >
                <span>Autorizar Nodo</span>
                <span className="material-symbols-outlined text-2xl font-black">verified_user</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
};

export default SafeZones;
