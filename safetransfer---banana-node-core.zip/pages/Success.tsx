
import React, { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Layout } from '../components/Layout';
import { NotificationService } from '../services/notificationService';
import { AudioService } from '../services/audioService';

const Success: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const state = location.state as { 
    recipient: string, 
    purpose?: string, 
    memo?: string, 
    amount?: number, 
    currency?: string,
    type?: string 
  } | null;

  const [adminLink, setAdminLink] = useState<string>('');
  const [txRef, setTxRef] = useState<string>('');
  const [isAlertGenerated, setIsAlertGenerated] = useState(false);

  useEffect(() => {
    // Sonido de éxito al entrar
    AudioService.playSuccess();

    const generateAdminAlert = async () => {
      const result = await NotificationService.notifyAdmin(state?.type || 'General Transaction', {
        recipient: state?.recipient || 'Unknown Terminal',
        amount: state?.amount || 0,
        currency: state?.currency || 'RUB',
        memo: state?.memo || state?.purpose || 'No memo'
      });
      setAdminLink(result.whatsappLink);
      setTxRef(result.txId);
      setIsAlertGenerated(true);
    };
    generateAdminAlert();
  }, [state]);

  const recipientName = state?.recipient || "Terminal de Red";
  const isDeposit = state?.type?.toLowerCase().includes('deposit');

  return (
    <Layout hideNav>
      <div className="flex-1 flex flex-col items-center justify-center px-6 pt-20 h-full animate-in fade-in zoom-in duration-500">
        <div className="w-24 h-24 bg-green-500/10 rounded-full flex items-center justify-center mb-8 relative">
          <div className="absolute inset-0 bg-green-500/20 rounded-full animate-ping"></div>
          <span className="material-symbols-outlined text-green-500 text-6xl relative z-10" style={{fontVariationSettings: "'FILL' 1"}}>check_circle</span>
        </div>
        
        <h2 className="text-3xl font-black text-white tracking-tighter mb-2 text-center uppercase italic">¡Éxito Atómico!</h2>
        <p className="text-slate-400 mb-10 text-center text-sm font-medium leading-relaxed max-w-[280px]">
          {isDeposit 
            ? `El depósito ha sido registrado en el nodo. El administrador ha sido notificado para su validación.`
            : `Los fondos han sido procesados y el nodo de destino está en espera de liquidación final.`
          }
        </p>
        
        <div className="w-full bg-card-dark rounded-3xl p-6 mb-8 border border-slate-800 shadow-2xl space-y-4 relative overflow-hidden group">
          <div className="absolute top-0 right-0 bg-primary/10 px-3 py-1 rounded-bl-xl text-[8px] font-black uppercase tracking-widest">SafeNode Receipt</div>
          <div className="absolute -bottom-10 -left-10 opacity-5 group-hover:rotate-12 transition-transform duration-1000">
             <span className="material-symbols-outlined text-[100px]">{isDeposit ? 'account_balance' : 'payments'}</span>
          </div>
          
          <div className="flex justify-between items-center pb-4 border-b border-slate-800/50 relative z-10">
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Referencia de Nodo</span>
            <span className="text-xs font-mono font-bold text-primary bg-primary/10 px-2 py-1 rounded">#{txRef || 'SYNCING...'}</span>
          </div>
          
          <div className="flex justify-between items-center relative z-10">
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Liquidación</span>
            <span className="text-xs font-bold text-white uppercase tracking-widest">
              {state?.amount ? `${state.amount.toLocaleString()} ${state.currency}` : 'Protocolo Estándar'}
            </span>
          </div>

          <div className="flex justify-between items-center pt-4 border-t border-slate-800/50 relative z-10">
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Canal de Alerta</span>
            <div className="flex items-center gap-2">
              <span className="size-2 bg-green-500 rounded-full animate-pulse shadow-[0_0_8px_#22c55e]"></span>
              <span className="text-xs font-bold text-green-500 uppercase">Admin Notificado</span>
            </div>
          </div>
        </div>
        
        <div className="mt-auto mb-10 w-full space-y-3 px-2">
            <div className="bg-primary/5 border border-primary/20 rounded-2xl p-4 mb-4">
              <p className="text-[9px] text-center text-slate-500 font-black uppercase tracking-widest leading-relaxed">
                Para acelerar el proceso, envíe el comprobante al administrador vía WhatsApp.
              </p>
            </div>

            <a 
                href={adminLink}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => AudioService.playClick()}
                className={`w-full py-6 rounded-[1.5rem] font-black uppercase tracking-[0.2em] text-[12px] flex items-center justify-center gap-4 transition-all active:scale-95 shadow-2xl ${isAlertGenerated ? 'bg-green-600 hover:bg-green-500 text-white shadow-green-500/30' : 'bg-slate-800 text-slate-500 pointer-events-none'}`}
            >
                <span className="material-symbols-outlined font-black text-2xl">chat</span>
                {isAlertGenerated ? 'Reportar a Admin (+1...)' : 'Sincronizando Alerta...'}
            </a>

            <div className="grid grid-cols-2 gap-3">
              <button 
                  onClick={() => {
                      AudioService.playClick();
                      const text = `SafeTransfer: ¡Éxito! Operación de ${state?.amount} ${state?.currency} enviada a ${recipientName}. Ref: #${txRef}`;
                      window.open(`https://wa.me/?text=${encodeURIComponent(text)}`);
                  }}
                  className="bg-slate-800 hover:bg-slate-700 text-white py-5 rounded-[1.5rem] font-black uppercase tracking-[0.15em] text-[10px] border border-slate-700 flex items-center justify-center gap-2 transition-all active:scale-95"
              >
                  <span className="material-symbols-outlined text-[18px]">share</span>
                  Compartir
              </button>
              <button 
                onClick={() => { AudioService.playClick(); navigate('/'); }} 
                className="bg-primary hover:bg-blue-600 text-white py-5 rounded-[1.5rem] font-black uppercase tracking-[0.15em] text-[10px] shadow-xl shadow-primary/20 transition-all active:scale-95 flex items-center justify-center gap-2"
              >
                <span className="material-symbols-outlined text-[18px]">home</span>
                Ir al Hub
              </button>
            </div>
        </div>
      </div>
    </Layout>
  );
};

export default Success;
