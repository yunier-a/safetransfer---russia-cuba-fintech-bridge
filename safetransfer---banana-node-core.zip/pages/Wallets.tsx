
import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Layout } from '../components/Layout';
import { supabase } from '../services/supabase';
import { getMarketUpdate, getBotResponse } from '../services/geminiService';

const Wallets: React.FC = () => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [userWallets, setUserWallets] = useState<any[]>([]);
  const [totalBalanceRUB, setTotalBalanceRUB] = useState(0);
  const [aiInsight, setAiInsight] = useState<string | null>(null);

  const assetMetadata: Record<string, any> = {
    'RUB': { name: 'Ruble Ruso', icon: 'currency_ruble', logo: 'https://flagcdn.com/ru.svg', network: 'MIR / SBP Node' },
    'CUP': { name: 'Peso Cubano', icon: 'payments', logo: 'https://flagcdn.com/cu.svg', network: 'BANDEC / METRO Node' },
    'USDT': { name: 'Tether', icon: 'attach_money', logo: 'https://raw.githubusercontent.com/spothq/cryptocurrency-icons/master/128/color/usdt.png', network: 'TRC-20 Node' }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setIsLoading(true);
    
    // RETRASO FORZADO: 1.5 segundos para simular latencia bancaria real
    const delay = new Promise(resolve => setTimeout(resolve, 1500));
    
    const operation = (async () => {
      const { data: { session } } = await supabase.auth.getSession();
      const market = await getMarketUpdate();

      let balances = [];
      if (session) {
        const { data } = await supabase.from('wallet_balances').select('*').eq('user_id', session.user.id);
        balances = data || [];
      } else {
        balances = [
          { id: '1', asset: 'RUB', balance: '25450.00' },
          { id: '2', asset: 'CUP', balance: '1280.50' },
          { id: '3', asset: 'USDT', balance: '450.00' }
        ];
      }

      const enriched = balances.map(w => {
        const meta = assetMetadata[w.asset] || { name: w.asset, logo: '', network: 'Protocol' };
        let rubVal = parseFloat(w.balance);
        if (market?.rates) {
          if (w.asset === 'USDT') rubVal *= market.rates.USD_RUB;
          if (w.asset === 'CUP') rubVal /= market.rates.RUB_CUP;
        }
        return { ...w, rubValue: rubVal, meta };
      });

      setUserWallets(enriched);
      setTotalBalanceRUB(enriched.reduce((acc, curr) => acc + curr.rubValue, 0));
    })();

    await Promise.all([delay, operation]);
    setIsLoading(false);
  };

  return (
    <Layout hideNav>
      <header className="flex items-center p-4 pt-10 bg-background-dark/95 sticky top-0 z-50 backdrop-blur-md border-b border-slate-800 justify-between">
        <button onClick={() => navigate(-1)} className="size-11 flex items-center justify-center rounded-2xl bg-slate-800/50 hover:bg-slate-800 transition-all text-white">
          <span className="material-symbols-outlined text-[20px]">arrow_back_ios_new</span>
        </button>
        <div className="text-center">
            <h1 className="text-xl font-black text-white uppercase tracking-tighter italic">Nodos de Activos</h1>
            <p className="text-[10px] font-black text-primary uppercase tracking-[0.25em]">Sincronización Bancaria</p>
        </div>
        <button onClick={fetchData} className={`size-11 flex items-center justify-center rounded-2xl bg-primary/10 text-primary ${isLoading ? 'animate-spin' : ''}`}>
          <span className="material-symbols-outlined">sync</span>
        </button>
      </header>

      <div className="p-4 space-y-8 pb-40 animate-in fade-in duration-700">
        <section className="bg-gradient-to-br from-slate-900 to-background-dark rounded-[3rem] border border-white/10 p-10 shadow-2xl relative overflow-hidden">
            <div className="relative z-10 space-y-4">
                <p className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-500">Liquidez Global Estimada</p>
                <div className="flex items-baseline gap-3">
                    <span className="text-primary text-3xl font-black">₽</span>
                    <h2 className="text-6xl font-black text-white tracking-tighter">
                      {isLoading ? '---' : totalBalanceRUB.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                    </h2>
                </div>
            </div>
        </section>

        <div className="space-y-6">
            <div className="space-y-5">
                {isLoading ? (
                   [1, 2, 3].map(i => (
                     <div key={i} className="bg-card-dark border border-slate-800 rounded-[3rem] p-8 shadow-2xl animate-pulse">
                        <div className="flex items-center gap-6">
                            <div className="size-16 rounded-[1.5rem] bg-slate-800"></div>
                            <div className="flex-1 space-y-2">
                                <div className="h-4 w-24 bg-slate-800 rounded"></div>
                                <p className="text-primary text-[10px] font-black uppercase tracking-widest">Loading balance...</p>
                            </div>
                        </div>
                     </div>
                   ))
                ) : (
                  userWallets.map((wallet) => (
                    <div 
                      key={wallet.id} 
                      className="bg-card-dark border border-slate-800 rounded-[3rem] p-8 group hover:border-primary/40 transition-all cursor-pointer shadow-2xl relative overflow-hidden active:scale-[0.98]"
                      onClick={() => navigate(`/wallets/${wallet.asset.toLowerCase()}`)}
                    >
                        <div className="flex items-center gap-6 relative z-10">
                            <div className={`size-16 rounded-[1.5rem] bg-slate-950 flex items-center justify-center border border-white/5`}>
                                <img src={wallet.meta.logo} className={`w-9 h-9 object-contain`} alt={wallet.asset} />
                            </div>
                            
                            <div className="flex-1 min-w-0">
                                <div className="flex justify-between items-start mb-1">
                                    <div>
                                      <h4 className="text-lg font-black text-white uppercase truncate tracking-tight">{wallet.meta.name}</h4>
                                      <p className="text-[9px] text-slate-500 font-black uppercase tracking-widest mt-1">{wallet.meta.network}</p>
                                    </div>
                                    <div className="text-right">
                                      <p className="text-2xl font-black text-white tracking-tighter">{wallet.balance} <span className="text-[10px] text-slate-500">{wallet.asset}</span></p>
                                      <p className="text-[10px] text-slate-500 font-black tracking-widest mt-0.5">≈ {wallet.rubValue.toLocaleString(undefined, { maximumFractionDigits: 2 })} ₽</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                  ))
                )}
            </div>
        </div>
      </div>
    </Layout>
  );
};

export default Wallets;
