
export const AudioService = {
  sounds: {
    success: 'https://assets.mixkit.co/active_storage/sfx/2013/2013-preview.mp3',
    click: 'https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3',
    messageSent: 'https://assets.mixkit.co/active_storage/sfx/2354/2354-preview.mp3',
    notification: 'https://assets.mixkit.co/active_storage/sfx/2358/2358-preview.mp3',
    scan: 'https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3'
  },

  play(soundName: keyof typeof AudioService.sounds) {
    try {
      const audio = new Audio(this.sounds[soundName]);
      audio.volume = 0.4;
      audio.play().catch(e => console.debug("Audio play blocked by browser policy"));
    } catch (error) {
      console.error("Audio error:", error);
    }
  },

  playSuccess() { this.play('success'); },
  playClick() { this.play('click'); },
  playMessageSent() { this.play('messageSent'); },
  playNotification() { this.play('notification'); },
  playScan() { this.play('scan'); }
};
