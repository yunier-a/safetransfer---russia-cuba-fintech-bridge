
import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Layout } from '../components/Layout';
import { supabase } from '../services/supabase';
import { AudioService } from '../services/audioService';

const ConfirmTransfer: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const state = location.state as { 
    amount: number; 
    asset: string;
    total: number;
    commission: number;
    paymentSource: 'BALANCE' | 'CARD';
    selectedCard?: any;
    targetAsset: string;
    receivedAmount: string; 
    recipient: any;
  } | null;

  if (!state) return <Layout>Error: No hay datos de sesión disponibles.</Layout>;

  const handleConfirm = async () => {
    // Sonido de autorización/escaneo
    AudioService.playScan();
    setIsSubmitting(true);
    
    const { data: { session } } = await supabase.auth.getSession();
    
    if (!session) { navigate('/login'); return; }

    const { error } = await supabase.from('transactions').insert({
      user_id: session.user.id,
      recipient: state.recipient.name,
      amount: state.amount,
      currency: state.asset,
      fee: state.commission.toFixed(2),
      type: 'Remittance',
      status: 'SUCCESS',
      account: state.recipient.account,
      network: state.paymentSource === 'CARD' ? `Direct Card Settle (${state.selectedCard?.brand})` : 'Node Balance Bridge',
      memo: `Propósito: ${state.recipient.purpose} | Recibe: ${state.receivedAmount} ${state.targetAsset} | Fuente: ${state.paymentSource}`,
      node_id: session.user.id.slice(0, 8).toUpperCase()
    });

    if (error) {
      alert(`Error de Red: ${error.message}`);
      setIsSubmitting(false);
    } else {
      navigate('/success', { state: { ...state, type: 'Transferencia Exitosa' } });
    }
  };

  return (
    <Layout hideNav>
      <header className="flex items-center p-4 pt-10 pb-2 justify-between sticky top-0 bg-background-dark/80 backdrop-blur-md z-10 border-b border-white/5">
        <button onClick={() => { AudioService.playClick(); navigate(-1); }} className="size-11 flex items-center justify-center rounded-2xl bg-slate-800/50 hover:bg-slate-800 transition-all text-white">
          <span className="material-symbols-outlined text-[20px]">arrow_back_ios_new</span>
        </button>
        <div className="text-center flex-1">
          <h2 className="text-lg font-black text-white uppercase italic tracking-tighter">Autorizar Operación</h2>
          <p className="text-[9px] font-black text-primary uppercase tracking-[0.2em] mt-0.5">Secure Settle Protocol</p>
        </div>
        <div className="size-11"></div>
      </header>
      
      <div className="px-4 mt-6 pb-40 animate-in fade-in duration-700">
        <div className="bg-card-dark rounded-[3.5rem] p-10 mb-8 border border-slate-800 shadow-2xl relative overflow-hidden group">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-primary/5 via-transparent to-transparent"></div>
          
          <div className="flex flex-col items-center mb-10 relative z-10">
            <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] mb-4">Total a Debitar</p>
            <div className="flex items-baseline gap-3">
              <span className="text-6xl font-black text-white tracking-tighter">{state.total.toFixed(2)}</span>
              <span className="text-2xl font-black text-primary uppercase tracking-widest">{state.asset}</span>
            </div>
          </div>
          
          <div className="space-y-6 relative z-10 border-t border-slate-800/50 pt-8">
            <div className="flex justify-between items-center">
              <p className="text-slate-500 text-[9px] font-black uppercase tracking-widest">Fuente de Pago</p>
              <div className="flex items-center gap-2 px-4 py-1.5 bg-slate-900 border border-white/5 rounded-full">
                 <span className="material-symbols-outlined text-[14px] text-primary">
                    {state.paymentSource === 'CARD' ? 'credit_card' : 'account_balance_wallet'}
                 </span>
                 <p className="text-[10px] font-black text-white uppercase tracking-tight">
                    {state.paymentSource === 'CARD' ? `${state.selectedCard?.brand} •• ${state.selectedCard?.last4}` : 'Balance del Nodo'}
                 </p>
              </div>
            </div>

            <div className="flex justify-between items-start">
              <p className="text-slate-500 text-[9px] font-black uppercase tracking-widest">Beneficiario</p>
              <div className="text-right">
                <p className="font-black text-base text-white uppercase tracking-tight leading-none mb-1">{state.recipient.name}</p>
                <p className="text-[11px] text-slate-500 font-mono tracking-widest mb-1">{state.recipient.account}</p>
                <p className="text-[9px] text-primary font-black uppercase">{state.recipient.phone}</p>
              </div>
            </div>

            <div className="flex justify-between items-center">
              <p className="text-slate-500 text-[9px] font-black uppercase tracking-widest">Motivo</p>
              <p className="text-[10px] text-white font-black uppercase tracking-widest">{state.recipient.purpose}</p>
            </div>

            <div className="flex justify-between items-center py-2 border-y border-white/5">
              <p className="text-slate-500 text-[9px] font-black uppercase tracking-widest">Monto Neto a Recibir</p>
              <p className="font-black text-lg text-success-green tracking-tighter">{state.receivedAmount} {state.targetAsset}</p>
            </div>
            
            <div className="pt-6 flex justify-between items-center">
              <p className="text-slate-400 text-[9px] font-black uppercase tracking-widest">SafeNode Fee (0.9%)</p>
              <p className="text-white text-sm font-black font-mono">+{state.commission.toFixed(2)} {state.asset}</p>
            </div>
          </div>
        </div>

        <button 
            disabled={isSubmitting}
            onClick={handleConfirm}
            className="w-full bg-primary hover:bg-blue-600 text-white font-black text-sm uppercase tracking-[0.3em] shadow-[0_25px_60px_-15px_rgba(19,109,236,0.5)] transition-all active:scale-[0.98] flex items-center justify-center gap-4 py-8 rounded-[2.5rem]"
        >
            {isSubmitting ? (
              <span className="size-6 border-4 border-white/30 border-t-white rounded-full animate-spin"></span>
            ) : (
              <>Autorizar Settlement <span className="material-symbols-outlined font-black">verified_user</span></>
            )}
        </button>
      </div>
    </Layout>
  );
};

export default ConfirmTransfer;
