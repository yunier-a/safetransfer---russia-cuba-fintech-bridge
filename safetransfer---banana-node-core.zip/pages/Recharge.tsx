
import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Layout } from '../components/Layout';
import { supabase } from '../services/supabase';
import { BankCard } from '../types';

type Category = 'CUBACEL' | 'NAUTA' | 'QVAPAY';

const Recharge: React.FC = () => {
  const navigate = useNavigate();
  const [category, setCategory] = useState<Category>('CUBACEL');
  const [identifier, setIdentifier] = useState('');
  const [selectedPlanId, setSelectedPlanId] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [userBalances, setUserBalances] = useState<any[]>([]);
  const [linkedCards, setLinkedCards] = useState<BankCard[]>([]);
  const [paymentSource, setPaymentSource] = useState<'BALANCE' | 'CARD'>('BALANCE');

  const plans = {
    CUBACEL: [
      { id: 'promo_int', label: 'Gran Recarga PROMO', rub: 1980, detail: 'Bono 100GB + Min Ilimitados + 800 CUP', isPromo: true },
      { id: 'combo_m', label: 'Combo M (Datos+Voz)', rub: 1250, detail: '4GB (LTE) + 50 Min + 80 SMS', isPromo: false },
      { id: 'combo_xl', label: 'Combo XL (Premium)', rub: 2200, detail: '14GB (LTE) + 120 Min + 200 SMS', isPromo: false },
      { id: 'data_lte_4gb', label: 'Plan LTE 4GB', rub: 850, detail: 'Navegación exclusiva red 4G', isPromo: false },
      { id: 'data_lte_16gb', label: 'Plan LTE 16GB', rub: 1850, detail: 'Navegación exclusiva red 4G', isPromo: false }
    ],
    NAUTA: [
      { id: 'nauta_plus_5', label: 'Nauta Plus (5 Días)', rub: 980, detail: 'Internet Ilimitado x 5 días', isPromo: true },
      { id: 'nauta_plus_15', label: 'Nauta Plus (15 Días)', rub: 2450, detail: 'Internet Ilimitado x 15 días', isPromo: true },
      { id: 'nauta_10h', label: 'Recarga 10 Horas', rub: 350, detail: 'Saldo para navegación wifi', isPromo: false },
      { id: 'nauta_25h', label: 'Recarga 25 Horas', rub: 820, detail: 'Saldo para navegación wifi', isPromo: false }
    ],
    QVAPAY: [
      { id: 'qv_5', label: 'Voucher QvaPay $5', rub: 550, detail: 'Saldo en USD P2P Global', isPromo: false },
      { id: 'qv_10', label: 'Voucher QvaPay $10', rub: 1100, detail: 'Saldo en USD P2P Global', isPromo: false },
      { id: 'qv_20', label: 'Voucher QvaPay $20', rub: 2150, detail: 'Saldo en USD P2P Global', isPromo: false },
      { id: 'qv_50', label: 'Voucher QvaPay $50', rub: 5200, detail: 'Saldo en USD P2P Global', isPromo: false }
    ]
  };

  useEffect(() => {
    const fetchData = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session) {
        const { data: b } = await supabase.from('wallet_balances').select('*').eq('user_id', session.user.id);
        const { data: c } = await supabase.from('bank_cards').select('*').eq('user_id', session.user.id);
        if (b) setUserBalances(b);
        if (c) setLinkedCards(c);
      }
    };
    fetchData();
  }, []);

  const currentPlans = plans[category] || [];
  const selectedPlan = currentPlans.find(p => p.id === selectedPlanId);
  const commission = (selectedPlan?.rub || 0) * 0.009;
  const totalRub = (selectedPlan?.rub || 0) + commission;

  const currentBalance = useMemo(() => {
    const b = userBalances.find(w => w.asset === 'RUB');
    return b ? parseFloat(b.balance) : 0;
  }, [userBalances]);

  const hasInsufficientBalance = totalRub > currentBalance;

  // Lógica de "Pago Directo" para Recargas
  useEffect(() => {
    if (hasInsufficientBalance && linkedCards.length > 0) setPaymentSource('CARD');
    else if (!hasInsufficientBalance) setPaymentSource('BALANCE');
  }, [hasInsufficientBalance, linkedCards, totalRub]);

  const handleExecute = async () => {
    if (!selectedPlanId || isProcessing || !identifier) return;
    setIsProcessing(true);
    const { data: { session } } = await supabase.auth.getSession();
    
    await supabase.from('transactions').insert({
      user_id: session?.user.id,
      recipient: `${category}: ${identifier}`,
      amount: totalRub.toFixed(2),
      currency: 'RUB',
      fee: commission.toFixed(2),
      type: 'Recharge',
      status: 'SUCCESS',
      network: paymentSource === 'CARD' ? 'Direct Card Auto-Settle' : 'Node Balance',
      memo: `Recarga ${selectedPlan?.label} para ${identifier}`
    });

    navigate('/success', { 
        state: { 
            recipient: identifier, 
            amount: totalRub.toFixed(2), 
            currency: 'RUB', 
            type: 'Recarga Exitosa',
            memo: `Plan ${selectedPlan?.label} procesado vía ${paymentSource === 'CARD' ? 'tarjeta vinculada' : 'balance de cuenta'}.`
        } 
    });
  };

  return (
    <Layout hideNav>
      <header className="px-4 py-6 border-b border-slate-200 dark:border-white/5 bg-white dark:bg-app-bg-dark sticky top-0 z-50 shadow-sm">
        <div className="flex justify-between items-center">
          <button onClick={() => navigate(-1)} className="size-11 flex items-center justify-center rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-500 shadow-sm active:scale-90 transition-all">
            <span className="material-symbols-outlined text-[20px]">arrow_back_ios_new</span>
          </button>
          <div className="text-center">
            <h2 className="text-xs font-black uppercase tracking-[0.2em] italic text-slate-900 dark:text-white leading-none">Recarga Bridge</h2>
            <p className="text-[7px] font-black text-primary uppercase tracking-widest mt-1">Cubacel / Nauta / QvaPay</p>
          </div>
          <div className="size-11"></div>
        </div>
      </header>

      <main className="p-4 space-y-6 pb-40 animate-in fade-in duration-500">
        <div className="flex p-1 bg-slate-100 dark:bg-slate-900/80 rounded-2xl border border-slate-200 dark:border-white/5">
          {(['CUBACEL', 'NAUTA', 'QVAPAY'] as Category[]).map(cat => (
            <button 
              key={cat} 
              onClick={() => { setCategory(cat); setSelectedPlanId(null); }}
              className={`flex-1 py-3 px-2 rounded-xl text-[9px] font-black uppercase tracking-wider transition-all ${category === cat ? 'bg-white dark:bg-app-card-dark text-primary shadow-sm scale-[1.02]' : 'text-slate-400'}`}
            >
              {cat}
            </button>
          ))}
        </div>

        <section className="bg-white dark:bg-app-card-dark border border-slate-200 dark:border-white/5 rounded-3xl p-8 space-y-6 shadow-xl relative overflow-hidden">
          <div className="space-y-3 relative z-10">
            <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-1">
              {category === 'QVAPAY' ? 'Usuario o Email QvaPay' : category === 'NAUTA' ? 'Cuenta Nauta (@nauta.com.cu)' : 'Número Cubacel (+53)'}
            </label>
            <div className="relative">
               <input 
                type="text" 
                className="w-full bg-slate-50 dark:bg-slate-950 border-none rounded-2xl py-5 px-6 font-black text-slate-900 dark:text-white focus:ring-2 focus:ring-primary/20 tracking-tight" 
                placeholder={category === 'CUBACEL' ? '5XXXXXXX' : 'Identificador...'} 
                value={identifier} 
                onChange={e => setIdentifier(e.target.value)} 
               />
               <span className="absolute right-6 top-1/2 -translate-y-1/2 material-symbols-outlined text-slate-300">bolt</span>
            </div>
          </div>
          
          <div className="flex justify-between items-center p-5 bg-primary/5 rounded-2xl border border-primary/10">
             <div className="flex items-center gap-4">
                <div className="size-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                   <span className="material-symbols-outlined text-xl">{paymentSource === 'CARD' ? 'credit_card' : 'account_balance_wallet'}</span>
                </div>
                <div>
                   <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest">Fuente de Pago</p>
                   <p className="text-[10px] font-black text-primary uppercase">{paymentSource === 'CARD' ? 'Tarjeta Directa' : 'Saldo del Nodo'}</p>
                </div>
             </div>
             <div className="text-right">
                <p className="text-[8px] font-black text-slate-500 uppercase">Disponible</p>
                <p className={`text-[10px] font-black ${hasInsufficientBalance && paymentSource === 'BALANCE' ? 'text-red-500' : 'text-slate-900 dark:text-white'}`}>{currentBalance.toFixed(2)} RUB</p>
             </div>
          </div>
        </section>

        <div className="space-y-3">
          <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-2">Seleccione una Oferta</h3>
          <div className="grid grid-cols-1 gap-3">
            {currentPlans.map(plan => (
              <button 
                key={plan.id} 
                onClick={() => setSelectedPlanId(plan.id)} 
                className={`p-5 rounded-[2rem] border-2 transition-all flex justify-between items-center relative overflow-hidden group ${selectedPlanId === plan.id ? 'border-primary bg-primary/5 shadow-lg' : 'bg-white dark:bg-app-card-dark border-slate-100 dark:border-white/5'}`}
              >
                {plan.isPromo && (
                  <div className="absolute top-0 right-0 bg-primary px-3 py-1 rounded-bl-xl">
                    <span className="text-[7px] font-black text-white uppercase tracking-widest">PROMO</span>
                  </div>
                )}
                <div className="text-left flex-1 pr-4">
                  <p className="text-[13px] font-black uppercase text-slate-900 dark:text-white tracking-tight leading-none mb-1">{plan.label}</p>
                  <p className="text-[9px] text-slate-500 font-bold uppercase tracking-tight leading-relaxed">{plan.detail}</p>
                </div>
                <div className="text-right">
                  <p className="text-lg font-black tracking-tighter text-slate-900 dark:text-white">₽{plan.rub}</p>
                  <p className="text-[7px] text-slate-400 font-black uppercase mt-0.5">Neto</p>
                </div>
              </button>
            ))}
          </div>
        </div>

        {selectedPlan && (
          <div className="bg-slate-900 rounded-[2.5rem] p-8 space-y-4 animate-in slide-in-from-bottom-2 duration-500 shadow-2xl relative overflow-hidden">
             <div className="flex justify-between items-center px-1">
                <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Resumen de Cobro</p>
                <p className="text-[8px] font-black text-primary uppercase">Tasa Dinámica Activa</p>
             </div>
             <div className="flex justify-between items-baseline">
                <h4 className="text-white font-black text-2xl tracking-tighter uppercase italic">{selectedPlan.label}</h4>
                <div className="text-right">
                   <p className="text-3xl font-black text-white tracking-tighter">₽ {totalRub.toFixed(2)}</p>
                   <p className="text-[8px] text-primary font-black uppercase tracking-widest">Total Débito</p>
                </div>
             </div>
          </div>
        )}

        <button 
          onClick={handleExecute} 
          disabled={!selectedPlanId || !identifier || (paymentSource === 'BALANCE' && hasInsufficientBalance && linkedCards.length === 0) || isProcessing} 
          className="w-full py-7 bg-primary text-white rounded-[2.5rem] font-black uppercase text-[11px] tracking-[0.3em] shadow-2xl shadow-primary/30 disabled:opacity-30 disabled:grayscale transition-all active:scale-[0.98] flex items-center justify-center gap-4"
        >
          {isProcessing ? (
             <span className="size-6 border-4 border-white/30 border-t-white rounded-full animate-spin"></span>
          ) : (
            <>Ejecutar Pago <span className="material-symbols-outlined text-xl">bolt</span></>
          )}
        </button>
        
        <p className="text-center text-[8px] text-slate-500 font-black uppercase tracking-widest px-10 leading-relaxed">
          Las recargas se sincronizan con los nodos de ETECSA y QvaPay en tiempo real.
        </p>
      </main>
    </Layout>
  );
};

export default Recharge;
