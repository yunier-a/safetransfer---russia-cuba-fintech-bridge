
import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Layout } from '../components/Layout';
import { supabase } from '../services/supabase';
import { AudioService } from '../services/audioService';

interface LeaderboardEntry {
  user_id: string;
  full_name: string;
  avatar_url: string;
  total_ops: number;
}

interface Referral {
  id: string;
  full_name: string;
  is_qualified: boolean;
}

interface RewardItem {
  id: string;
  title: string;
  cost: string;
  type: string;
  icon: string;
  img: string;
}

const Rewards: React.FC = () => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [currentUserOps, setCurrentUserOps] = useState(0);
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [referrals, setReferrals] = useState<Referral[]>([]);
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [isCopied, setIsCopied] = useState(false);

  // Recompensas del catálogo anterior
  const availableRewards: RewardItem[] = [
    { id: '1', title: '5 USDT Cashback', cost: '10 pts', type: 'VOUCHER', icon: 'payments', img: 'https://images.unsplash.com/photo-1621416894569-0f39ed31d247?auto=format&fit=crop&q=80&w=200' },
    { id: '2', title: 'Amazon Gift Card $10', cost: '50 pts', type: 'EXTERNAL', icon: 'shopping_bag', img: 'https://images.unsplash.com/photo-1523475496153-3d6cc0f0bf19?auto=format&fit=crop&q=80&w=200' },
    { id: '3', title: 'Fee 0% x 24h', cost: '25 pts', type: 'BOOST', icon: 'bolt', img: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&q=80&w=200' },
    { id: '4', title: 'QvaPay $5 Credit', cost: '30 pts', type: 'TRANSFER', icon: 'account_balance_wallet', img: 'https://images.unsplash.com/photo-1556742044-3c52d6e88c62?auto=format&fit=crop&q=80&w=200' }
  ];

  useEffect(() => {
    fetchCompetitionData();
  }, []);

  const fetchCompetitionData = async () => {
    setIsLoading(true);
    const { data: { session } } = await supabase.auth.getSession();
    
    if (session) {
      setCurrentUser(session.user);
      
      // 1. Ranking de Operadores
      const startOfMonth = new Date();
      startOfMonth.setDate(1);
      startOfMonth.setHours(0, 0, 0, 0);

      const { data: txs } = await supabase
        .from('transactions')
        .select('user_id, status')
        .gte('created_at', startOfMonth.toISOString())
        .eq('status', 'SUCCESS');

      if (txs) {
        const counts: Record<string, number> = {};
        txs.forEach(tx => { counts[tx.user_id] = (counts[tx.user_id] || 0) + 1; });
        setCurrentUserOps(counts[session.user.id] || 0);

        const sortedUserIds = Object.keys(counts).sort((a, b) => counts[b] - counts[a]).slice(0, 10);
        if (sortedUserIds.length > 0) {
          const { data: profiles } = await supabase.from('profiles').select('id, full_name, avatar_url').in('id', sortedUserIds);
          const fullLeaderboard = sortedUserIds.map(id => {
            const profile = profiles?.find(p => p.id === id);
            return {
              user_id: id,
              full_name: profile?.full_name || 'Nodo Anónimo',
              avatar_url: profile?.avatar_url || '',
              total_ops: counts[id]
            };
          });
          setLeaderboard(fullLeaderboard);
        }
      }

      // 2. Referidos (Invita y Gana)
      const { data: invitedUsers } = await supabase
        .from('profiles')
        .select('id, full_name')
        .eq('referrer_id', session.user.id);

      if (invitedUsers) {
        const invitedIds = invitedUsers.map(u => u.id);
        const { data: qualifiedTxs } = await supabase
          .from('transactions')
          .select('user_id')
          .in('user_id', invitedIds)
          .eq('status', 'SUCCESS');

        const qualifiedUserIds = new Set(qualifiedTxs?.map(t => t.user_id));
        
        const mappedReferrals = invitedUsers.map(u => ({
          id: u.id,
          full_name: u.full_name,
          is_qualified: qualifiedUserIds.has(u.id)
        }));
        setReferrals(mappedReferrals);
      }
    }
    setIsLoading(false);
  };

  const qualifiedCount = referrals.filter(r => r.is_qualified).length;

  const inviteLink = useMemo(() => {
    if (!currentUser) return '';
    return `${window.location.origin}/#/login?ref=${currentUser.id}`;
  }, [currentUser]);

  const handleCopyLink = () => {
    AudioService.playClick();
    navigator.clipboard.writeText(inviteLink);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const milestones = [
    { count: 1, reward: '50 RUB' },
    { count: 3, reward: '250 RUB' },
    { count: 5, reward: '500 RUB' }
  ];

  return (
    <Layout hideNav>
      <header className="p-6 pt-10 border-b border-slate-200 dark:border-white/5 bg-white dark:bg-app-bg-dark sticky top-0 z-50 backdrop-blur-md">
        <div className="flex items-center justify-between mb-2">
          <button onClick={() => { AudioService.playClick(); navigate(-1); }} className="size-11 flex items-center justify-center rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-500 shadow-sm active:scale-90">
            <span className="material-symbols-outlined text-[20px]">arrow_back_ios_new</span>
          </button>
          <div className="text-center">
            <h2 className="text-xl font-black text-slate-900 dark:text-white uppercase tracking-tighter italic">Premios de Red</h2>
            <p className="text-[10px] font-black text-primary uppercase tracking-[0.2em] mt-0.5">HUB DE BENEFICIOS</p>
          </div>
          <button onClick={() => { AudioService.playClick(); fetchCompetitionData(); }} className="size-11 flex items-center justify-center rounded-2xl bg-primary/10 text-primary">
            <span className={`material-symbols-outlined ${isLoading ? 'animate-spin' : ''}`}>sync</span>
          </button>
        </div>
      </header>
      
      <div className="p-6 space-y-12 pb-40 animate-in fade-in duration-500">
        
        {/* SECCIÓN 1: INVITA Y GANA */}
        <section className="bg-gradient-to-br from-primary to-blue-900 rounded-[2.5rem] p-8 shadow-2xl relative overflow-hidden group">
           <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-white/10 via-transparent to-transparent"></div>
           <div className="relative z-10 space-y-6">
              <div className="flex justify-between items-start">
                 <div className="space-y-1">
                    <h3 className="text-white font-black text-xl uppercase italic tracking-tighter">Invita y Gana</h3>
                    <p className="text-white/60 text-[9px] font-black uppercase tracking-widest">Expande el Nodo</p>
                 </div>
                 <div className="size-12 bg-white/10 rounded-2xl flex items-center justify-center border border-white/20">
                    <span className="material-symbols-outlined text-white font-black">share</span>
                 </div>
              </div>

              <div className="bg-black/20 backdrop-blur-md border border-white/10 p-5 rounded-3xl space-y-4">
                 <div className="flex gap-2">
                    <div className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-3 truncate text-[10px] text-white/50 font-mono">
                       {inviteLink || 'Sincronizando...'}
                    </div>
                    <button onClick={handleCopyLink} className={`px-6 rounded-xl font-black text-[10px] uppercase transition-all ${isCopied ? 'bg-green-500 text-white' : 'bg-white text-primary'}`}>
                      {isCopied ? 'Copiado' : 'Copiar'}
                    </button>
                 </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                 {milestones.map((m, i) => (
                   <div key={i} className={`p-4 rounded-2xl border flex flex-col items-center gap-1 transition-all ${qualifiedCount >= m.count ? 'bg-white/10 border-white/30' : 'bg-black/10 border-white/5 opacity-40'}`}>
                      <p className="text-white font-black text-[11px]">{m.reward}</p>
                      <p className="text-[7px] text-white/50 font-bold uppercase tracking-tighter text-center">{m.count} Ref.</p>
                      {qualifiedCount >= m.count && <span className="material-symbols-outlined text-xs text-green-400">check_circle</span>}
                   </div>
                 ))}
              </div>
              
              <div className="pt-2">
                 <div className="flex justify-between items-center px-1 mb-2">
                    <p className="text-[8px] font-black text-white/50 uppercase">Progreso de Red</p>
                    <p className="text-[10px] font-black text-white uppercase">{qualifiedCount} / 5</p>
                 </div>
                 <div className="h-1.5 w-full bg-black/20 rounded-full overflow-hidden border border-white/5">
                    <div className="h-full bg-white shadow-[0_0_15px_#fff] transition-all duration-1000" style={{ width: `${Math.min(100, (qualifiedCount / 5) * 100)}%` }}></div>
                 </div>
              </div>
           </div>
        </section>

        {/* SECCIÓN 2: RECOMPENSAS DISPONIBLES (RESTAURADO) */}
        <section className="space-y-6">
           <div className="flex justify-between items-center px-2">
              <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Catálogo de Beneficios</h3>
              <span className="text-[9px] font-black text-primary uppercase">Puntos: {currentUserOps * 5}</span>
           </div>
           
           <div className="grid grid-cols-2 gap-4">
              {availableRewards.map(reward => (
                <div key={reward.id} className="bg-white dark:bg-app-card-dark border border-slate-200 dark:border-white/5 rounded-[2rem] overflow-hidden shadow-lg group active:scale-95 transition-all">
                   <div className="h-24 w-full relative">
                      <img src={reward.img} className="size-full object-cover group-hover:scale-110 transition-transform duration-500" alt={reward.title} />
                      <div className="absolute inset-0 bg-black/30 group-hover:bg-black/10 transition-colors"></div>
                      <div className="absolute top-3 right-3 size-8 rounded-lg bg-white/90 dark:bg-app-bg-dark/90 backdrop-blur-md flex items-center justify-center text-primary shadow-lg">
                         <span className="material-symbols-outlined text-lg font-black">{reward.icon}</span>
                      </div>
                   </div>
                   <div className="p-4 space-y-3">
                      <h4 className="text-[11px] font-black text-slate-900 dark:text-white uppercase leading-tight">{reward.title}</h4>
                      <div className="flex justify-between items-center">
                         <span className="text-[9px] font-black text-primary uppercase tracking-tighter">{reward.cost}</span>
                         <button onClick={() => AudioService.playClick()} className="bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-300 px-3 py-1 rounded-lg text-[8px] font-black uppercase hover:bg-primary hover:text-white transition-all">Canjear</button>
                      </div>
                   </div>
                </div>
              ))}
           </div>
        </section>

        {/* SECCIÓN 3: RANKING DE LÍDERES (PODIO) */}
        <section className="space-y-6 pt-6">
           <div className="flex justify-between items-center px-2">
              <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Líderes de la Red</h3>
              <span className="text-[8px] font-black text-green-500 uppercase flex items-center gap-1">
                <div className="size-1.5 bg-green-500 rounded-full animate-pulse"></div> Auditado en Vivo
              </span>
           </div>
           
           <div className="flex items-end gap-3 justify-center pt-8">
              {leaderboard[1] && (
                <div className="flex-1 flex flex-col items-center gap-3 animate-in slide-in-from-bottom-4 duration-700">
                   <div className="relative">
                      <div className="size-16 rounded-[1.5rem] p-0.5 bg-gradient-to-br from-slate-200 to-slate-400 shadow-xl overflow-hidden">
                         <img src={leaderboard[1].avatar_url || `https://ui-avatars.com/api/?name=${leaderboard[1].full_name}&background=64748b&color=fff`} className="size-full object-cover rounded-[1.25rem]" alt="" />
                      </div>
                      <div className="absolute -top-3 -right-3 size-8 rounded-xl bg-slate-500 flex items-center justify-center text-white border-4 border-app-bg-light dark:border-app-bg-dark font-black text-xs shadow-lg">2</div>
                   </div>
                   <div className="text-center">
                      <p className="text-[10px] font-black text-slate-900 dark:text-white uppercase truncate max-w-[80px] leading-tight">{leaderboard[1].full_name.split(' ')[0]}</p>
                      <p className="text-[9px] font-black text-slate-500 mt-0.5">{leaderboard[1].total_ops} OP</p>
                   </div>
                   <div className="w-full h-16 bg-slate-200 dark:bg-slate-800/50 rounded-t-2xl border-x border-t border-slate-300 dark:border-white/5"></div>
                </div>
              )}

              {leaderboard[0] && (
                <div className="flex-1 flex flex-col items-center gap-3 animate-in slide-in-from-bottom-6 duration-1000 scale-110 -translate-y-4">
                   <div className="relative">
                      <div className="size-20 rounded-[2rem] p-0.5 bg-gradient-to-br from-amber-300 via-amber-500 to-orange-600 shadow-2xl overflow-hidden">
                         <img src={leaderboard[0].avatar_url || `https://ui-avatars.com/api/?name=${leaderboard[0].full_name}&background=f59e0b&color=fff`} className="size-full object-cover rounded-[1.75rem]" alt="" />
                      </div>
                      <div className="absolute -top-4 -right-4 size-10 rounded-2xl bg-amber-500 flex items-center justify-center text-white border-4 border-app-bg-light dark:border-app-bg-dark font-black text-lg shadow-2xl">1</div>
                      <div className="absolute -top-10 left-1/2 -translate-x-1/2 animate-bounce">
                         <span className="material-symbols-outlined text-amber-500 text-3xl font-black">crown</span>
                      </div>
                   </div>
                   <div className="text-center">
                      <p className="text-xs font-black text-slate-900 dark:text-white uppercase truncate max-w-[90px] leading-tight">{leaderboard[0].full_name.split(' ')[0]}</p>
                      <p className="text-[10px] font-black text-primary mt-0.5">{leaderboard[0].total_ops} OP</p>
                   </div>
                   <div className="w-full h-24 bg-primary/10 rounded-t-2xl border-x border-t border-primary/20 shadow-[0_-10px_20px_rgba(19,109,236,0.1)]"></div>
                </div>
              )}

              {leaderboard[2] && (
                <div className="flex-1 flex flex-col items-center gap-3 animate-in slide-in-from-bottom-2 duration-500">
                   <div className="relative">
                      <div className="size-16 rounded-[1.5rem] p-0.5 bg-gradient-to-br from-orange-400 to-amber-700 shadow-xl overflow-hidden">
                         <img src={leaderboard[2].avatar_url || `https://ui-avatars.com/api/?name=${leaderboard[2].full_name}&background=d97706&color=fff`} className="size-full object-cover rounded-[1.25rem]" alt="" />
                      </div>
                      <div className="absolute -top-3 -right-3 size-8 rounded-xl bg-orange-700 flex items-center justify-center text-white border-4 border-app-bg-light dark:border-app-bg-dark font-black text-xs shadow-lg">3</div>
                   </div>
                   <div className="text-center">
                      <p className="text-[10px] font-black text-slate-900 dark:text-white uppercase truncate max-w-[80px] leading-tight">{leaderboard[2].full_name.split(' ')[0]}</p>
                      <p className="text-[9px] font-black text-slate-500 mt-0.5">{leaderboard[2].total_ops} OP</p>
                   </div>
                   <div className="w-full h-12 bg-slate-200 dark:bg-slate-800/50 rounded-t-2xl border-x border-t border-slate-300 dark:border-white/5"></div>
                </div>
              )}
           </div>
        </section>

        {/* SECCIÓN 4: INFO Y PROTOCOLO */}
        <section className="bg-primary/5 border border-primary/20 rounded-[2.5rem] p-8 flex gap-6 items-start shadow-inner">
           <div className="size-12 rounded-3xl bg-primary/10 flex items-center justify-center text-primary shrink-0">
             <span className="material-symbols-outlined text-2xl font-black">info</span>
           </div>
           <div className="space-y-1">
             <h4 className="text-[10px] font-black text-slate-900 dark:text-white uppercase tracking-widest">Protocolo de Reinicio</h4>
             <p className="text-[9px] text-slate-500 leading-relaxed font-bold uppercase tracking-tight">
                El ranking y los puntos de canje se consolidan el día <span className="text-primary font-black">01 de cada mes</span> a las 00:00 UTC. Las recompensas de referidos se acreditan tras el primer "Settlement" exitoso del invitado.
             </p>
           </div>
        </section>

      </div>
    </Layout>
  );
};

export default Rewards;
