
import { supabase } from './supabase';

export type WebhookProvider = 'SBP_RUSSIA' | 'CUBA_SMS_BRIDGE' | 'NOWPAYMENTS' | 'STRIPE' | 'PAYPAL';

export interface WebhookPayload {
  provider: WebhookProvider;
  data: any;
}

export const WebhookService = {
  async handleIncomingSignal(payload: WebhookPayload) {
    const { provider, data } = payload;

    const { data: logData, error: logError } = await supabase
      .from('webhook_logs')
      .insert({
        provider,
        payload: data,
        processed: false
      })
      .select()
      .single();

    if (logError) return { success: false, error: 'Audit log failed' };

    try {
      // Por ahora simulamos éxito en el procesamiento del webhook
      await supabase.from('webhook_logs').update({ processed: true }).eq('id', logData.id);
      return { success: true };
    } catch (err: any) {
      console.error('Handshake Error:', err);
      return { success: false, error: err.message };
    }
  }
};
