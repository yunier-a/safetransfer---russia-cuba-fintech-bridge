
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Layout } from '../components/Layout';
import { supabase } from '../services/supabase';
import { CoinExService } from '../services/coinExService';
import { NotificationService } from '../services/notificationService';
import { PaymentService } from '../services/paymentService';
import { AudioService } from '../services/audioService';

const BrilliantIcon: React.FC<{ type: 'RUB' | 'CUP' | 'MLC' | 'USDT' | 'PAYPAL' | 'ZELLE' | 'MASTER' | 'GPAY' }> = ({ type }) => {
  const baseClass = "size-12 rounded-xl flex items-center justify-center overflow-hidden border transition-all duration-300 shadow-lg group-hover:scale-105";
  switch (type) {
    case 'RUB': return <div className={`${baseClass} bg-white border-slate-200 dark:border-white/10 glow-rub`}><img src="https://flagcdn.com/w80/ru.png" className="w-full h-full object-cover" alt="Rusia" /></div>;
    case 'CUP': return <div className={`${baseClass} bg-white border-slate-200 dark:border-white/10 glow-cup`}><img src="https://flagcdn.com/w80/cu.png" className="w-full h-full object-cover" alt="Cuba" /></div>;
    case 'MLC': return <div className={`${baseClass} bg-white border-slate-200 dark:border-white/10 glow-mlc`}><img src="https://flagcdn.com/w80/cu.png" className="w-full h-full object-cover brightness-110 saturate-150" alt="MLC" /><div className="absolute inset-0 bg-cyan-500/10 pointer-events-none"></div></div>;
    case 'USDT': return <div className={`${baseClass} bg-white dark:bg-slate-900 border-slate-200 dark:border-white/10 glow-usdt p-2`}><img src="https://raw.githubusercontent.com/spothq/cryptocurrency-icons/master/128/color/usdt.png" className="size-full object-contain" alt="Tether" /></div>;
    case 'PAYPAL': return <div className={`${baseClass} bg-white border-slate-100 p-2`}><img src="https://img.icons8.com/fluency/96/paypal.png" className="size-full object-contain" alt="Paypal" /></div>;
    case 'ZELLE': return <div className={`${baseClass} bg-white border-slate-100 p-1`}><img src="https://img.icons8.com/color/96/zelle.png" className="size-full object-contain" alt="Zelle" /></div>;
    case 'GPAY': return <div className={`${baseClass} bg-white border-slate-100 p-2 shadow-[0_0_15px_rgba(66,133,244,0.2)]`}><img src="https://img.icons8.com/color/48/google-pay.png" className="size-full object-contain" alt="GPay" /></div>;
    default: return <div className={`${baseClass} bg-slate-900 border-white/10 p-2`}><img src="https://img.icons8.com/fluency/96/shield.png" className="size-full object-contain" alt="Master" /></div>;
  }
};

const DepositCrypto: React.FC = () => {
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [currentStep, setCurrentStep] = useState<1 | 2 | 3 | 4>(1);
  const [activeTab, setActiveTab] = useState<'ALL' | 'FIAT' | 'CRYPTO' | 'GLOBAL'>('ALL');
  const [selectedAssetId, setSelectedAssetId] = useState<string | null>(null);
  const [amount, setAmount] = useState('');
  const [txHash, setTxHash] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [receiptImage, setReceiptImage] = useState<string | null>(null);

  const options: any[] = [
    { id: 'rub_sbp', label: 'Rusia: Tarjeta / SBP', symbol: 'RUB', type: 'FIAT', iconType: 'RUB', network: 'MIR Direct Transfer', minDeposit: 500, address: '2204 1202 0360 3887', estTime: '10 min' },
    { id: 'cup_direct', label: 'Cuba: Transferencia CUP', symbol: 'CUP', type: 'FIAT', iconType: 'CUP', network: 'Red Bancaria (CUP)', minDeposit: 2500, address: '9225 1299 5502 3341', estTime: '30 min' },
    { id: 'mlc_direct', label: 'Cuba: Tarjeta MLC', symbol: 'MLC', type: 'FIAT', iconType: 'MLC', network: 'Red MLC / Transfermóvil', minDeposit: 10, address: '9225 1299 8832 1104', estTime: '20 min' },
    { id: 'crypto_usdt', label: 'Tether (USDT)', symbol: 'USDT', type: 'CRYPTO', iconType: 'USDT', network: 'CoinEx Bridge (TRC-20)', minDeposit: 5, address: CoinExService.getDepositAddress(), estTime: 'Instant' },
    { id: 'google_wallet', label: 'Google Wallet', symbol: 'USD', type: 'GLOBAL', iconType: 'GPAY', network: 'Google Pay SafeNode', minDeposit: 1, estTime: 'Instant' },
    { id: 'zelle_usa', label: 'Zelle USA', symbol: 'USD', type: 'GLOBAL', iconType: 'ZELLE', network: '502 BLACK INC / USA', minDeposit: 25, estTime: '5-15 min' },
    { id: 'paypal_dual', label: 'PayPal Global', symbol: 'USD', type: 'GLOBAL', iconType: 'PAYPAL', network: 'Request via Support', minDeposit: 10, estTime: '15 min' }
  ];

  const filteredOptions = useMemo(() => {
    if (activeTab === 'FIAT') return options.filter(o => o.type === 'FIAT');
    if (activeTab === 'CRYPTO') return options.filter(o => o.type === 'CRYPTO');
    if (activeTab === 'GLOBAL') return options.filter(o => o.type === 'GLOBAL');
    return options;
  }, [activeTab]);

  const selectedAsset = options.find(o => o.id === selectedAssetId);
  const commission = useMemo(() => (parseFloat(amount) || 0) * 0.009, [amount]);
  const totalDeposit = useMemo(() => (parseFloat(amount) || 0) + commission, [amount, commission]);

  const isAmountValid = useMemo(() => {
    const val = parseFloat(amount) || 0;
    if (!selectedAsset) return false;
    return val >= selectedAsset.minDeposit;
  }, [amount, selectedAsset]);

  const handleStep2Continue = async () => {
    AudioService.playClick();
    if (selectedAsset?.id === 'google_wallet') {
      setIsProcessing(true);
      try {
        const { data: { session } } = await supabase.auth.getSession();
        const payment = await PaymentService.createPaymentSession('GPAY', session?.user.id || 'anonymous', parseFloat(amount), 'USD');
        navigate(payment.confirmationUrl);
      } catch (err) {
        alert("Fallo al iniciar sesión de Google Wallet.");
      } finally {
        setIsProcessing(false);
      }
    } else {
      setCurrentStep(3);
    }
  };

  const handleFinalize = async () => {
    if (selectedAsset?.id === 'crypto_usdt' && !txHash) return;
    if (selectedAsset?.id !== 'crypto_usdt' && !receiptImage) return;

    AudioService.playClick();
    setIsProcessing(true);
    const { data: { session } } = await supabase.auth.getSession();
    
    let status = 'PENDING';
    let msg = 'Depósito notificado al nodo.';

    if (selectedAsset?.id === 'crypto_usdt') {
      const verify = await CoinExService.verifyTransaction(txHash, amount);
      if (verify.success) {
        status = 'SUCCESS';
        msg = 'Cripto verificada en CoinEx Node con éxito.';
      }
    }

    await supabase.from('transactions').insert({
      user_id: session?.user.id,
      recipient: `Depósito: ${selectedAsset?.label}`,
      amount: totalDeposit.toFixed(2),
      currency: selectedAsset?.symbol,
      fee: commission.toFixed(2),
      type: 'Deposit',
      status: status,
      memo: `Settle: ${selectedAsset?.network} | Ref: ${txHash || 'Manual Upload'}`,
      hash: txHash,
      node_id: selectedAsset?.id === 'crypto_usdt' ? 'COINEX_PRIORITY' : 'VAULT_SETTLE'
    });

    navigate('/success', { 
      state: { 
        recipient: selectedAsset?.label, 
        amount: totalDeposit.toFixed(2), 
        currency: selectedAsset?.symbol, 
        type: selectedAsset?.id === 'crypto_usdt' ? 'CoinEx Fast Deposit' : 'Safe Deposit',
        memo: msg
      } 
    });
  };

  const handleWhatsAppContact = async () => {
    AudioService.playClick();
    if (!selectedAsset || !amount) return;
    const opType = selectedAsset.id === 'zelle_usa' ? 'ZELLE_DEPOSIT_REQUEST' : 'PAYPAL_DEPOSIT_REQUEST';
    const result = await NotificationService.notifyAdmin(opType, {
        amount: totalDeposit.toFixed(2),
        currency: selectedAsset.symbol,
        recipient: selectedAsset.label
    });
    window.open(result.whatsappLink, '_blank');
  };

  return (
    <Layout hideNav>
      <header className="p-4 pt-8 glass-header sticky top-0 z-50">
        <div className="flex justify-between items-center mb-6">
          <button onClick={() => { AudioService.playClick(); currentStep > 1 ? setCurrentStep((currentStep - 1) as any) : navigate(-1); }} className="size-11 flex items-center justify-center rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-500 shadow-sm active:scale-90 transition-all">
            <span className="material-symbols-outlined text-[18px]">arrow_back_ios_new</span>
          </button>
          <div className="text-center">
            <h2 className="text-sm font-black text-slate-900 dark:text-white uppercase tracking-widest italic">Depósito de Fondos</h2>
            <p className="text-[7px] font-black text-primary uppercase tracking-widest mt-0.5">Etapa {currentStep}</p>
          </div>
          <div className="size-11"></div>
        </div>
      </header>

      <div className="p-4 space-y-6 pb-32 animate-in fade-in duration-500">
        {currentStep === 1 && (
          <div className="space-y-6">
             <div className="flex p-1 bg-slate-100 dark:bg-slate-900/80 rounded-2xl border border-slate-200 dark:border-white/5 overflow-x-auto hide-scrollbar gap-1">
                {(['ALL', 'FIAT', 'CRYPTO', 'GLOBAL'] as const).map(tab => (
                  <button key={tab} onClick={() => { AudioService.playClick(); setActiveTab(tab); }} className={`flex-1 py-2.5 px-3 rounded-xl text-[8px] font-black uppercase transition-all ${activeTab === tab ? 'bg-white dark:bg-app-card-dark text-primary shadow-sm' : 'text-slate-400'}`}>{tab}</button>
                ))}
             </div>
             <div className="grid grid-cols-1 gap-3">
                {filteredOptions.map((opt) => (
                  <button key={opt.id} onClick={() => { AudioService.playClick(); setSelectedAssetId(opt.id); }} className={`w-full p-5 rounded-3xl border-2 transition-all flex items-center gap-5 relative overflow-hidden group ${selectedAssetId === opt.id ? 'border-primary bg-primary/5 shadow-xl' : 'bg-white dark:bg-app-card-dark border-slate-100 dark:border-white/5'}`}>
                      <BrilliantIcon type={opt.iconType} />
                      <div className="text-left flex-1">
                        <p className="text-[14px] font-black uppercase text-slate-900 dark:text-white tracking-tight leading-none mb-1">{opt.label}</p>
                        <p className="text-[8px] text-slate-500 font-bold uppercase tracking-widest">{opt.network}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-[10px] font-black text-slate-900 dark:text-white leading-none">Min: {opt.minDeposit}</p>
                        <p className="text-[7px] text-slate-400 font-bold uppercase mt-1">{opt.estTime}</p>
                      </div>
                  </button>
                ))}
             </div>
             <button disabled={!selectedAssetId} onClick={() => { AudioService.playClick(); setCurrentStep(2); }} className="w-full py-6 bg-primary text-white rounded-[1.5rem] font-black uppercase text-[11px] tracking-[0.2em] shadow-2xl active:scale-95 disabled:opacity-30">Continuar</button>
          </div>
        )}

        {currentStep === 2 && selectedAsset && (
          <div className="space-y-6 text-center animate-in zoom-in duration-300">
             <div className="bg-white dark:bg-app-card-dark border border-slate-200 dark:border-white/5 rounded-[3rem] p-10 shadow-2xl space-y-8">
                <div className="flex justify-center"><BrilliantIcon type={selectedAsset.iconType} /></div>
                <div className="space-y-2">
                  <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em]">Monto Base a Recargar</h3>
                  <div className="flex items-center justify-center gap-2">
                    <span className="text-2xl font-black text-slate-300">$</span>
                    <input type="number" className="bg-transparent border-none p-0 text-6xl font-black text-slate-900 dark:text-white focus:ring-0 text-center tracking-tighter w-full max-w-[220px]" value={amount} onChange={e => setAmount(e.target.value)} placeholder="0.00" autoFocus />
                  </div>
                  {parseFloat(amount) > 0 && !isAmountValid && (
                    <p className="text-[9px] font-black text-red-500 uppercase tracking-widest mt-2 animate-bounce">
                      Mínimo requerido: {selectedAsset.minDeposit} {selectedAsset.symbol}
                    </p>
                  )}
                </div>
                {parseFloat(amount) > 0 && (
                  <div className="pt-6 border-t border-slate-100 dark:border-white/5 space-y-3">
                    <div className="flex justify-between items-center text-[11px] font-bold text-slate-400">
                       <span>Comisión (0.9%)</span>
                       <span className="text-primary">+{commission.toFixed(2)} {selectedAsset.symbol}</span>
                    </div>
                    <div className="flex justify-between items-center bg-primary/5 p-4 rounded-2xl border border-primary/10">
                       <span className="text-[10px] font-black text-primary uppercase">Total a Transferir</span>
                       <span className="text-xl font-black text-primary">{totalDeposit.toFixed(2)} {selectedAsset.symbol}</span>
                    </div>
                  </div>
                )}
             </div>
             <button disabled={!isAmountValid || isProcessing} onClick={handleStep2Continue} className="w-full py-6 bg-primary text-white rounded-[1.5rem] font-black uppercase text-[11px] tracking-[0.2em] shadow-lg active:scale-95 disabled:grayscale flex items-center justify-center gap-2">
               {isProcessing ? <span className="size-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span> : (selectedAsset.id === 'google_wallet' ? 'Proceder con GPay' : 'Ver datos de pago')}
             </button>
          </div>
        )}

        {currentStep === 3 && selectedAsset && (
          <div className="space-y-6 animate-in slide-in-from-bottom-4">
             <div className="bg-white dark:bg-app-card-dark border border-slate-200 dark:border-white/5 rounded-[2.5rem] p-8 space-y-6 shadow-2xl">
                {(selectedAsset.id === 'paypal_dual' || selectedAsset.id === 'zelle_usa') ? (
                  <div className="space-y-6 text-center">
                    <div className="flex justify-center"><BrilliantIcon type={selectedAsset.iconType} /></div>
                    <div className="space-y-2">
                       <h3 className="text-xl font-black text-slate-900 dark:text-white uppercase italic tracking-tight">Solicitud de liquidación</h3>
                       <p className="text-[11px] font-bold text-slate-500 uppercase tracking-widest">Canal Global {selectedAsset.label}</p>
                    </div>
                    
                    <div className="bg-slate-50 dark:bg-slate-950 p-6 rounded-[1.5rem] border border-primary/20 text-center space-y-4 shadow-inner">
                        <span className="material-symbols-outlined text-4xl text-primary font-black">qr_code_scanner</span>
                        <p className="text-[11px] font-black text-slate-700 dark:text-slate-300 uppercase leading-relaxed tracking-tight">Solicita el código QR de 502 BLACK INC para pagar exactamente:</p>
                        <div className="bg-white dark:bg-slate-900 py-3 rounded-xl border border-slate-200 dark:border-white/5 shadow-sm">
                           <p className="text-lg font-black text-primary tracking-tighter">{totalDeposit.toFixed(2)} USD</p>
                        </div>
                        <button onClick={handleWhatsAppContact} className="w-full py-5 bg-green-600 text-white rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-3 active:scale-95 transition-all"><span className="material-symbols-outlined text-xl">chat</span>Obtener QR vía WhatsApp</button>
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="text-center">
                       <div className="flex justify-center mb-4"><BrilliantIcon type={selectedAsset.iconType} /></div>
                       <h3 className="text-lg font-black text-slate-900 dark:text-white uppercase italic tracking-tight">Datos de Depósito</h3>
                       <p className="text-[10px] font-bold text-primary uppercase tracking-widest mt-2 bg-primary/5 py-2 px-4 rounded-full inline-block">
                         Total requerido: {totalDeposit.toFixed(2)} {selectedAsset.symbol}
                       </p>
                    </div>
                    {selectedAsset.address && (
                      <div className="space-y-3">
                          <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest px-1">Dirección del Nodo Receptor</label>
                          <div className="bg-slate-50 dark:bg-slate-950 p-6 rounded-[1.5rem] flex items-center justify-between border border-slate-100 dark:border-white/5 shadow-inner">
                              <code className="text-primary font-mono font-black text-xs truncate pr-4">{selectedAsset.address}</code>
                              <button onClick={() => { AudioService.playClick(); navigator.clipboard.writeText(selectedAsset.address); alert("Copiado"); }} className="size-11 flex items-center justify-center rounded-xl bg-white dark:bg-slate-800 text-slate-400 shadow-sm"><span className="material-symbols-outlined text-[20px]">content_copy</span></button>
                          </div>
                      </div>
                    )}
                  </>
                )}
                
                <button onClick={() => { AudioService.playClick(); setCurrentStep(4); }} className="w-full py-6 bg-primary text-white rounded-[1.5rem] font-black uppercase text-[11px] tracking-[0.2em] shadow-lg active:scale-95">Siguiente: Validar Operación</button>
             </div>
          </div>
        )}

        {currentStep === 4 && selectedAsset && (
          <div className="space-y-8 text-center animate-in fade-in zoom-in duration-500">
             <div className="space-y-2">
                <h3 className="text-3xl font-black text-slate-900 dark:text-white uppercase italic tracking-tighter">Validación</h3>
                <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Confirma tu transferencia al nodo central</p>
             </div>

             {selectedAsset.id === 'crypto_usdt' ? (
                <div className="bg-white dark:bg-app-card-dark border border-slate-200 dark:border-white/5 rounded-[3rem] p-8 shadow-2xl space-y-6">
                   <div className="size-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto text-primary mb-4 border border-primary/10"><span className="material-symbols-outlined text-3xl font-black">hub</span></div>
                   <div className="space-y-2 text-left">
                      <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-2">CoinEx Transaction Hash (TXID)</label>
                      <input 
                        type="text"
                        className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-white/10 rounded-2xl py-5 px-6 text-sm text-white font-mono focus:border-primary outline-none"
                        placeholder="E.g. 0x... o TXID de la transferencia"
                        value={txHash}
                        onChange={e => setTxHash(e.target.value)}
                      />
                   </div>
                   <div className="bg-blue-500/5 p-4 rounded-xl border border-blue-500/10"><p className="text-[9px] text-slate-500 font-bold uppercase leading-relaxed italic">El nodo de CoinEx validará el hash automáticamente para una liquidación instantánea.</p></div>
                </div>
             ) : (
                <div onClick={() => { AudioService.playClick(); fileInputRef.current?.click(); }} className={`w-full aspect-[4/3] rounded-[3rem] border-4 border-dashed flex flex-col items-center justify-center cursor-pointer overflow-hidden transition-all shadow-inner ${receiptImage ? 'border-primary/50 bg-primary/5' : 'border-slate-200 dark:border-slate-800'}`}>
                  {receiptImage ? <img src={receiptImage} className="size-full object-cover" alt="Comprobante" /> : (
                    <div className="flex flex-col items-center gap-4 text-slate-400">
                      <span className="material-symbols-outlined text-5xl">add_a_photo</span>
                      <span className="text-[10px] font-black uppercase tracking-widest">Cargar captura de pantalla</span>
                    </div>
                  )}
                </div>
             )}
             
             <input type="file" ref={fileInputRef} onChange={e => {
               const f = e.target.files?.[0];
               if(f){ const r = new FileReader(); r.onloadend = () => setReceiptImage(r.result as string); r.readAsDataURL(f); }
             }} className="hidden" accept="image/*" />
             
             <button onClick={handleFinalize} disabled={isProcessing || (selectedAsset.id === 'crypto_usdt' ? !txHash : !receiptImage)} className="w-full py-7 bg-primary text-white rounded-[2rem] text-[12px] font-black uppercase tracking-[0.3em] shadow-xl flex items-center justify-center gap-4">
               {isProcessing ? <span className="size-6 border-4 border-white/30 border-t-white rounded-full animate-spin"></span> : <>Finalizar Depósito <span className="material-symbols-outlined">verified_user</span></>}
             </button>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default DepositCrypto;
