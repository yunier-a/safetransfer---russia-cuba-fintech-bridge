
import { supabase } from './supabase';

export type PaymentGateway = 'STRIPE' | 'NOWPAYMENTS' | 'SBP' | 'PAYPAL' | 'QVAPAY' | 'GPAY' | 'DEBIT_CARD';

export const PaymentService = {
  /**
   * Crea una sesión de pago o factura en el nodo central
   */
  async createPaymentSession(gateway: PaymentGateway, userId: string, amount: number, currency: string) {
    const sessionId = `${gateway.toLowerCase()}_${Math.random().toString(36).substring(7).toUpperCase()}`;
    const formattedAmount = parseFloat(amount.toFixed(2));

    // Intentar registrar en DB, pero no bloqueamos el proceso si falla
    try {
      await supabase.from('payment_sessions').insert({
        user_id: userId,
        gateway,
        session_id: sessionId,
        amount: formattedAmount,
        currency,
        status: 'PENDING'
      });
    } catch (e) {
      console.warn("DB Session log failed, proceeding with URL fallback.");
    }

    let confirmationUrl = '';

    // Pasamos amount y currency en la URL como "Fail-Safe"
    if (gateway === 'QVAPAY') {
      confirmationUrl = `/gateway-checkout?sessionId=${sessionId}&gateway=QVAPAY&amount=${formattedAmount}&currency=${currency}&external=true`;
    } else if (gateway === 'GPAY') {
      confirmationUrl = `/gateway-checkout?sessionId=${sessionId}&gateway=GPAY&amount=${formattedAmount}&currency=${currency}`;
    } else if (gateway === 'DEBIT_CARD') {
      confirmationUrl = `/gateway-checkout?sessionId=${sessionId}&gateway=DEBIT_CARD&amount=${formattedAmount}&currency=${currency}&requireProof=true`;
    } else if (gateway === 'PAYPAL') {
      confirmationUrl = `https://wa.me/16892564329?text=Hola,%20solicito%20link%20de%20pago%20PayPal%20por%20${formattedAmount}%20USD.%20Ref:%20${sessionId}`;
    } else {
      confirmationUrl = `/gateway-checkout?sessionId=${sessionId}&gateway=${gateway}&amount=${formattedAmount}&currency=${currency}`;
    }

    return {
      sessionId,
      confirmationUrl,
    };
  }
};
