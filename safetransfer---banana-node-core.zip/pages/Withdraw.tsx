
import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Layout } from '../components/Layout';
import { supabase } from '../services/supabase';
import { NotificationService } from '../services/notificationService';

interface Wallet {
  id: string;
  asset: string;
  balance: number;
}

interface BankCard {
  id: string;
  last4: string;
  brand: string;
  holder_name: string;
  color: string;
}

type ManualType = 'BANK' | 'CRYPTO';

const Withdraw: React.FC = () => {
  const navigate = useNavigate();
  const [wallets, setWallets] = useState<Wallet[]>([]);
  const [bankCards, setBankCards] = useState<BankCard[]>([]);
  const [selectedWalletId, setSelectedWalletId] = useState<string | null>(null);
  const [selectedCardId, setSelectedCardId] = useState<string | 'external'>('external');
  const [userProfile, setUserProfile] = useState<any>(null);
  
  // Manual External Details
  const [manualType, setManualType] = useState<ManualType>('CRYPTO');
  const [extRecipient, setExtRecipient] = useState('');
  const [extBankName, setExtBankName] = useState('');
  const [extAccountNumber, setExtAccountNumber] = useState('');
  const [extRoutingNetwork, setExtRoutingNetwork] = useState('');

  const [amount, setAmount] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // 2FA Re-auth state
  const [is2FAModalOpen, setIs2FAModalOpen] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [isVerifying2FA, setIsVerifying2FA] = useState(false);

  useEffect(() => {
    fetchUserData();
  }, []);

  const fetchUserData = async () => {
    setIsLoading(true);
    const { data: { session } } = await supabase.auth.getSession();
    if (session) {
      const { data: b } = await supabase.from('wallet_balances').select('*').eq('user_id', session.user.id);
      const { data: c } = await supabase.from('bank_cards').select('*').eq('user_id', session.user.id);
      const { data: p } = await supabase.from('profiles').select('*').eq('id', session.user.id).single();
      
      if (b) setWallets(b);
      if (c) setBankCards(c);
      if (p) setUserProfile(p);

      if (b && b.length > 0) {
        setSelectedWalletId(b[0].id);
        setAmount(b[0].balance.toFixed(2));
      }
    }
    setIsLoading(false);
  };

  const selectedWallet = useMemo(() => wallets.find(w => w.id === selectedWalletId), [selectedWalletId, wallets]);
  
  useEffect(() => {
    if (selectedWallet) {
      setAmount(selectedWallet.balance.toFixed(2));
    }
  }, [selectedWalletId]);

  const commissionRate = useMemo(() => {
    if (!selectedWallet) return 2.0;
    const rates: Record<string, number> = { 
      'RUB': 2.0, 
      'CUP': 4.5, 
      'USDT': 1.5, 
      'BTC': 1.0, 
      'MLC': 3.0 
    };
    return rates[selectedWallet.asset] || 2.5;
  }, [selectedWallet]);

  const commissionAmount = useMemo(() => {
    const val = parseFloat(amount) || 0;
    return (val * commissionRate) / 100;
  }, [amount, commissionRate]);

  const totalToReceive = useMemo(() => {
    const val = parseFloat(amount) || 0;
    return Math.max(0, val - commissionAmount);
  }, [amount, commissionAmount]);

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputVal = e.target.value;
    const numericVal = parseFloat(inputVal);
    const maxBalance = selectedWallet?.balance || 0;
    if (inputVal === '') { setAmount(''); return; }
    if (numericVal > maxBalance) { setAmount(maxBalance.toFixed(2)); } 
    else { setAmount(inputVal); }
  };

  const isManualValid = useMemo(() => {
    if (selectedCardId !== 'external') return true;
    return extRecipient.trim() !== '' && 
           extAccountNumber.trim() !== '' && 
           extRoutingNetwork.trim() !== '' && 
           (manualType === 'BANK' ? extBankName.trim() !== '' : true);
  }, [selectedCardId, extRecipient, extAccountNumber, extRoutingNetwork, extBankName, manualType]);

  const handleWithdrawInitiation = async () => {
    if (!selectedWallet || !amount || isProcessing || !isManualValid) return;
    
    // Check for 2FA requirement
    if (userProfile?.two_factor_enabled) {
      setIs2FAModalOpen(true);
      return;
    }

    executeWithdraw();
  };

  const handle2FAVerification = async () => {
    if (otpCode !== '123456' && otpCode !== '000000') {
      alert("Código incorrecto.");
      return;
    }
    setIsVerifying2FA(true);
    await new Promise(r => setTimeout(r, 800));
    setIsVerifying2FA(false);
    setIs2FAModalOpen(false);
    executeWithdraw();
  };

  const executeWithdraw = async () => {
    const val = parseFloat(amount);
    
    if (val > (selectedWallet?.balance || 0)) {
      alert("Saldo insuficiente en el bolsillo seleccionado.");
      return;
    }

    setIsProcessing(true);
    const { data: { session } } = await supabase.auth.getSession();
    
    try {
      const txId = `WD-${Math.random().toString(36).substring(7).toUpperCase()}`;
      let destination = '';
      let memoDetails = '';

      if (selectedCardId === 'external') {
        destination = `${manualType}: ${extAccountNumber}`;
        memoDetails = `Retiro Externo (${manualType})\n` +
                      `Beneficiario: ${extRecipient}\n` +
                      `Banco/Plataforma: ${extBankName || 'N/A'}\n` +
                      `Cuenta/Address: ${extAccountNumber}\n` +
                      `Red/Ruta: ${extRoutingNetwork}`;
      } else {
        const card = bankCards.find(c => c.id === selectedCardId);
        destination = `Card ending in ${card?.last4}`;
        memoDetails = `Retiro a tarjeta vinculada: ${card?.brand} ${card?.last4}. Titular: ${card?.holder_name}`;
      }

      const { error: txError } = await supabase.from('transactions').insert({
        user_id: session?.user.id,
        recipient: `Liquidación: ${destination}`,
        amount: val,
        currency: selectedWallet?.asset,
        status: 'PENDING',
        fee: commissionAmount.toFixed(2),
        type: 'Withdraw',
        memo: memoDetails,
        hash: txId,
        node_id: 'WITHDRAW_QUEUE'
      });

      if (txError) throw txError;

      await NotificationService.notifyAdmin('WITHDRAW_REQUEST', {
        amount: val.toFixed(2),
        currency: selectedWallet?.asset,
        recipient: extRecipient || 'Self Card',
        details: memoDetails,
        txId: txId,
        netAmount: totalToReceive.toFixed(2)
      });

      navigate('/success', {
        state: {
          recipient: extRecipient || destination,
          amount: val.toFixed(2),
          currency: selectedWallet?.asset,
          type: 'Withdrawal / Settlement',
          memo: `Solicitud de liquidación procesada. Ref: ${txId}.`
        }
      });

    } catch (err: any) {
      alert("Error en el protocolo de retiro: " + err.message);
      setIsProcessing(false);
    }
  };

  const getAssetMeta = (asset: string) => {
    switch (asset) {
      case 'RUB': return { icon: 'currency_ruble', color: 'text-blue-500', bg: 'bg-blue-500/10', border: 'border-blue-500/20', label: 'Rublos' };
      case 'CUP': return { icon: 'payments', color: 'text-primary', bg: 'bg-primary/10', border: 'border-primary/20', label: 'Pesos' };
      case 'USDT': return { icon: 'attach_money', color: 'text-green-500', bg: 'bg-green-500/10', border: 'border-green-500/20', label: 'Tether' };
      case 'BTC': return { icon: 'currency_bitcoin', color: 'text-orange-500', bg: 'bg-orange-500/10', border: 'border-orange-500/20', label: 'Bitcoin' };
      default: return { icon: 'wallet', color: 'text-slate-500', bg: 'bg-slate-500/10', border: 'border-slate-500/20', label: asset };
    }
  };

  return (
    <Layout hideNav>
      <header className="p-6 pt-10 border-b border-slate-800 bg-background-dark/95 backdrop-blur-md sticky top-0 z-50">
        <div className="flex justify-between items-center mb-6">
          <button onClick={() => navigate(-1)} className="size-11 flex items-center justify-center rounded-2xl bg-slate-800/50 hover:bg-slate-800 transition-all text-white">
            <span className="material-symbols-outlined text-[20px]">arrow_back_ios_new</span>
          </button>
          <div className="text-center">
            <h2 className="text-xl font-black text-white uppercase tracking-tighter italic">Liquidación de Fondos</h2>
            <p className="text-[10px] font-black text-primary uppercase tracking-[0.2em] mt-0.5">Settle Terminal v5.0</p>
          </div>
          <div className="size-11"></div>
        </div>
      </header>

      <div className="p-6 space-y-10 pb-40 animate-in fade-in duration-700">
        
        {/* WALLET SELECTION */}
        <section className="space-y-4">
          <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] px-2">1. Origen de Liquidez</h3>
          <div className="flex gap-4 overflow-x-auto hide-scrollbar -mx-6 px-6 pb-2">
            {isLoading ? (
               Array(3).fill(0).map((_, i) => <div key={i} className="min-w-[160px] h-32 bg-slate-800/20 animate-pulse rounded-[2.5rem]"></div>)
            ) : wallets.map(w => {
              const meta = getAssetMeta(w.asset);
              const isActive = selectedWalletId === w.id;
              return (
                <button
                  key={w.id}
                  onClick={() => setSelectedWalletId(w.id)}
                  className={`min-w-[160px] p-6 rounded-[2.5rem] border-2 transition-all flex flex-col items-center gap-4 relative overflow-hidden group ${isActive ? 'bg-primary/10 border-primary shadow-2xl scale-[1.02]' : 'bg-card-dark border-slate-800 hover:border-slate-700'}`}
                >
                  <div className={`flex items-center gap-2 px-3 py-1 rounded-full border ${meta.bg} ${meta.border}`}>
                     <span className={`material-symbols-outlined text-[14px] font-black ${meta.color}`}>{meta.icon}</span>
                     <span className={`text-[9px] font-black uppercase ${meta.color}`}>{w.asset}</span>
                  </div>
                  <div className="text-center">
                     <p className={`text-2xl font-black tracking-tighter ${isActive ? 'text-white' : 'text-slate-400'}`}>{w.balance.toFixed(2)}</p>
                     <p className="text-[8px] font-black text-slate-600 uppercase tracking-[0.1em] mt-0.5">Saldo Disponible</p>
                  </div>
                </button>
              );
            })}
          </div>
        </section>

        {/* AMOUNT CARD */}
        <section className="bg-card-dark border-2 border-slate-800 rounded-[3.5rem] p-10 space-y-8 shadow-2xl relative overflow-hidden text-center">
          <div className="space-y-6 relative z-10">
            <label className="text-[11px] font-black text-slate-500 uppercase tracking-[0.25em]">2. Monto a Liquidar</label>
            <div className="flex flex-col items-center gap-4">
               <div className="relative w-full">
                  <input 
                    type="number" 
                    className="w-full bg-transparent border-none p-0 text-7xl font-black text-white focus:ring-0 text-center tracking-tighter"
                    placeholder="0.00"
                    value={amount}
                    onChange={handleAmountChange}
                  />
                  <span className="absolute right-0 top-1/2 -translate-y-1/2 text-xl font-bold text-slate-600">{selectedWallet?.asset}</span>
               </div>
               <div className="flex items-center gap-2 bg-primary/10 px-4 py-2 rounded-xl border border-primary/20">
                 <span className="material-symbols-outlined text-sm text-primary">percent</span>
                 <p className="text-[10px] font-black text-primary uppercase">
                   Red Fee: {commissionRate}% (-{commissionAmount.toFixed(2)})
                 </p>
               </div>
            </div>
          </div>
          <div className="pt-8 border-t border-slate-800/50 flex justify-between items-center relative z-10">
             <div className="text-left">
                <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Recibirás Neto</p>
                <p className="text-xs text-slate-600 font-bold uppercase">Safe Settlement Protocol</p>
             </div>
             <p className="text-3xl font-black text-success-green tracking-tighter">
               {totalToReceive.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} 
               <span className="text-sm ml-2 opacity-50">{selectedWallet?.asset}</span>
             </p>
          </div>
        </section>

        {/* DESTINATION SELECTION */}
        <section className="space-y-5">
          <div className="flex justify-between items-center px-2">
            <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">3. Nodo de Destino (Endpoint)</h3>
          </div>
          
          <div className="grid grid-cols-1 gap-4">
             {bankCards.length > 0 && (
               <div className="space-y-4">
                  <p className="text-[9px] font-black text-slate-600 uppercase tracking-[0.3em] px-4">Métodos Vinculados</p>
                  {bankCards.map(card => (
                    <button 
                      key={card.id}
                      onClick={() => setSelectedCardId(card.id)}
                      className={`w-full p-6 rounded-[2.5rem] border-2 flex items-center justify-between transition-all ${selectedCardId === card.id ? 'bg-primary/10 border-primary' : 'bg-card-dark border-slate-800'}`}
                    >
                      <div className="flex items-center gap-4 text-left">
                        <div className={`size-12 rounded-xl ${card.color} flex items-center justify-center text-white`}><span className="material-symbols-outlined">credit_card</span></div>
                        <div>
                          <p className="text-sm font-black text-white uppercase">{card.brand} •••• {card.last4}</p>
                          <p className="text-[9px] text-slate-500 font-bold uppercase">{card.holder_name}</p>
                        </div>
                      </div>
                      <div className={`size-6 rounded-full border-2 flex items-center justify-center ${selectedCardId === card.id ? 'bg-primary border-primary' : 'border-slate-800'}`}>
                         {selectedCardId === card.id && <span className="material-symbols-outlined text-white text-[14px] font-black">check</span>}
                      </div>
                    </button>
                  ))}
               </div>
             )}

             <div className="space-y-4">
                <p className="text-[9px] font-black text-slate-600 uppercase tracking-[0.3em] px-4">Entrada Manual de Nodo</p>
                <button 
                  onClick={() => setSelectedCardId('external')}
                  className={`w-full p-6 rounded-[2.5rem] border-2 flex items-center justify-between transition-all ${selectedCardId === 'external' ? 'bg-primary/10 border-primary shadow-xl' : 'bg-card-dark border-slate-800'}`}
                >
                  <div className="flex items-center gap-4 text-left">
                    <div className="size-12 rounded-xl bg-slate-800 flex items-center justify-center text-slate-500 shadow-inner">
                      <span className="material-symbols-outlined">account_balance</span>
                    </div>
                    <div>
                      <p className="text-sm font-black text-white uppercase">Liquidación Externa</p>
                      <p className="text-[9px] text-slate-500 font-bold uppercase">Bancos / Redes Cripto / SWIFT</p>
                    </div>
                  </div>
                  <div className={`size-6 rounded-full border-2 flex items-center justify-center ${selectedCardId === 'external' ? 'bg-primary border-primary' : 'border-slate-800'}`}>
                       {selectedCardId === 'external' && <span className="material-symbols-outlined text-white text-[14px] font-black">check</span>}
                  </div>
                </button>
             </div>

             {selectedCardId === 'external' && (
               <div className="space-y-6 pt-2 animate-in slide-in-from-top-4 duration-500">
                  {/* Selector de Tipo */}
                  <div className="flex p-1.5 bg-slate-900 border border-slate-800 rounded-[2rem]">
                    <button onClick={() => setManualType('CRYPTO')} className={`flex-1 py-3 rounded-[1.5rem] text-[10px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2 ${manualType === 'CRYPTO' ? 'bg-primary text-white shadow-lg' : 'text-slate-500'}`}>
                      <span className="material-symbols-outlined text-base">token</span>
                      Nodo Cripto
                    </button>
                    <button onClick={() => setManualType('BANK')} className={`flex-1 py-3 rounded-[1.5rem] text-[10px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2 ${manualType === 'BANK' ? 'bg-primary text-white shadow-lg' : 'text-slate-500'}`}>
                      <span className="material-symbols-outlined text-base">account_balance</span>
                      Banca / SWIFT
                    </button>
                  </div>

                  <div className="grid grid-cols-1 gap-6 bg-card-dark p-8 rounded-[3rem] border border-slate-800 shadow-2xl">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-4">Titular de Recepción</label>
                      <input 
                        className="w-full bg-slate-950 border border-slate-800 rounded-2xl py-5 px-6 text-sm text-white focus:border-primary outline-none transition-all placeholder:text-slate-800 font-bold uppercase"
                        placeholder="Nombre Completo / Razón Social"
                        value={extRecipient}
                        onChange={e => setExtRecipient(e.target.value)}
                      />
                    </div>

                    {manualType === 'BANK' && (
                      <div className="space-y-2 animate-in zoom-in duration-300">
                        <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-4">Entidad Financiera</label>
                        <input 
                          className="w-full bg-slate-950 border border-slate-800 rounded-2xl py-5 px-6 text-sm text-white focus:border-primary outline-none transition-all placeholder:text-slate-800 uppercase font-bold"
                          placeholder="E.g. Tinkoff, Sberbank, Revolut"
                          value={extBankName}
                          onChange={e => setExtBankName(e.target.value)}
                        />
                      </div>
                    )}

                    <div className="space-y-6">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-4">
                          {manualType === 'BANK' ? 'Cuenta / IBAN / Tarjeta' : 'Dirección del Wallet (Wallet Address)'}
                        </label>
                        <div className="relative">
                           <input 
                             className="w-full bg-slate-950 border border-slate-800 rounded-2xl py-5 px-6 text-xs text-white font-mono focus:border-primary outline-none transition-all placeholder:text-slate-800"
                             placeholder={manualType === 'BANK' ? '9200... / IBAN...' : 'bc1q... / 0x... / TMd...'}
                             value={extAccountNumber}
                             onChange={e => setExtAccountNumber(e.target.value)}
                           />
                           <span className="absolute right-6 top-1/2 -translate-y-1/2 material-symbols-outlined text-slate-700">qr_code_scanner</span>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-4">
                          {manualType === 'BANK' ? 'BIC-SWIFT / Routing Number' : 'Red de Liquidación (Network)'}
                        </label>
                        <div className="relative">
                          <input 
                            className="w-full bg-slate-950 border border-slate-800 rounded-2xl py-5 px-6 text-xs text-white font-mono focus:border-primary outline-none transition-all uppercase placeholder:text-slate-800"
                            placeholder={manualType === 'BANK' ? 'SWIFTRUXX' : 'E.g. TRC20, ERC20, BEP20'}
                            value={extRoutingNetwork}
                            onChange={e => setExtRoutingNetwork(e.target.value)}
                          />
                          <span className="absolute right-6 top-1/2 -translate-y-1/2 material-symbols-outlined text-slate-700">hub</span>
                        </div>
                        {manualType === 'CRYPTO' && (
                          <p className="text-[8px] font-bold text-slate-600 px-4 uppercase tracking-tighter mt-1">
                            Asegúrate de que la red coincida con la dirección para evitar pérdida de fondos.
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
               </div>
             )}
          </div>
        </section>

        {/* SECURITY WARNING */}
        <section className="bg-amber-500/5 border border-amber-500/20 rounded-[3rem] p-8 flex gap-6 items-start shadow-inner">
           <div className="size-14 rounded-3xl bg-amber-500/10 flex items-center justify-center text-amber-500 shrink-0 border border-amber-500/10 shadow-lg">
             <span className="material-symbols-outlined text-3xl font-black">verified_user</span>
           </div>
           <div className="space-y-1">
             <h4 className="text-[10px] font-black text-white uppercase tracking-widest">Protocolo de Auditoría</h4>
             <p className="text-[10px] text-slate-500 leading-relaxed font-bold uppercase tracking-tight">
               Toda liquidación externa es auditada manualmente por el nodo central. Tiempo estimado: <span className="text-white">60 - 240 minutos</span>.
             </p>
           </div>
        </section>

        {/* SUBMIT BUTTON */}
        <button 
          onClick={handleWithdrawInitiation}
          disabled={!amount || !isManualValid || isProcessing || !selectedWallet}
          className={`w-full py-9 rounded-[3rem] font-black text-base uppercase tracking-[0.3em] transition-all active:scale-95 shadow-2xl flex items-center justify-center gap-5 ${
            amount && isManualValid && !isProcessing
              ? 'bg-primary text-white shadow-[0_25px_50px_-12px_rgba(19,109,236,0.4)]' 
              : 'bg-slate-800 text-slate-600 cursor-not-allowed opacity-40 grayscale'
          }`}
        >
          {isProcessing ? (
             <span className="size-7 border-4 border-white/30 border-t-white rounded-full animate-spin"></span>
          ) : (
            <>
              Confirmar Retiro
              <span className="material-symbols-outlined font-black text-2xl transition-transform group-hover:translate-x-1">rocket_launch</span>
            </>
          )}
        </button>
      </div>

      {/* 2FA RE-AUTHENTICATION MODAL */}
      {is2FAModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center px-4">
          <div className="absolute inset-0 bg-background-dark/95 backdrop-blur-md animate-in fade-in duration-300" onClick={() => !isVerifying2FA && setIs2FAModalOpen(false)}></div>
          <div className="relative w-full max-w-[380px] bg-card-dark rounded-[3rem] border border-slate-800 shadow-2xl p-10 animate-in zoom-in duration-300 space-y-8">
            <header className="text-center space-y-4">
               <div className="size-16 rounded-2xl bg-amber-500/10 flex items-center justify-center mx-auto text-amber-500 border border-amber-500/20">
                  <span className="material-symbols-outlined text-4xl">shield_lock</span>
               </div>
               <div>
                  <h3 className="text-xl font-black text-white uppercase tracking-tight italic">Autorización 2FA</h3>
                  <p className="text-[10px] font-black text-slate-500 font-bold uppercase tracking-widest mt-1">Se requiere verificación para retirar</p>
               </div>
            </header>

            <div className="space-y-6">
                <p className="text-[11px] text-center text-slate-400 font-medium leading-relaxed">
                  Introduce el código enviado a tu Telegram <span className="text-primary">{userProfile?.telegram_handle}</span> para autorizar esta liquidación.
                </p>
                <div className="space-y-2">
                    <input 
                      type="text"
                      maxLength={6}
                      className="w-full bg-slate-950 border border-slate-800 rounded-2xl py-5 px-6 text-3xl font-black text-white focus:border-primary outline-none transition-all text-center font-mono tracking-[0.5em] placeholder:text-slate-900"
                      placeholder="000000"
                      value={otpCode}
                      onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ''))}
                    />
                </div>
                <button 
                  onClick={handle2FAVerification}
                  disabled={isVerifying2FA || otpCode.length !== 6}
                  className="w-full py-6 bg-primary text-white rounded-[1.5rem] font-black text-xs uppercase tracking-[0.2em] shadow-xl active:scale-95 disabled:opacity-30 flex items-center justify-center gap-3"
                >
                  {isVerifying2FA ? <span className="size-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span> : <>Autorizar Liquidación <span className="material-symbols-outlined text-base">verified_user</span></>}
                </button>
                <button onClick={() => setIs2FAModalOpen(false)} className="w-full text-[9px] font-black text-slate-500 uppercase hover:text-white transition-colors">Abortar</button>
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
};

export default Withdraw;
