
import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Layout } from '../components/Layout';
import { getMarketUpdate } from '../services/geminiService';
import { supabase } from '../services/supabase';
import { BankCard } from '../types';

type TransferType = 'NATIONAL' | 'INTERNATIONAL';
type PaymentSource = 'BALANCE' | 'CARD';

const SendMoney: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  
  const initialState = location.state as { 
    asset?: string, 
    amount?: string,
    recipient?: any
  } | null;

  const [rates, setRates] = useState<any>({ 'USD_RUB': 92.45, 'RUB_CUP': 4.15, 'USD_CUP': 325.00 });
  const [userBalances, setUserBalances] = useState<any[]>([]);
  const [linkedCards, setLinkedCards] = useState<BankCard[]>([]);
  const [paymentSource, setPaymentSource] = useState<PaymentSource>('BALANCE');
  const [selectedCardId, setSelectedCardId] = useState<string | null>(null);

  // Form States
  const [fromAsset, setFromAsset] = useState(initialState?.asset || 'RUB');
  const [amount, setAmount] = useState(initialState?.amount || '');
  const [recipientName, setRecipientName] = useState(initialState?.recipient?.name || '');
  const [accountNumber, setAccountNumber] = useState(initialState?.recipient?.account || '');
  const [transferType, setTransferType] = useState<TransferType>('NATIONAL');
  const [purpose, setPurpose] = useState('FAMILIAR');
  const [countryCode, setCountryCode] = useState('+53');
  const [phoneNumber, setPhoneNumber] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session) {
        const { data: b } = await supabase.from('wallet_balances').select('*').eq('user_id', session.user.id);
        const { data: c } = await supabase.from('bank_cards').select('*').eq('user_id', session.user.id);
        if (b) setUserBalances(b);
        if (c) {
          setLinkedCards(c);
          if (c.length > 0) {
            setSelectedCardId(c[0].id);
          }
        }
      }
      const update = await getMarketUpdate();
      if (update?.rates) setRates(update.rates);
    };
    fetchData();
  }, []);

  const currentBalance = useMemo(() => {
    const b = userBalances.find(w => w.asset === fromAsset);
    return b ? parseFloat(b.balance) : 0;
  }, [userBalances, fromAsset]);

  const commission = useMemo(() => (parseFloat(amount) || 0) * 0.009, [amount]);
  const totalToPay = useMemo(() => (parseFloat(amount) || 0) + commission, [amount, commission]);
  
  const hasInsufficientBalance = useMemo(() => totalToPay > currentBalance, [totalToPay, currentBalance]);

  // Lógica de "Pago Directo": Si el balance es insuficiente pero hay tarjeta, cambiar a Tarjeta automáticamente
  useEffect(() => {
    if (hasInsufficientBalance && linkedCards.length > 0) {
      setPaymentSource('CARD');
    } else if (!hasInsufficientBalance) {
      setPaymentSource('BALANCE');
    }
  }, [hasInsufficientBalance, linkedCards]);

  const receivedAmount = useMemo(() => {
    const val = parseFloat(amount) || 0;
    if (fromAsset === 'RUB' && transferType === 'NATIONAL') return (val * rates.RUB_CUP).toFixed(2);
    if (fromAsset === 'RUB' && transferType === 'INTERNATIONAL') return (val / rates.USD_RUB).toFixed(2);
    return val.toFixed(2);
  }, [amount, fromAsset, transferType, rates]);

  const handleContinue = () => {
    const selectedCard = linkedCards.find(c => c.id === selectedCardId);
    navigate('/confirm', { 
      state: { 
        amount: parseFloat(amount), 
        asset: fromAsset,
        total: totalToPay,
        commission,
        paymentSource,
        selectedCard,
        recipient: { 
          name: recipientName, 
          account: accountNumber, 
          phone: `${countryCode} ${phoneNumber}`, 
          purpose 
        },
        targetAsset: transferType === 'NATIONAL' ? 'CUP' : 'USD',
        receivedAmount: receivedAmount
      } 
    });
  };

  const purposes = [
    { id: 'FAMILIAR', label: 'Ayuda Familiar', icon: 'family_restroom' },
    { id: 'SERVICES', label: 'Pago de Servicios', icon: 'receipt_long' },
    { id: 'BUSINESS', label: 'Negocios / Pyme', icon: 'business_center' },
    { id: 'SAVINGS', label: 'Ahorro Personal', icon: 'savings' }
  ];

  return (
    <Layout hideNav>
      <header className="px-4 py-4 glass-header sticky top-0 z-50 flex items-center justify-between">
        <button onClick={() => navigate(-1)} className="size-11 flex items-center justify-center rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-500 shadow-sm active:scale-90 transition-all">
          <span className="material-symbols-outlined text-[20px]">arrow_back_ios_new</span>
        </button>
        <div className="text-center">
          <h2 className="text-[10px] font-black text-slate-900 dark:text-white uppercase tracking-widest italic leading-none">SafeTransfer Bridge</h2>
          <p className="text-[7px] font-black text-primary uppercase tracking-[0.3em] mt-1">Envío de Fondos</p>
        </div>
        <div className="size-11"></div>
      </header>
      
      <main className="p-4 space-y-6 pb-40 animate-in fade-in duration-500">
        {/* MONTO */}
        <section className="bg-white dark:bg-app-card-dark border border-slate-200 dark:border-white/5 rounded-[3rem] p-10 shadow-2xl space-y-8 text-center">
          <div className="space-y-2">
            <p className="text-[9px] font-black text-slate-500 uppercase tracking-[0.4em]">Monto del Envío</p>
            <div className="flex items-center justify-center gap-3">
               <input 
                className="bg-transparent border-none p-0 text-7xl font-black text-slate-900 dark:text-white focus:ring-0 text-center tracking-tighter w-full max-w-[280px]" 
                type="number" 
                placeholder="0.00" 
                value={amount} 
                onChange={(e) => setAmount(e.target.value)} 
                autoFocus
              />
              <span className="text-xl font-black text-primary">{fromAsset}</span>
            </div>
          </div>
          
          <div className="pt-6 border-t border-slate-100 dark:border-white/5 flex justify-between items-center">
             <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-sm text-slate-400">account_balance_wallet</span>
                <p className="text-[9px] font-bold text-slate-500 uppercase">Balance en Nodo:</p>
             </div>
             <p className={`text-[10px] font-black ${hasInsufficientBalance ? 'text-red-500' : 'text-green-500'}`}>
               {currentBalance.toFixed(2)} {fromAsset}
             </p>
          </div>
        </section>

        {/* ORIGEN DE FONDOS */}
        <section className="space-y-4">
           <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-2">Fuente de Fondos</h3>
           <div className="grid grid-cols-1 gap-3">
              <button 
                onClick={() => !hasInsufficientBalance && setPaymentSource('BALANCE')}
                className={`p-5 rounded-[2rem] border-2 transition-all flex items-center justify-between ${paymentSource === 'BALANCE' ? 'border-primary bg-primary/5 shadow-lg' : 'border-slate-100 dark:border-white/5 bg-white dark:bg-app-card-dark opacity-60'}`}
              >
                 <div className="flex items-center gap-4 text-left">
                    <div className="size-11 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500">
                       <span className="material-symbols-outlined">account_balance_wallet</span>
                    </div>
                    <div>
                       <p className="text-xs font-black text-slate-900 dark:text-white uppercase">Saldo del Nodo</p>
                       <p className="text-[9px] text-slate-500 font-bold uppercase">Balance disponible</p>
                    </div>
                 </div>
                 {hasInsufficientBalance && <span className="text-[8px] font-black text-red-500 uppercase bg-red-500/10 px-2 py-1 rounded-lg">Bajo</span>}
              </button>

              <button 
                onClick={() => linkedCards.length > 0 ? setPaymentSource('CARD') : navigate('/profile')}
                className={`p-5 rounded-[2rem] border-2 transition-all flex items-center justify-between ${paymentSource === 'CARD' ? 'border-primary bg-primary/5 shadow-lg' : 'border-slate-100 dark:border-white/5 bg-white dark:bg-app-card-dark'}`}
              >
                 <div className="flex items-center gap-4 text-left">
                    <div className="size-11 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                       <span className="material-symbols-outlined">credit_card</span>
                    </div>
                    <div>
                       <p className="text-xs font-black text-slate-900 dark:text-white uppercase">Tarjeta Directa</p>
                       <p className="text-[9px] text-slate-500 font-bold uppercase">
                         {linkedCards.length > 0 ? `Liquidación: •• ${linkedCards[0].last4}` : 'Añadir Tarjeta'}
                       </p>
                    </div>
                 </div>
                 {linkedCards.length === 0 && <span className="material-symbols-outlined text-primary animate-pulse">add_circle</span>}
              </button>
           </div>
        </section>

        {/* BENEFICIARIO */}
        <section className="space-y-4">
           <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-2">Datos del Beneficiario</h3>
           
           <div className="flex p-1 bg-slate-100 dark:bg-slate-900/80 rounded-2xl border border-slate-200 dark:border-white/5">
              {(['NATIONAL', 'INTERNATIONAL'] as TransferType[]).map(t => (
                <button 
                  key={t}
                  onClick={() => setTransferType(t)}
                  className={`flex-1 py-3 px-2 rounded-xl text-[9px] font-black uppercase transition-all ${transferType === t ? 'bg-white dark:bg-app-card-dark text-primary shadow-sm' : 'text-slate-400'}`}
                >
                  {t === 'NATIONAL' ? 'CUP' : 'USD/RUB'}
                </button>
              ))}
           </div>

           <div className="bg-white dark:bg-app-card-dark border border-slate-200 dark:border-white/5 rounded-[2.5rem] p-8 space-y-6 shadow-xl">
              <div className="space-y-2">
                 <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest px-2">Nombre</label>
                 <input type="text" placeholder="NOMBRE COMPLETO" className="w-full bg-slate-50 dark:bg-slate-950 border-none rounded-2xl py-4 px-6 text-sm font-black uppercase" value={recipientName} onChange={e => setRecipientName(e.target.value)} />
              </div>

              <div className="space-y-2">
                 <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest px-2">Cuenta / Tarjeta</label>
                 <input type="text" placeholder="NÚMERO DE CUENTA" className="w-full bg-slate-50 dark:bg-slate-950 border-none rounded-2xl py-4 px-6 text-sm font-mono font-bold" value={accountNumber} onChange={e => setAccountNumber(e.target.value)} />
              </div>

              <div className="grid grid-cols-4 gap-3">
                 <div className="space-y-2">
                    <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest px-2">Cód.</label>
                    <input type="text" className="w-full bg-slate-50 dark:bg-slate-950 border-none rounded-2xl py-4 px-2 text-center text-sm font-bold" value={countryCode} onChange={e => setCountryCode(e.target.value)} />
                 </div>
                 <div className="col-span-3 space-y-2">
                    <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest px-2">WhatsApp / Teléfono</label>
                    <input type="tel" placeholder="5XXXXXXX" className="w-full bg-slate-50 dark:bg-slate-950 border-none rounded-2xl py-4 px-6 text-sm font-bold" value={phoneNumber} onChange={e => setPhoneNumber(e.target.value)} />
                 </div>
              </div>
           </div>
        </section>

        {/* MOTIVO */}
        <section className="space-y-4">
           <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-2">Motivo del Envío</h3>
           <div className="grid grid-cols-2 gap-3">
              {purposes.map(p => (
                <button 
                  key={p.id}
                  onClick={() => setPurpose(p.id)}
                  className={`p-4 rounded-2xl border-2 transition-all flex flex-col items-center gap-2 ${purpose === p.id ? 'border-primary bg-primary/5' : 'bg-white dark:bg-app-card-dark border-slate-100 dark:border-white/5 opacity-60'}`}
                >
                   <span className="material-symbols-outlined text-xl">{p.icon}</span>
                   <span className="text-[9px] font-black uppercase">{p.label}</span>
                </button>
              ))}
           </div>
        </section>

        <section className="bg-slate-900 rounded-[2.5rem] p-8 space-y-4 shadow-2xl relative overflow-hidden">
           <div className="absolute top-0 right-0 p-6 opacity-5"><span className="material-symbols-outlined text-6xl text-white">receipt_long</span></div>
           <div className="flex justify-between items-center px-1 relative z-10">
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Resumen de Recepción</p>
              <p className="text-[8px] font-black text-primary uppercase">SafeNode Fee: 0.9%</p>
           </div>
           <div className="flex justify-between items-baseline relative z-10">
              <h4 className="text-white font-black text-3xl tracking-tighter uppercase italic">{receivedAmount}</h4>
              <p className="text-xl font-black text-primary uppercase">{transferType === 'NATIONAL' ? 'CUP' : 'USD'}</p>
           </div>
        </section>

        <button 
          onClick={handleContinue} 
          disabled={!amount || !recipientName || !accountNumber || (paymentSource === 'BALANCE' && hasInsufficientBalance && linkedCards.length === 0)} 
          className="w-full py-8 bg-primary text-white rounded-[2.5rem] font-black uppercase text-[12px] tracking-[0.3em] shadow-2xl shadow-primary/30 disabled:opacity-30 disabled:grayscale transition-all active:scale-[0.98] flex items-center justify-center gap-4"
        >
          Confirmar y Enviar <span className="material-symbols-outlined text-xl">bolt</span>
        </button>
        
        <p className="text-center text-[8px] text-slate-500 font-black uppercase tracking-widest px-10 leading-relaxed">
          {paymentSource === 'CARD' ? 'Liquidación directa mediante tarjeta vinculada.' : 'Débito desde el balance acumulado en tu nodo.'}
        </p>
      </main>
    </Layout>
  );
};

export default SendMoney;
