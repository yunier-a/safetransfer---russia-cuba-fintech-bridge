
import React from 'react';
import { useLocation, Link } from 'react-router-dom';

interface LayoutProps {
  children: React.ReactNode;
  hideNav?: boolean;
}

const BottomNav = () => {
  const location = useLocation();
  const getActive = (path: string) => location.pathname === path;
  
  return (
    <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[430px] bg-white/90 dark:bg-app-bg-dark/90 backdrop-blur-2xl border-t border-slate-200/50 dark:border-white/5 px-2 py-2.5 pb-6 flex justify-between items-center z-50 shadow-[0_-10px_30px_rgba(0,0,0,0.05)] dark:shadow-none">
      <Link to="/" className={`flex flex-col items-center gap-1 flex-1 transition-all ${getActive('/') ? 'text-primary' : 'text-slate-400 dark:text-slate-700'}`}>
        <span className={`material-symbols-outlined text-[24px] ${getActive('/') ? 'icon-brilliant scale-110' : ''}`} style={{fontVariationSettings: getActive('/') ? "'FILL' 1" : "'FILL' 0"}}>home</span>
        <span className="text-[7px] font-black uppercase tracking-widest">Home</span>
      </Link>
      <Link to="/activity" className={`flex flex-col items-center gap-1 flex-1 transition-all ${getActive('/activity') ? 'text-primary' : 'text-slate-400 dark:text-slate-700'}`}>
        <span className={`material-symbols-outlined text-[24px] ${getActive('/activity') ? 'icon-brilliant scale-110' : ''}`} style={{fontVariationSettings: getActive('/activity') ? "'FILL' 1" : "'FILL' 0"}}>history</span>
        <span className="text-[7px] font-black uppercase tracking-widest">Actividad</span>
      </Link>
      <Link to="/exchange" className={`flex flex-col items-center gap-1 flex-1 transition-all ${getActive('/exchange') ? 'text-primary' : 'text-slate-400 dark:text-slate-700'}`}>
        <div className={`size-12 -mt-6 rounded-2xl flex items-center justify-center shadow-2xl transition-all ${getActive('/exchange') ? 'bg-primary text-white scale-110 shadow-primary/30' : 'bg-slate-900 text-slate-500'}`}>
          <span className="material-symbols-outlined text-[26px]">swap_horiz</span>
        </div>
        <span className="text-[7px] font-black uppercase tracking-widest mt-1">Cambiar</span>
      </Link>
      <Link to="/safe-zones" className={`flex flex-col items-center gap-1 flex-1 transition-all ${getActive('/safe-zones') ? 'text-primary' : 'text-slate-400 dark:text-slate-700'}`}>
        <span className={`material-symbols-outlined text-[24px] ${getActive('/safe-zones') ? 'icon-brilliant scale-110' : ''}`} style={{fontVariationSettings: getActive('/safe-zones') ? "'FILL' 1" : "'FILL' 0"}}>verified_user</span>
        <span className="text-[7px] font-black uppercase tracking-widest">Seguridad</span>
      </Link>
      <Link to="/profile" className={`flex flex-col items-center gap-1 flex-1 transition-all ${getActive('/profile') ? 'text-primary' : 'text-slate-400 dark:text-slate-700'}`}>
        <span className={`material-symbols-outlined text-[24px] ${getActive('/profile') ? 'icon-brilliant scale-110' : ''}`} style={{fontVariationSettings: getActive('/profile') ? "'FILL' 1" : "'FILL' 0"}}>person</span>
        <span className="text-[7px] font-black uppercase tracking-widest">Perfil</span>
      </Link>
    </nav>
  );
};

export const Layout: React.FC<LayoutProps> = ({ children, hideNav = false }) => {
  return (
    <div className="relative flex h-screen w-full flex-col max-w-[430px] mx-auto overflow-hidden border-x border-slate-200/40 dark:border-white/5 bg-app-bg-light dark:bg-app-bg-dark shadow-2xl">
      {/* Dynamic Currency Background Layer - Only visible in light mode */}
      <div className="animated-currency-bg dark:hidden"></div>
      
      <div className="relative flex-1 overflow-y-auto hide-scrollbar z-10">
        {children}
      </div>
      
      {!hideNav && <BottomNav />}
      
      <div className="mt-auto flex justify-center pb-1 bg-white/50 dark:bg-app-bg-dark/50 backdrop-blur-sm z-20">
        <div className="w-24 h-1 bg-slate-200 dark:bg-white/10 rounded-full"></div>
      </div>
    </div>
  );
};
