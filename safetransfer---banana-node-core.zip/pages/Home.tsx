
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Layout } from '../components/Layout';
import { supabase } from '../services/supabase';
import { getDailyBriefing, getMarketUpdate } from '../services/geminiService';
import { BananaAvatar } from './BotChat';
import { AudioService } from '../services/audioService';

const Home: React.FC = () => {
  const navigate = useNavigate();
  const [totalBalance, setTotalBalance] = useState(0);
  const [userWallets, setUserWallets] = useState<any[]>([]);
  const [isLoadingData, setIsLoadingData] = useState(true);
  const [briefing, setBriefing] = useState<{ text: string, links: any[] } | null>(null);
  
  const [isDark, setIsDark] = useState(() => document.documentElement.classList.contains('dark'));

  useEffect(() => {
    const checkAuth = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        navigate('/login');
        return;
      }
      await fetchData(session);
    };
    checkAuth();
  }, [navigate]);

  const fetchData = async (session: any) => {
    setIsLoadingData(true);
    try {
      const market = await getMarketUpdate();
      const rates = market?.rates || { 'USD_RUB': 92, 'RUB_CUP': 4.1, 'USDT_RUB': 93, 'BTC_USD': 67000 };

      const { data: balances, error } = await supabase
        .from('wallet_balances')
        .select('*')
        .eq('user_id', session.user.id);

      if (balances && !error) {
        const totalInRub = balances.reduce((acc, curr) => {
          let rate = 1;
          if (curr.asset === 'CUP') rate = 1 / rates.RUB_CUP;
          else if (curr.asset === 'USDT' || curr.asset === 'USD') rate = rates.USD_RUB;
          else if (curr.asset === 'BTC') rate = rates.BTC_USD * rates.USD_RUB;
          return acc + (Number(curr.balance) * rate);
        }, 0);
        setTotalBalance(totalInRub);
        setUserWallets(balances);
      }
    } catch (e) {
      console.error("Error sync:", e);
    } finally {
      setIsLoadingData(false);
    }

    const news = await getDailyBriefing();
    setBriefing(news);
  };

  const toggleTheme = () => {
    AudioService.playClick();
    const next = !isDark;
    setIsDark(next);
    document.documentElement.classList.toggle('dark', next);
    localStorage.setItem('st_theme', next ? 'dark' : 'light');
  };

  const secondaryActions = [
    { id: 'remit', icon: 'send', label: 'Enviar', path: '/send', color: 'bg-blue-500/10 text-blue-600 dark:text-blue-500' },
    { id: 'rewards', icon: 'workspace_premium', label: 'Premios', path: '/rewards', color: 'bg-amber-500/10 text-amber-600 dark:text-amber-500' },
    { id: 'withdraw', icon: 'output', label: 'Retirar', path: '/withdraw', color: 'bg-orange-500/10 text-orange-600 dark:text-orange-500' },
    { id: 'vault', icon: 'lock', label: 'Bóveda', path: '/vault', color: 'bg-indigo-500/10 text-indigo-600 dark:text-indigo-500' },
  ];

  return (
    <Layout>
      <header className="px-4 py-3 glass-header sticky top-0 z-50 flex items-center justify-between">
        <div className="flex items-center gap-3">
           <button onClick={() => { AudioService.playClick(); navigate('/bot'); }} className="active:scale-90 transition-transform">
             <BananaAvatar size="size-11" />
           </button>
           <button onClick={toggleTheme} className="size-10 rounded-xl bg-slate-100 dark:bg-slate-900 flex items-center justify-center text-slate-500 dark:text-amber-400 border border-slate-200 dark:border-white/5 active:scale-90">
              <span className="material-symbols-outlined text-[20px]">{isDark ? 'light_mode' : 'dark_mode'}</span>
           </button>
        </div>
        
        <div className="flex-1 text-center pr-4">
          <h2 className="text-slate-900 dark:text-white text-[10px] font-black uppercase tracking-widest leading-none">SafeTransfer</h2>
          <div className="flex items-center justify-center gap-1.5 mt-0.5">
            <div className={`size-1.5 rounded-full ${isLoadingData ? 'bg-amber-500 animate-pulse' : 'bg-green-500 shadow-[0_0_10px_#22c55e]'}`}></div>
            <p className="text-[7px] font-black text-slate-500 uppercase tracking-widest">
              {isLoadingData ? 'Sincronizando...' : 'Bridge: Online'}
            </p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <button onClick={() => { AudioService.playClick(); navigate('/support'); }} className="size-10 bg-white dark:bg-app-card-dark rounded-xl flex items-center justify-center text-slate-400 border border-slate-200 dark:border-white/5 shadow-sm active:scale-90 transition-transform">
            <span className="material-symbols-outlined text-[22px]">help</span>
          </button>
          <button onClick={() => { AudioService.playClick(); navigate('/notifications'); }} className="size-10 bg-white dark:bg-app-card-dark rounded-xl flex items-center justify-center text-slate-400 relative border border-slate-200 dark:border-white/5 shadow-sm active:scale-90 transition-transform">
            <span className="material-symbols-outlined text-[22px]">notifications</span>
            <div className="absolute top-2.5 right-2.5 size-1.5 bg-primary rounded-full border-2 border-white dark:border-slate-900"></div>
          </button>
        </div>
      </header>

      <div className="p-4 space-y-6 pb-28">
        <section className="bg-gradient-to-br from-slate-900 to-slate-950 dark:from-app-card-dark dark:to-black rounded-[2.5rem] p-8 shadow-2xl relative overflow-hidden group">
           <div className="absolute top-0 right-0 p-8 opacity-5">
              <span className="material-symbols-outlined text-[120px] text-primary">account_balance_wallet</span>
           </div>
           <div className="relative z-10 space-y-2">
              <p className="text-[9px] font-black text-slate-500 uppercase tracking-[0.3em]">Capital Consolidado</p>
              <div className="flex items-baseline gap-2">
                 <span className="text-primary text-2xl font-black">₽</span>
                 <h2 className="text-5xl font-black text-white tracking-tighter">
                   {totalBalance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                 </h2>
              </div>
           </div>
        </section>

        <div className="grid grid-cols-2 gap-4">
          <button onClick={() => { AudioService.playClick(); navigate('/deposit'); }} className="bg-white dark:bg-app-card-dark border-2 border-green-500/20 p-6 rounded-[2rem] flex flex-col items-center gap-3 active:scale-[0.97] transition-all shadow-lg group">
             <div className="bg-green-500 text-white size-14 rounded-2xl flex items-center justify-center shadow-xl shadow-green-500/30 group-hover:scale-110 transition-transform">
                <span className="material-symbols-outlined text-3xl font-bold">add_card</span>
             </div>
             <div className="text-center">
                <span className="text-xs font-black text-slate-900 dark:text-white uppercase tracking-widest">Depositar</span>
                <p className="text-[8px] text-green-500 font-bold uppercase mt-0.5">RUB / USDT</p>
             </div>
          </button>
          <button onClick={() => { AudioService.playClick(); navigate('/recharge'); }} className="bg-white dark:bg-app-card-dark border-2 border-cyan-500/20 p-6 rounded-[2rem] flex flex-col items-center gap-3 active:scale-[0.97] transition-all shadow-lg group">
             <div className="bg-cyan-500 text-white size-14 rounded-2xl flex items-center justify-center shadow-xl shadow-cyan-500/30 group-hover:scale-110 transition-transform">
                <span className="material-symbols-outlined text-3xl font-bold">phone_iphone</span>
             </div>
             <div className="text-center">
                <span className="text-xs font-black text-slate-900 dark:text-white uppercase tracking-widest">Recargar</span>
                <p className="text-[8px] text-cyan-500 font-bold uppercase mt-0.5">Móvil Cuba</p>
             </div>
          </button>
        </div>

        <div className="grid grid-cols-4 gap-3">
          {secondaryActions.map(btn => (
            <button key={btn.id} onClick={() => { AudioService.playClick(); navigate(btn.path); }} className="bg-white dark:bg-app-card-dark border border-slate-200 dark:border-white/5 p-3 rounded-2xl flex flex-col items-center gap-2 active:scale-[0.97] transition-all shadow-sm group">
              <div className={`${btn.color} size-10 rounded-xl flex items-center justify-center border border-white/5 group-hover:shadow-glow transition-all`}>
                <span className="material-symbols-outlined text-[20px] font-black">{btn.icon}</span>
              </div>
              <span className="text-[8px] font-black text-slate-700 dark:text-slate-300 uppercase tracking-tighter text-center">{btn.label}</span>
            </button>
          ))}
        </div>

        {briefing && (
          <section className="bg-slate-900 rounded-3xl border border-white/5 p-6 space-y-4 shadow-2xl relative overflow-hidden group">
             <div className="absolute top-0 right-0 p-4 opacity-5">
                <span className="material-symbols-outlined text-7xl text-primary">analytics</span>
             </div>
             <p className="text-xs text-slate-300 leading-relaxed font-medium italic relative z-10">
                {briefing.text}
             </p>
          </section>
        )}
      </div>
    </Layout>
  );
};

export default Home;
