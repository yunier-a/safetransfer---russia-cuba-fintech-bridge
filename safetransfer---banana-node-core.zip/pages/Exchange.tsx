
import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Layout } from '../components/Layout';
import { getMarketUpdate, getNeuralMarketSignal } from '../services/geminiService';
import { NotificationService } from '../services/notificationService';

const Exchange: React.FC = () => {
  const navigate = useNavigate();
  const assetIcons: Record<string, string> = {
    'RUB': 'https://raw.githubusercontent.com/spothq/cryptocurrency-icons/master/128/color/rub.png',
    'CUP': 'https://flagcdn.com/w80/cu.png',
    'USD': 'https://flagcdn.com/w80/us.png',
    'EUR': 'https://flagcdn.com/w80/eu.png',
    'USDT': 'https://raw.githubusercontent.com/spothq/cryptocurrency-icons/master/128/color/usdt.png'
  };

  const [rates, setRates] = useState<any>({ 'USD_RUB': 92.45, 'RUB_CUP': 4.15, 'USD_CUP': 325.00 });
  const [fromAsset, setFromAsset] = useState('RUB');
  const [toAsset, setToAsset] = useState('CUP');
  const [swapAmount, setSwapAmount] = useState('1000.00');
  const [isSyncing, setIsSyncing] = useState(true);

  const [neuralSignal, setNeuralSignal] = useState<any>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  useEffect(() => {
    const fetch = async () => {
      setIsSyncing(true);
      const update = await getMarketUpdate();
      if (update?.rates) setRates(update.rates);
      setIsSyncing(false);
      triggerNeuralScan();
    };
    fetch();
    const int = setInterval(fetch, 60000);
    return () => clearInterval(int);
  }, []);

  const triggerNeuralScan = async () => {
    setIsAnalyzing(true);
    const signal = await getNeuralMarketSignal();
    if (signal) setNeuralSignal(signal);
    setIsAnalyzing(false);
  };

  const calculatedRate = useMemo(() => {
    const getToUSD = (a: string) => {
        if (a === 'USD') return 1;
        if (a === 'RUB') return 1 / rates.USD_RUB;
        if (a === 'CUP') return 1 / rates.USD_CUP;
        return 1;
    };
    return getToUSD(fromAsset) / getToUSD(toAsset);
  }, [fromAsset, toAsset, rates]);

  const commission = useMemo(() => {
    const val = parseFloat(swapAmount || '0');
    return val * 0.009;
  }, [swapAmount]);

  const receivedNet = useMemo(() => {
    const val = parseFloat(swapAmount || '0');
    return (val * calculatedRate).toFixed(2);
  }, [swapAmount, calculatedRate]);

  return (
    <Layout>
      <header className="p-4 pt-8 glass-header sticky top-0 z-50 flex justify-between items-center">
        <div className="flex items-center gap-3">
           <div className="size-9 rounded-xl bg-slate-800 flex items-center justify-center border border-white/5">
              <span className={`material-symbols-outlined text-white text-xl ${isSyncing ? 'animate-spin' : ''}`}>sync</span>
           </div>
           <div>
             <h1 className="text-sm font-black text-slate-900 dark:text-white uppercase tracking-widest italic">Intercambio</h1>
             <p className="text-[7px] font-black text-slate-500 uppercase tracking-widest mt-0.5">Real-Time Settle</p>
           </div>
        </div>
      </header>

      <div className="p-4 space-y-6 pb-32 animate-in fade-in duration-500">
        <section className="bg-slate-900 border border-white/10 rounded-2xl p-6 shadow-xl relative overflow-hidden group">
          <div className="relative z-10 space-y-2">
            <div className="flex justify-between items-center">
               <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest">Monitor Global</p>
               <span className="text-[8px] font-black text-green-500 uppercase flex items-center gap-1.5"><div className="size-1 bg-green-500 rounded-full animate-pulse"></div> Verified</span>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-4xl font-black text-white font-mono tracking-tighter">
                {calculatedRate.toFixed(4)}
              </span>
              <span className="text-slate-500 font-bold text-[10px] uppercase">{toAsset} / {fromAsset}</span>
            </div>
          </div>
        </section>

        <section className="bg-white dark:bg-app-card-dark border border-slate-200 dark:border-white/5 rounded-3xl p-6 space-y-6 shadow-md relative overflow-hidden">
          <div className="space-y-3">
            <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest px-2">Vender</label>
            <div className="flex items-center gap-3 bg-slate-50 dark:bg-slate-950 p-4 rounded-2xl border border-slate-200 dark:border-white/5 shadow-inner">
              <input type="number" className="bg-transparent border-none p-0 text-3xl font-black text-slate-900 dark:text-white focus:ring-0 w-full tracking-tighter" value={swapAmount} onChange={e => setSwapAmount(e.target.value)} />
              <div className="flex items-center gap-2 bg-white dark:bg-slate-800 py-1.5 px-3 rounded-xl border border-slate-200 dark:border-white/10 shadow-sm">
                 <img src={assetIcons[fromAsset]} className="size-4 object-contain rounded-full" alt="" />
                 <select value={fromAsset} onChange={e => setFromAsset(e.target.value)} className="bg-transparent border-none text-slate-900 dark:text-white text-[10px] font-black uppercase p-0 outline-none">
                    {Object.keys(assetIcons).map(a => <option key={a} value={a}>{a}</option>)}
                 </select>
              </div>
            </div>
            <div className="flex justify-between px-2">
               <p className="text-[8px] font-black text-slate-400 uppercase">Service Fee (0.9%)</p>
               <p className="text-[8px] font-black text-primary uppercase">+{commission.toFixed(2)} {fromAsset}</p>
            </div>
          </div>

          <div className="flex justify-center -my-8 relative z-20">
            <button onClick={() => {const t = fromAsset; setFromAsset(toAsset); setToAsset(t);}} className="size-12 rounded-2xl bg-primary text-white border-4 border-white dark:border-app-card-dark shadow-lg flex items-center justify-center active:scale-90 transition-all">
              <span className="material-symbols-outlined font-black">swap_vert</span>
            </button>
          </div>

          <div className="space-y-3 pt-2">
            <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest px-2">Recibir (Est.)</label>
            <div className="flex items-center gap-3 bg-slate-50 dark:bg-slate-950 p-4 rounded-2xl border border-slate-200 dark:border-white/5 shadow-inner">
              <div className="text-3xl font-black text-slate-900 dark:text-white w-full tracking-tighter truncate leading-none">{receivedNet}</div>
              <div className="flex items-center gap-2 bg-white dark:bg-slate-800 py-1.5 px-3 rounded-xl border border-slate-200 dark:border-white/10 shadow-sm">
                 <img src={assetIcons[toAsset]} className="size-4 object-contain rounded-full" alt="" />
                 <select value={toAsset} onChange={e => setToAsset(e.target.value)} className="bg-transparent border-none text-slate-900 dark:text-white text-[10px] font-black uppercase p-0 outline-none">
                    {Object.keys(assetIcons).map(a => <option key={a} value={a}>{a}</option>)}
                 </select>
              </div>
            </div>
          </div>

          <button onClick={() => navigate('/confirm', { state: { amount: parseFloat(swapAmount), asset: fromAsset, commission: commission, total: parseFloat(swapAmount) + commission, targetAsset: toAsset, receivedAmount: receivedNet, rate: calculatedRate, recipient: { name: 'Exchange Node', account: 'Automated Swap', phone: 'SYSTEM' } } })} className="w-full py-5 bg-primary text-white rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] shadow-lg active:scale-95 transition-all">Ejecutar Cambio</button>
        </section>
      </div>
    </Layout>
  );
};

export default Exchange;
