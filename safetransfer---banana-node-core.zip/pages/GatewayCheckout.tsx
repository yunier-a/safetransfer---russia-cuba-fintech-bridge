
import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { supabase } from '../services/supabase';

const GatewayCheckout: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [isProcessing, setIsProcessing] = useState(false);
  const [sessionData, setSessionData] = useState<{amount: number, currency: string, gateway: string} | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Extraer datos de la URL como fail-safe (Protocolo de Respaldo)
  const sessionId = searchParams.get('sessionId');
  const urlGateway = searchParams.get('gateway') || 'MASTER_NODE';
  const urlAmount = parseFloat(searchParams.get('amount') || '0');
  const urlCurrency = searchParams.get('currency') || 'USD';
  const requireProof = searchParams.get('requireProof') === 'true';

  useEffect(() => {
    const syncNode = async () => {
      setIsLoading(true);
      
      // Intentar recuperar de DB para auditoría
      try {
        const { data } = await supabase
          .from('payment_sessions')
          .select('*')
          .eq('session_id', sessionId)
          .maybeSingle();
        
        if (data) {
          setSessionData({
            amount: Number(data.amount),
            currency: data.currency,
            gateway: data.gateway
          });
        } else {
          // Si falla la DB, usamos el Fallback de URL para no detener al usuario
          setSessionData({
            amount: urlAmount,
            currency: urlCurrency,
            gateway: urlGateway
          });
        }
      } catch (e) {
        // Fallback inmediato en caso de error de red
        setSessionData({
          amount: urlAmount,
          currency: urlCurrency,
          gateway: urlGateway
        });
      } finally {
        // Simular tiempo de handshake bancario para estética
        setTimeout(() => setIsLoading(false), 1200);
      }
    };

    syncNode();
  }, [sessionId, urlAmount, urlCurrency, urlGateway]);

  const handlePay = async () => {
    if (!sessionData) return;
    setIsProcessing(true);
    
    try {
      // Latencia de procesamiento del Master Node
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      if (requireProof) {
        // Redirigir al Paso 4 para subir captura de pantalla
        navigate(`/deposit?status=success&requireProof=true&amount=${sessionData.amount}&sessionId=${sessionId}`);
        return;
      }

      const { data: { session: authSession } } = await supabase.auth.getSession();
      
      // Intentar registrar la transacción (Fondo de Red)
      if (authSession) {
        await supabase.from('transactions').insert({
          user_id: authSession.user.id,
          recipient: `Depósito via ${sessionData.gateway}`,
          amount: sessionData.amount.toFixed(2),
          currency: sessionData.currency,
          type: 'Deposit',
          status: 'SUCCESS',
          memo: `Sincronización Exitosa. Ref: ${sessionId}`,
          node_id: `GATEWAY_${sessionData.gateway}`
        });
      }

      navigate('/success', { 
        state: { 
          recipient: `${sessionData.gateway} Secure Vault`,
          amount: sessionData.amount.toFixed(2),
          currency: sessionData.currency,
          type: `Instant Deposit`,
          memo: `Protocolo de liquidación finalizado correctamente.` 
        } 
      });

    } catch (e: any) {
      alert("Error de Red: El nodo no respondió. Intente de nuevo.");
      setIsProcessing(false);
    }
  };

  if (isLoading) {
    return (
      <div className="h-screen flex flex-col items-center justify-center bg-slate-950 space-y-6">
        <div className="relative">
          <div className="size-20 border-4 border-primary/10 border-t-primary rounded-full animate-spin"></div>
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="material-symbols-outlined text-primary animate-pulse">lock</span>
          </div>
        </div>
        <div className="text-center">
          <p className="text-[10px] font-black text-white uppercase tracking-[0.4em]">Sincronizando con Nodo Seguro</p>
          <p className="text-[8px] font-black text-slate-600 uppercase tracking-widest mt-1 italic">Estableciendo Handshake...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen bg-slate-950 flex flex-col items-center justify-center p-6 font-display overflow-hidden">
        {/* Fondo decorativo de red */}
        <div className="absolute inset-0 opacity-10 pointer-events-none">
           <div className="absolute top-[-10%] left-[-10%] size-96 bg-primary rounded-full blur-[120px]"></div>
           <div className="absolute bottom-[-10%] right-[-10%] size-96 bg-blue-900 rounded-full blur-[120px]"></div>
        </div>

        <div className={`w-full max-w-[420px] rounded-[4rem] border border-white/10 p-10 space-y-12 shadow-2xl relative z-10 bg-slate-900/40 backdrop-blur-2xl animate-in zoom-in duration-700`}>
           <div className="absolute top-0 right-0 p-10 opacity-5">
              <span className="material-symbols-outlined text-[180px]">verified_user</span>
           </div>
           
           <div className="text-center space-y-4">
              <div className="size-20 bg-primary/20 rounded-[2rem] flex items-center justify-center mx-auto border border-primary/30 shadow-inner">
                 <img 
                    src={
                        sessionData?.gateway === 'GPAY' ? 'https://img.icons8.com/color/96/google-pay.png' : 
                        sessionData?.gateway === 'DEBIT_CARD' ? 'https://img.icons8.com/fluency/96/bank-card-back_side.png' : 
                        'https://img.icons8.com/fluency/96/shield.png'
                    } 
                    className="size-12 object-contain" 
                    alt="Gateway" 
                 />
              </div>
              <div>
                <p className="text-slate-500 text-[10px] font-black uppercase tracking-[0.4em]">Pasarela de Liquidación</p>
                <h1 className="text-2xl font-black text-white mt-1 uppercase italic tracking-widest">
                    {sessionData?.gateway === 'GPAY' ? 'GOOGLE PAY' : sessionData?.gateway === 'DEBIT_CARD' ? 'TARJETA DÉBITO' : 'MASTER NODE'}
                </h1>
              </div>
           </div>

           <div className="bg-black/40 p-10 rounded-[3rem] border border-white/5 text-center shadow-inner relative overflow-hidden group">
              <div className="absolute inset-0 bg-primary/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
              <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest mb-2">Monto a Autorizar</p>
              <h2 className="text-6xl font-black text-white tracking-tighter">
                {sessionData?.amount.toFixed(2)} <span className="text-xl text-primary font-bold">{sessionData?.currency}</span>
              </h2>
           </div>

           <div className="space-y-4">
             <button 
               onClick={handlePay}
               disabled={isProcessing}
               className={`w-full py-8 rounded-[2.5rem] text-white font-black text-base uppercase tracking-[0.3em] transition-all shadow-[0_20px_60px_-15px_rgba(19,109,236,0.5)] active:scale-95 flex items-center justify-center gap-4 bg-primary hover:bg-blue-600`}
             >
               {isProcessing ? (
                <span className="size-7 border-4 border-white/30 border-t-white rounded-full animate-spin"></span>
               ) : (
                 <>Autorizar Pago <span className="material-symbols-outlined font-black text-2xl">bolt</span></>
               )}
             </button>
             <button 
               onClick={() => navigate('/deposit')} 
               disabled={isProcessing}
               className="w-full text-slate-600 font-black text-[10px] uppercase tracking-widest hover:text-white transition-colors py-2"
             >
               Cancelar Protocolo
             </button>
           </div>
           
           <div className="text-center pt-4 border-t border-white/5">
              <p className="text-[8px] text-slate-800 font-black uppercase tracking-[0.4em]">SafeTransfer Node Bridge v5.8 • Conexión Cifrada</p>
           </div>
        </div>
    </div>
  );
};

export default GatewayCheckout;
