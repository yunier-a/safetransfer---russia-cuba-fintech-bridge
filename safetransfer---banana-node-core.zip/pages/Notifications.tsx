
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Layout } from '../components/Layout';
import { NotificationService } from '../services/notificationService';
import { AppNotification } from '../types';

const Notifications: React.FC = () => {
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadNotifications();
  }, []);

  const loadNotifications = async () => {
    setIsLoading(true);
    const data = await NotificationService.getMyNotifications();
    setNotifications(data);
    setIsLoading(false);
  };

  const handleRead = async (id: string) => {
    await NotificationService.markAsRead(id);
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const getTypeIcon = (type: AppNotification['type']) => {
    switch(type) {
      case 'DEPOSIT': return 'add_circle';
      case 'TRANSFER': return 'send';
      case 'RECHARGE': return 'bolt';
      default: return 'info';
    }
  };

  const getStatusColor = (status: AppNotification['status']) => {
    switch(status) {
      case 'SUCCESS': return 'text-green-500 bg-green-500/10';
      case 'WARNING': return 'text-amber-500 bg-amber-500/10';
      default: return 'text-primary bg-primary/10';
    }
  };

  return (
    <Layout hideNav>
      <header className="p-6 pt-10 border-b border-slate-800 flex justify-between items-center bg-background-dark/95 backdrop-blur-md sticky top-0 z-50">
        <button onClick={() => navigate(-1)} className="size-10 flex items-center justify-center rounded-full hover:bg-slate-800 transition-colors">
          <span className="material-symbols-outlined text-white">arrow_back_ios_new</span>
        </button>
        <div className="text-center">
          <h2 className="text-lg font-black text-white uppercase tracking-tighter">Security Alerts</h2>
          <p className="text-[9px] font-black text-primary uppercase tracking-widest">Protocol Audit Trail</p>
        </div>
        <button onClick={loadNotifications} className="size-10 flex items-center justify-center rounded-xl bg-slate-800 text-slate-400">
          <span className={`material-symbols-outlined ${isLoading ? 'animate-spin' : ''}`}>sync</span>
        </button>
      </header>

      <main className="p-4 space-y-4 pb-24">
        {notifications.length === 0 && !isLoading ? (
          <div className="py-20 text-center opacity-30">
            <span className="material-symbols-outlined text-6xl mb-4">notifications_off</span>
            <p className="text-xs font-black uppercase tracking-widest">No signals detected</p>
          </div>
        ) : (
          notifications.map(n => (
            <div 
              key={n.id} 
              onClick={() => handleRead(n.id)}
              className={`bg-card-dark border rounded-3xl p-5 transition-all relative overflow-hidden group ${n.read ? 'border-slate-800/50' : 'border-primary/30 shadow-lg shadow-primary/5'}`}
            >
              {!n.read && <div className="absolute top-4 right-4 size-2 bg-primary rounded-full animate-pulse"></div>}
              <div className="flex gap-4">
                <div className={`size-12 rounded-2xl flex items-center justify-center shrink-0 border border-white/5 ${getStatusColor(n.status)}`}>
                  <span className="material-symbols-outlined font-black">{getTypeIcon(n.type)}</span>
                </div>
                <div className="flex-1 space-y-1">
                  <div className="flex justify-between items-start">
                    <h4 className={`text-xs font-black uppercase tracking-tight ${n.read ? 'text-slate-400' : 'text-white'}`}>{n.title}</h4>
                    <span className="text-[9px] font-black text-slate-600 uppercase">{n.timestamp}</span>
                  </div>
                  <p className={`text-[11px] leading-relaxed ${n.read ? 'text-slate-600' : 'text-slate-400 font-medium'}`}>{n.message}</p>
                </div>
              </div>
              <div className="mt-4 pt-3 border-t border-white/5 flex justify-between items-center">
                 <span className="text-[8px] font-black text-slate-700 uppercase tracking-widest">Secure Link Verification: OK</span>
                 {n.type === 'TRANSFER' && <button className="text-[9px] font-black text-primary uppercase">View Tx Hash</button>}
              </div>
            </div>
          ))
        )}
      </main>
    </Layout>
  );
};

export default Notifications;
