
import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Layout } from '../components/Layout';
import { Message } from '../types';
import { getBotResponse, translateFinancialText } from '../services/geminiService';
import { supabase } from '../services/supabase';
import { AudioService } from '../services/audioService';

const BANANA_AGENT_IMG = "https://files.oaiusercontent.com/file-YhYmX9vFpBvY6X9mYhYmX9vF?se=2024-10-25T12%3A00%3A00Z&sp=r&sv=2024-08-04&sr=b&rscc=max-age%3D604800%2C%20immutable%2C%20private&rscd=attachment%3B%20filename%3Dbanana_agent.png&sig=generated_signature_placeholder";

export const BananaAvatar: React.FC<{ size?: string, glow?: boolean }> = ({ size = "size-10", glow = true }) => {
  const [hasError, setHasError] = useState(false);
  
  return (
    <div className={`${size} rounded-2xl overflow-hidden bg-slate-900 border border-white/10 flex items-center justify-center shrink-0 shadow-lg ${glow ? 'glow-banana' : ''}`}>
      {!hasError ? (
        <img 
          src={BANANA_AGENT_IMG} 
          className="size-full object-cover" 
          onError={() => setHasError(true)} 
          alt="Agente" 
        />
      ) : (
        <span className="text-2xl">🍌</span>
      )}
    </div>
  );
};

const BotChat: React.FC = () => {
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [messages, setMessages] = useState<Message[]>([
    { id: '1', type: 'bot', text: '¡Hola! Soy el Agente Banana. Estoy listo para procesar tus remesas y optimizar tu arbitraje entre Rusia y Cuba. ¿Qué operación autorizamos hoy?', time: 'NODE_READY' }
  ]);
  const [input, setInput] = useState('');
  const [selectedFile, setSelectedFile] = useState<{ data: string, mimeType: string, previewUrl: string, name: string } | null>(null);
  const [isThinking, setIsThinking] = useState(false);
  const [userData, setUserData] = useState<any>(null);
  const [translatingId, setTranslatingId] = useState<string | null>(null);
  const [commentingId, setCommentingId] = useState<string | null>(null);
  const [commentInput, setCommentInput] = useState('');
  
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollToBottom();
    fetchUserContext();
  }, [messages, isThinking]);

  const scrollToBottom = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({
        top: scrollRef.current.scrollHeight,
        behavior: 'smooth'
      });
    }
  };

  const fetchUserContext = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (session) {
      const { data: balances } = await supabase.from('wallet_balances').select('*').eq('user_id', session.user.id);
      const { data: txs } = await supabase.from('transactions').select('*').eq('user_id', session.user.id).order('created_at', { ascending: false }).limit(5);
      setUserData({ balances, transactions: txs });
    }
  };

  const handleTranslate = async (id: string, text: string) => {
    if (translatingId) return;
    AudioService.playClick();
    setTranslatingId(id);
    try {
      const translated = await translateFinancialText(text, 'ES');
      setMessages(prev => prev.map(m => 
        m.id === id ? { ...m, text: translated, isTranslated: true } : m
      ));
    } catch (error) {
      console.error("Translation error:", error);
    } finally {
      setTranslatingId(null);
    }
  };

  const handleSaveComment = (id: string) => {
    AudioService.playClick();
    if (!commentInput.trim()) {
      setCommentingId(null);
      return;
    }
    setMessages(prev => prev.map(m => 
      m.id === id ? { ...m, comment: commentInput } : m
    ));
    setCommentInput('');
    setCommentingId(null);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    AudioService.playClick();
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64 = (reader.result as string).split(',')[1];
      setSelectedFile({
        data: base64,
        mimeType: file.type,
        previewUrl: URL.createObjectURL(file),
        name: file.name
      });
    };
    reader.readAsDataURL(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const clearSelectedFile = () => {
    if (selectedFile?.previewUrl) URL.revokeObjectURL(selectedFile.previewUrl);
    setSelectedFile(null);
  };

  const handleSendText = async (customPrompt?: string) => {
    const textToSend = customPrompt || input;
    if ((!textToSend.trim() && !selectedFile) || isThinking) return;
    
    // Sonido de mensaje enviado
    AudioService.playMessageSent();

    const userMsg: Message = { 
      id: Date.now().toString(), 
      type: 'user', 
      text: textToSend || (selectedFile ? `Analizar: ${selectedFile.name}` : ""), 
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) 
    };
    
    setMessages(prev => [...prev, userMsg]);
    const currentFile = selectedFile;
    setInput('');
    clearSelectedFile();
    setIsThinking(true);

    const response = await getBotResponse(textToSend, userData, currentFile ? { data: currentFile.data, mimeType: currentFile.mimeType } : undefined);
    
    // Sonido de respuesta del bot
    AudioService.playNotification();

    setMessages(prev => [...prev, { 
      id: Date.now().toString(), 
      type: 'bot', 
      text: response.text, 
      time: 'AGENT_NODE', 
      groundingLinks: response.groundingChunks?.filter((c: any) => c.web).map((c: any) => ({ title: c.web.title, uri: c.web.uri })) 
    }]);
    setIsThinking(false);
  };

  return (
    <Layout hideNav>
      <header className="flex items-center glass-header p-6 pt-10 sticky top-0 z-50">
        <button onClick={() => { AudioService.playClick(); navigate(-1); }} className="size-11 flex items-center justify-center rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-primary transition-all active:scale-90 mr-4">
          <span className="material-symbols-outlined text-[20px]">arrow_back_ios_new</span>
        </button>
        <div className="flex items-center gap-4 flex-1">
          <BananaAvatar size="size-14" />
          <div>
            <h2 className="text-slate-900 dark:text-white text-base font-black uppercase tracking-tighter italic">Agente Banana</h2>
            <div className="flex items-center gap-2">
               <span className="text-primary text-[8px] font-black uppercase tracking-[0.2em] animate-pulse">SafeNeural Active</span>
            </div>
          </div>
        </div>
      </header>

      <div className="p-6 space-y-8 flex-1 overflow-y-auto hide-scrollbar pb-72" ref={scrollRef}>
        {messages.map((msg) => (
          <div key={msg.id} className={`flex items-end gap-3 ${msg.type === 'user' ? 'flex-row-reverse' : 'flex-row'} animate-in slide-in-from-bottom-2`}>
            {msg.type === 'bot' && <BananaAvatar size="size-9" />}
            <div className={`max-w-[85%] space-y-2 ${msg.type === 'user' ? 'items-end' : 'items-start'}`}>
              <div className={`p-5 rounded-[2.2rem] text-[13px] leading-relaxed shadow-xl transition-all group relative ${
                msg.type === 'user' ? 'bg-primary text-white rounded-br-none shadow-primary/20' : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-white/5 rounded-bl-none'
              }`}>
                {msg.text}

                {msg.comment && (
                  <div className="mt-4 pt-3 border-t border-slate-100 dark:border-white/10 flex items-start gap-2">
                    <span className="material-symbols-outlined text-primary text-[14px] mt-0.5">sticky_note_2</span>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 font-bold italic">"{msg.comment}"</p>
                  </div>
                )}
                
                {msg.type === 'bot' && (
                  <div className="absolute -right-3 -top-3 flex items-center gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button 
                      onClick={() => { AudioService.playClick(); setCommentingId(msg.id); setCommentInput(msg.comment || ''); }}
                      className="size-8 rounded-full border border-slate-200 dark:border-white/10 flex items-center justify-center bg-white dark:bg-slate-800 text-slate-400 hover:text-primary transition-all shadow-lg active:scale-90"
                      title="Añadir Nota"
                    >
                      <span className="material-symbols-outlined text-[16px]">add_comment</span>
                    </button>
                    <button 
                      onClick={() => handleTranslate(msg.id, msg.text)}
                      disabled={translatingId === msg.id}
                      className={`size-8 rounded-full border border-slate-200 dark:border-white/10 flex items-center justify-center transition-all shadow-lg active:scale-90 ${translatingId === msg.id ? 'bg-slate-200 dark:bg-slate-700 animate-pulse' : 'bg-white dark:bg-slate-800 text-slate-400 hover:text-primary'}`}
                      title="Traducir"
                    >
                      {translatingId === msg.id ? (
                        <span className="size-4 border-2 border-primary/30 border-t-primary rounded-full animate-spin"></span>
                      ) : (
                        <span className="material-symbols-outlined text-[16px]">translate</span>
                      )}
                    </button>
                  </div>
                )}
              </div>

              {commentingId === msg.id && (
                <div className="w-full bg-slate-50 dark:bg-slate-950 border border-primary/20 p-3 rounded-2xl space-y-2 animate-in slide-in-from-top-1">
                   <textarea 
                    autoFocus
                    className="w-full bg-transparent border-none p-0 text-[11px] text-slate-800 dark:text-slate-300 focus:ring-0 resize-none font-medium italic"
                    placeholder="Escribe una nota para este mensaje..."
                    value={commentInput}
                    onChange={(e) => setCommentInput(e.target.value)}
                   />
                   <div className="flex justify-end gap-2">
                      <button onClick={() => { AudioService.playClick(); setCommentingId(null); }} className="text-[9px] font-black text-slate-500 uppercase tracking-widest px-2 py-1">Cancelar</button>
                      <button onClick={() => handleSaveComment(msg.id)} className="bg-primary text-white text-[9px] font-black uppercase tracking-widest px-3 py-1 rounded-lg shadow-lg shadow-primary/20">Guardar Nota</button>
                   </div>
                </div>
              )}

              <div className={`px-3 ${msg.type === 'user' ? 'text-right' : 'text-left'}`}>
                <p className="text-[8px] font-black uppercase tracking-widest text-slate-500 font-mono">{msg.time}</p>
              </div>
            </div>
          </div>
        ))}
        {isThinking && (
          <div className="flex items-end gap-3 justify-start animate-in fade-in duration-500">
             <BananaAvatar size="size-9" />
             <div className="bg-white dark:bg-slate-900 border border-primary/20 p-6 rounded-[2.5rem] rounded-bl-none flex items-center gap-4 shadow-2xl">
                <div className="flex gap-1">
                   <div className="size-1.5 bg-primary rounded-full animate-bounce"></div>
                   <div className="size-1.5 bg-primary rounded-full animate-bounce [animation-delay:0.2s]"></div>
                   <div className="size-1.5 bg-primary rounded-full animate-bounce [animation-delay:0.4s]"></div>
                </div>
                <p className="text-[9px] font-black text-primary uppercase tracking-[0.2em]">Escaneando Nodo...</p>
             </div>
          </div>
        )}
      </div>

      <footer className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[430px] p-6 bg-white/95 dark:bg-app-bg-dark/95 backdrop-blur-3xl border-t border-slate-200 dark:border-white/5 z-50 space-y-4">
        <div className="flex gap-3">
          <button onClick={() => { AudioService.playClick(); fileInputRef.current?.click(); }} className="size-14 rounded-2xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-white/5 flex items-center justify-center text-slate-400 hover:text-primary transition-all active:scale-90 shrink-0">
            <span className="material-symbols-outlined text-2xl">add_a_photo</span>
          </button>
          <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept="image/*" />

          <div className="flex-1 relative flex items-center">
            <input className="w-full h-14 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl px-5 pr-14 text-sm text-slate-800 dark:text-white outline-none focus:ring-2 focus:ring-primary/40 transition-all placeholder:text-slate-500 font-bold" placeholder="Consultar Agente..." value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSendText()} />
            <button onClick={() => handleSendText()} disabled={(!input.trim() && !selectedFile) || isThinking} className="absolute right-2 size-11 bg-primary text-white rounded-xl flex items-center justify-center transition-all active:scale-90 disabled:opacity-30 shadow-xl shadow-primary/30">
              <span className="material-symbols-outlined font-black">send</span>
            </button>
          </div>
        </div>
      </footer>
    </Layout>
  );
};

export default BotChat;
