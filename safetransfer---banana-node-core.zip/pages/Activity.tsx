
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Layout } from '../components/Layout';
import { Transaction } from '../types';
import { supabase } from '../services/supabase';

type SearchScope = 'all' | 'recipient' | 'memo';

const Activity: React.FC = () => {
  const navigate = useNavigate();
  const searchInputRef = useRef<HTMLInputElement>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [selectedTypes, setSelectedTypes] = useState<string[]>([]);
  const [statusFilter, setStatusFilter] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [appliedSearchTerm, setAppliedSearchTerm] = useState('');
  const [searchScope, setSearchScope] = useState<SearchScope>('all');
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const filterOptions = [
    { id: 'Remittance', label: 'Remesas', icon: 'payments', color: 'bg-green-500' },
    { id: 'Swap', label: 'Cambios', icon: 'swap_horiz', color: 'bg-purple-500' },
    { id: 'Recharge', label: 'Recargas', icon: 'bolt', color: 'bg-blue-400' },
    { id: 'Deposit', label: 'Depósitos', icon: 'account_balance_wallet', color: 'bg-primary' }
  ];

  useEffect(() => {
    fetchTransactions();
  }, []);

  const fetchTransactions = async () => {
    setIsLoading(true);
    const { data, error } = await supabase
      .from('transactions')
      .select('*')
      .order('created_at', { ascending: false });

    if (!error && data) {
      const formatted = data.map((tx: any) => ({
        ...tx,
        date: new Date(tx.created_at).toLocaleDateString('es-ES', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })
      }));
      setTransactions(formatted);
    }
    setIsLoading(false);
  };

  const stats = useMemo(() => {
    const total = transactions.length;
    const volume = transactions.reduce((acc, curr) => acc + parseFloat(curr.amount.toString()), 0);
    return { total, volume };
  }, [transactions]);

  const handleTypeToggle = (type: string) => {
    if (type === 'All') {
      setSelectedTypes([]);
      return;
    }
    setSelectedTypes(prev => prev.includes(type) ? prev.filter(t => t !== type) : [...prev, type]);
  };

  const filteredTransactions = useMemo(() => {
    return transactions.filter(tx => {
      const txDate = new Date(tx.created_at || '');
      const matchType = selectedTypes.length === 0 || selectedTypes.includes(tx.type);
      const matchStatus = statusFilter === 'All' || tx.status === statusFilter;
      const matchStartDate = !startDate || txDate >= new Date(startDate);
      const matchEndDate = !endDate || txDate <= new Date(endDate + 'T23:59:59');
      const searchLower = appliedSearchTerm.toLowerCase();
      
      let matchSearch = true;
      if (appliedSearchTerm) {
        const recipientMatch = tx.recipient.toLowerCase().includes(searchLower);
        const memoMatch = tx.memo?.toLowerCase().includes(searchLower) || false;
        if (searchScope === 'recipient') matchSearch = recipientMatch;
        else if (searchScope === 'memo') matchSearch = memoMatch;
        else matchSearch = recipientMatch || memoMatch;
      }

      return matchType && matchStatus && matchSearch && matchStartDate && matchEndDate;
    });
  }, [selectedTypes, statusFilter, appliedSearchTerm, searchScope, transactions, startDate, endDate]);

  const getCategoryMeta = (type: string) => {
    switch (type) {
      case 'Remittance': return { icon: 'payments', color: 'text-green-500', bg: 'bg-green-500/10', label: 'Remesa' };
      case 'Swap': return { icon: 'swap_horiz', color: 'text-purple-400', bg: 'bg-purple-400/10', label: 'Intercambio' };
      case 'Recharge': return { icon: 'bolt', color: 'text-blue-400', bg: 'bg-blue-400/10', label: 'Recarga' };
      case 'Deposit': return { icon: 'account_balance_wallet', color: 'text-primary', bg: 'bg-primary/10', label: 'Depósito' };
      default: return { icon: 'history', color: 'text-slate-500', bg: 'bg-slate-500/10', label: type };
    }
  };

  return (
    <Layout>
      <header className="p-6 pt-10 bg-background-dark/95 sticky top-0 z-50 backdrop-blur-xl border-b border-slate-800 space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-black text-white uppercase tracking-tighter italic">Actividad</h1>
          <div className="flex items-center gap-2 bg-primary/10 px-4 py-1.5 rounded-full border border-primary/20">
             <span className="size-2 bg-primary rounded-full animate-pulse"></span>
             <span className="text-[10px] font-black text-primary uppercase tracking-widest">En Vivo</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="bg-slate-900 p-4 rounded-2xl border border-white/5">
            <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest mb-1">Volumen Total</p>
            <p className="text-lg font-black text-white tracking-tighter">₽ {stats.volume.toLocaleString()}</p>
          </div>
          <div className="bg-slate-900 p-4 rounded-2xl border border-white/5">
            <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest mb-1">Operaciones</p>
            <p className="text-lg font-black text-white tracking-tighter">{stats.total}</p>
          </div>
        </div>
        
        <div className="space-y-4">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-600">search</span>
              <input 
                ref={searchInputRef}
                type="text" 
                placeholder="Buscar nodo..." 
                className="w-full bg-slate-900 border border-slate-800 rounded-2xl py-3 pl-11 pr-4 text-xs text-white outline-none focus:border-primary transition-all font-bold"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && setAppliedSearchTerm(searchTerm)}
              />
            </div>
            <button onClick={() => setAppliedSearchTerm(searchTerm)} className="bg-primary text-white p-3 rounded-2xl shadow-lg active:scale-95">
              <span className="material-symbols-outlined">filter_list</span>
            </button>
          </div>

          <div className="flex gap-2 overflow-x-auto hide-scrollbar pb-1">
            <button 
              onClick={() => handleTypeToggle('All')}
              className={`px-5 py-2.5 rounded-xl text-[10px] font-black uppercase whitespace-nowrap transition-all border ${selectedTypes.length === 0 ? 'bg-primary border-primary text-white shadow-lg' : 'bg-slate-900 border-slate-800 text-slate-500'}`}
            >
              Todos
            </button>
            {filterOptions.map(opt => (
              <button 
                key={opt.id}
                onClick={() => handleTypeToggle(opt.id)}
                className={`px-5 py-2.5 rounded-xl text-[10px] font-black uppercase whitespace-nowrap transition-all border flex items-center gap-2 ${selectedTypes.includes(opt.id) ? `${opt.color} border-transparent text-white shadow-lg` : 'bg-slate-900 border-slate-800 text-slate-500'}`}
              >
                <span className="material-symbols-outlined text-sm">{opt.icon}</span>
                {opt.label}
              </button>
            ))}
          </div>
        </div>
      </header>
      
      <div className="p-4 space-y-4 pb-32">
        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-20 gap-4 opacity-30">
            <span className="size-10 border-4 border-slate-800 border-t-primary rounded-full animate-spin"></span>
            <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Sincronizando Nodo...</p>
          </div>
        ) : filteredTransactions.length === 0 ? (
          <div className="py-20 text-center space-y-4 opacity-30">
            <span className="material-symbols-outlined text-6xl">history</span>
            <p className="text-xs font-black uppercase tracking-widest">Sin actividad detectada</p>
          </div>
        ) : (
          filteredTransactions.map(tx => {
            const meta = getCategoryMeta(tx.type);
            const isExpanded = expandedId === tx.id;
            return (
              <div key={tx.id} className="bg-card-dark rounded-3xl border border-slate-800 overflow-hidden transition-all hover:border-slate-700 shadow-xl">
                <div className="p-5 flex items-center gap-4" onClick={() => setExpandedId(isExpanded ? null : tx.id)}>
                  <div className={`size-14 rounded-2xl flex items-center justify-center shrink-0 ${meta.bg} border border-white/5`}>
                    <span className={`material-symbols-outlined text-3xl ${meta.color}`}>{meta.icon}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-base font-black truncate text-white uppercase tracking-tight mb-1">{tx.recipient}</p>
                    <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">{tx.date}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-base font-black text-white tracking-tighter">
                      {tx.type === 'Deposit' ? '+' : '-'}{tx.amount} <span className="text-[10px] text-slate-500">{tx.currency}</span>
                    </p>
                    <div className="flex items-center justify-end gap-1.5 mt-1">
                      <span className={`size-1.5 rounded-full ${tx.status === 'SUCCESS' ? 'bg-green-500' : 'bg-amber-500'}`}></span>
                      <p className={`text-[8px] font-black uppercase tracking-widest ${tx.status === 'SUCCESS' ? 'text-green-500' : 'text-amber-500'}`}>{tx.status}</p>
                    </div>
                  </div>
                </div>
                {isExpanded && (
                  <div className="px-5 pb-5 pt-1 animate-in slide-in-from-top-4">
                    <div className="bg-slate-900/50 rounded-2xl p-5 space-y-4 border border-slate-800/50">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest mb-1">Referencia</p>
                          <p className="text-[10px] text-primary font-mono font-black">{tx.hash || 'GEN-TX-ID'}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest mb-1">Protocolo</p>
                          <p className="text-[10px] text-white font-black">{tx.network || 'SafeNode Core'}</p>
                        </div>
                      </div>
                      {tx.memo && (
                        <div className="pt-2 border-t border-slate-800">
                          <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest">Nota</p>
                          <p className="text-[11px] text-slate-400 italic mt-1 leading-relaxed">"{tx.memo}"</p>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </Layout>
  );
};

export default Activity;
