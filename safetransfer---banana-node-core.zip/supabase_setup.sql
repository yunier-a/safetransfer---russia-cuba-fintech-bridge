
-- 1. Tabla de Perfiles (Actualizada)
create table if not exists public.profiles (
  id uuid references auth.users on delete cascade primary key,
  full_name text,
  avatar_url text,
  telegram_handle text,
  two_factor_enabled boolean default false,
  referrer_id uuid references public.profiles(id), -- Nuevo campo para referidos
  updated_at timestamp with time zone default now()
);

alter table public.profiles enable row level security;

create policy "Los usuarios pueden ver su propio perfil" 
  on public.profiles for select using (auth.uid() = id);

create policy "Los usuarios pueden actualizar su propio perfil" 
  on public.profiles for update using (auth.uid() = id);

create policy "Permitir ver perfiles publicos limitados para referidos"
  on public.profiles for select using (true);

-- 2. Tabla de Sesiones de Pago (Sin cambios)
create table if not exists public.payment_sessions (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users on delete cascade not null,
  gateway text not null,
  session_id text not null unique,
  amount numeric not null,
  currency text not null,
  status text default 'PENDING',
  created_at timestamp with time zone default now()
);
-- ... resto del archivo se mantiene igual
