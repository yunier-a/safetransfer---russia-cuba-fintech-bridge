
import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Layout } from '../components/Layout';
import { supabase } from '../services/supabase';
import { translateFinancialText } from '../services/geminiService';

interface VaultItem {
  id: string;
  file_name: string;
  file_type: string;
  file_path: string;
  expiry_date: string;
  uploaded_at: string;
  translation?: string;
}

interface UploadTask {
  id: string;
  name: string;
  progress: number;
  status: 'reading' | 'syncing' | 'success' | 'error';
  errorMessage?: string;
}

const Vault: React.FC = () => {
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [activeUploads, setActiveUploads] = useState<UploadTask[]>([]);
  const [vaultItems, setVaultItems] = useState<VaultItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [translatingId, setTranslatingId] = useState<string | null>(null);

  // Withdrawal States
  const [itemToWithdraw, setItemToWithdraw] = useState<VaultItem | null>(null);
  const [isWithdrawing, setIsWithdrawing] = useState(false);
  const [withdrawalProgress, setWithdrawalProgress] = useState(0);

  useEffect(() => {
    fetchVaultItems();
  }, []);

  const fetchVaultItems = async () => {
    setIsLoading(true);
    const { data: { session } } = await supabase.auth.getSession();
    if (session) {
      const { data, error } = await supabase
        .from('security_vault')
        .select('*')
        .eq('user_id', session.user.id)
        .order('uploaded_at', { ascending: false });

      if (!error && data) setVaultItems(data);
    }
    setIsLoading(false);
  };

  const handleTranslateItem = async (item: VaultItem) => {
    setTranslatingId(item.id);
    // Para imágenes/recibos, Gemini puede "leer" y traducir el contexto. 
    // Por simplicidad en este mockup, traducimos el nombre y metadatos simulando un OCR
    const contextText = `Documento bancario: ${item.file_name}. Tipo: ${item.file_type}.`;
    const translation = await translateFinancialText(contextText, 'ES');
    
    setVaultItems(prev => prev.map(i => i.id === item.id ? { ...i, translation } : i));
    setTranslatingId(null);
  };

  const updateUploadTask = (id: string, updates: Partial<UploadTask>) => {
    setActiveUploads(prev => prev.map(task => task.id === id ? { ...task, ...updates } : task));
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      alert("Se requiere una identidad activa para acceder a la bóveda.");
      return;
    }

    const fileList = Array.from(files) as File[];
    
    for (const file of fileList) {
      const taskId = Math.random().toString(36).substring(7);
      const newTask: UploadTask = {
        id: taskId,
        name: file.name,
        progress: 0,
        status: 'reading'
      };

      setActiveUploads(prev => [newTask, ...prev]);

      const reader = new FileReader();
      
      reader.onprogress = (e) => {
        if (e.lengthComputable) {
          const progress = Math.round((e.loaded / e.total) * 50);
          updateUploadTask(taskId, { progress });
        }
      };

      reader.onloadend = async () => {
        try {
          updateUploadTask(taskId, { status: 'syncing', progress: 60 });
          
          const base64data = reader.result as string;
          const expiry = new Date();
          expiry.setDate(expiry.getDate() + 7);
          const isImage = file.type.startsWith('image');

          const { error } = await supabase.from('security_vault').insert({
            user_id: session.user.id,
            file_name: file.name,
            file_type: isImage ? 'image' : 'doc',
            file_path: isImage ? base64data : 'doc_placeholder',
            expiry_date: expiry.toISOString()
          });

          if (error) throw error;

          updateUploadTask(taskId, { status: 'success', progress: 100 });
          fetchVaultItems();
          
          setTimeout(() => {
            setActiveUploads(prev => prev.filter(t => t.id !== taskId));
          }, 3000);

        } catch (err: any) {
          console.error("Upload error:", err);
          updateUploadTask(taskId, { 
            status: 'error', 
            errorMessage: err.message || "Error de sincronización con el nodo." 
          });
        }
      };

      reader.readAsDataURL(file);
    }
    
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const executeWithdrawal = async () => {
    if (!itemToWithdraw) return;
    setIsWithdrawing(true);
    
    // Simulate Decryption/Retrieval Tunneling
    for (let i = 0; i <= 100; i += 10) {
      setWithdrawalProgress(i);
      await new Promise(r => setTimeout(r, 150));
    }

    const { error } = await supabase.from('security_vault').delete().eq('id', itemToWithdraw.id);
    
    if (!error) {
      setVaultItems(prev => prev.filter(i => i.id !== itemToWithdraw.id));
      setItemToWithdraw(null);
    } else {
      alert("Fallo en el protocolo de retiro.");
    }
    
    setIsWithdrawing(false);
    setWithdrawalProgress(0);
  };

  const cancelUpload = (id: string) => {
    setActiveUploads(prev => prev.filter(t => t.id !== id));
  };

  return (
    <Layout hideNav>
      <header className="sticky top-0 z-40 bg-background-dark/90 backdrop-blur-xl border-b border-slate-800 p-6 flex items-center justify-between">
        <button onClick={() => navigate('/')} className="size-11 flex items-center justify-center rounded-2xl bg-slate-800/50 hover:bg-slate-800 transition-all active:scale-90">
          <span className="material-symbols-outlined text-white text-[20px]">arrow_back_ios_new</span>
        </button>
        <div className="text-center">
          <h2 className="text-xl font-black text-white uppercase tracking-tighter italic">Bóveda de Seguridad</h2>
          <p className="text-[10px] text-primary font-black uppercase tracking-widest mt-0.5 flex items-center justify-center gap-1.5">
            <span className="size-1 bg-primary rounded-full animate-pulse"></span>
            Cifrado Cuántico Activo
          </p>
        </div>
        <div className="size-11"></div>
      </header>
      
      <div className="p-6 space-y-8 pb-32">
        {/* Banner de Carga Principal */}
        <section>
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="w-full bg-gradient-to-br from-primary via-blue-700 to-blue-900 p-10 rounded-[2.5rem] flex flex-col items-center justify-center gap-5 shadow-2xl relative overflow-hidden group transition-all active:scale-[0.98]"
          >
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white/10 via-transparent to-transparent opacity-50"></div>
            <div className="relative z-10 size-20 rounded-3xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20 group-hover:scale-110 transition-transform">
              <span className="material-symbols-outlined text-white text-4xl font-black">add_moderator</span>
            </div>
            <div className="relative z-10 text-center space-y-2">
               <h3 className="text-white font-black uppercase tracking-widest text-sm">Resguardar Nuevo Objeto</h3>
               <p className="text-white/60 text-[9px] font-black uppercase tracking-[0.2em]">Destrucción Automática en 7 Días</p>
            </div>
          </button>
          <input type="file" ref={fileInputRef} onChange={handleFileUpload} className="hidden" accept="image/*,.pdf,.doc,.docx" multiple />
        </section>

        {/* Active Uploads Queue */}
        {activeUploads.length > 0 && (
          <section className="space-y-4 animate-in slide-in-from-top-4 duration-500">
            <h3 className="text-[10px] font-black text-primary uppercase tracking-[0.2em] px-1 flex items-center gap-2">
              <span className="size-1.5 bg-primary rounded-full animate-ping"></span>
              Sincronización en Curso
            </h3>
            <div className="space-y-3">
              {activeUploads.map(task => (
                <div key={task.id} className="bg-slate-900/50 border border-slate-800 rounded-3xl p-5 space-y-3 relative overflow-hidden">
                  <div className="flex justify-between items-center mb-1">
                    <div className="flex items-center gap-3 min-w-0">
                      <span className={`material-symbols-outlined text-sm ${task.status === 'error' ? 'text-red-500' : 'text-primary'}`}>
                        {task.status === 'error' ? 'error' : task.status === 'success' ? 'check_circle' : 'upload_file'}
                      </span>
                      <p className="text-xs font-black text-white truncate uppercase tracking-tight">{task.name}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className={`text-[9px] font-black uppercase ${task.status === 'error' ? 'text-red-500' : 'text-slate-500'}`}>
                        {task.status === 'reading' ? 'Leyendo...' : task.status === 'syncing' ? 'Sincronizando...' : task.status === 'success' ? 'Completado' : 'Fallo'}
                      </span>
                      {task.status === 'error' && (
                        <button onClick={() => cancelUpload(task.id)} className="size-6 bg-slate-800 rounded-lg flex items-center justify-center text-slate-400">
                          <span className="material-symbols-outlined text-xs">close</span>
                        </button>
                      )}
                    </div>
                  </div>
                  <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                    <div 
                      className={`h-full transition-all duration-500 rounded-full ${task.status === 'error' ? 'bg-red-500' : 'bg-primary shadow-[0_0_10px_#136dec]'}`} 
                      style={{ width: `${task.progress}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        <div className="space-y-6">
          <div className="flex justify-between items-end px-1">
            <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Registros Protegidos</h3>
            <div className="flex items-center gap-2">
              <span className="text-[9px] font-black text-primary uppercase">{vaultItems.length} Objetos</span>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {vaultItems.length === 0 && !isLoading ? (
              <div className="py-20 text-center border-2 border-dashed border-slate-800 rounded-[2.5rem] bg-card-dark/30 flex flex-col items-center justify-center gap-4 opacity-40">
                <span className="material-symbols-outlined text-5xl">inventory_2</span>
                <p className="text-[10px] font-black uppercase tracking-widest">Bóveda Vacía</p>
              </div>
            ) : (
              vaultItems.map(item => (
                <div key={item.id} className="bg-card-dark border border-slate-800 p-4 rounded-[2rem] flex flex-col shadow-xl group hover:border-primary/30 transition-all">
                  <div className="flex items-center justify-between w-full">
                    <div className="flex items-center gap-5 flex-1 min-w-0">
                      <div className="size-16 rounded-2xl bg-slate-900 border border-white/5 flex items-center justify-center overflow-hidden shrink-0 relative shadow-inner">
                        {item.file_type === 'image' && item.file_path !== 'doc_placeholder' ? (
                          <img src={item.file_path} className="size-full object-cover group-hover:scale-110 transition-transform" alt="Preview" />
                        ) : (
                          <span className="material-symbols-outlined text-slate-700 text-3xl">description</span>
                        )}
                      </div>
                      <div className="flex-1 min-w-0 pr-4">
                        <p className="text-sm font-black text-white uppercase truncate tracking-tight">{item.file_name}</p>
                        <div className="mt-1 flex flex-col gap-0.5">
                          <p className="text-[8px] text-red-500 font-black uppercase tracking-widest">
                            Expira en {Math.max(1, Math.ceil((new Date(item.expiry_date).getTime() - Date.now()) / (1000 * 60 * 60 * 24)))} Días
                          </p>
                          <p className="text-[7px] text-slate-500 font-black uppercase tracking-widest flex items-center gap-1">
                            <span className="material-symbols-outlined text-[10px]">event_busy</span>
                            Cierre: {new Date(item.expiry_date).toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric' })}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button 
                        onClick={() => handleTranslateItem(item)}
                        disabled={translatingId === item.id}
                        className="size-10 bg-primary/10 text-primary border border-primary/20 rounded-xl flex items-center justify-center hover:bg-primary/20 transition-all active:scale-95"
                        title="Traducir Resumen"
                      >
                        {translatingId === item.id ? (
                          <span className="size-4 border-2 border-primary/30 border-t-primary rounded-full animate-spin"></span>
                        ) : (
                          <span className="material-symbols-outlined text-sm">translate</span>
                        )}
                      </button>
                      <button 
                        onClick={() => setItemToWithdraw(item)}
                        className="px-4 py-2 bg-slate-800 text-slate-300 border border-white/5 rounded-xl text-[9px] font-black uppercase tracking-widest hover:bg-slate-700 transition-all active:scale-95"
                      >
                        Withdraw
                      </button>
                    </div>
                  </div>
                  
                  {item.translation && (
                    <div className="mt-4 p-4 bg-slate-950/50 border border-primary/10 rounded-2xl animate-in slide-in-from-top-2 duration-300">
                      <p className="text-[8px] font-black text-primary uppercase tracking-widest mb-1 flex items-center gap-1.5">
                        <span className="material-symbols-outlined text-[12px]">auto_awesome</span>
                        Traducción Neuronal:
                      </p>
                      <p className="text-[10px] text-slate-400 leading-relaxed font-medium italic">"{item.translation}"</p>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>

        <div className="bg-primary/5 border border-primary/20 rounded-3xl p-6 flex gap-4 items-start shadow-inner">
           <div className="size-10 rounded-2xl bg-primary/10 flex items-center justify-center text-primary shrink-0">
             <span className="material-symbols-outlined text-xl">verified_user</span>
           </div>
           <div className="space-y-1">
             <h4 className="text-[11px] font-black text-white uppercase tracking-widest">Protocolo de Limpieza</h4>
             <p className="text-[10px] text-slate-500 leading-relaxed font-bold uppercase tracking-tight">
                Todo objeto resguardado en la bóveda es fragmentado criptográficamente y eliminado permanentemente de nuestros nodos tras 168 horas (7 días).
             </p>
           </div>
        </div>
      </div>

      {/* WITHDRAWAL CONFIRMATION MODAL */}
      {itemToWithdraw && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center px-6">
          <div className="absolute inset-0 bg-background-dark/95 backdrop-blur-2xl animate-in fade-in duration-300"></div>
          <div className="relative w-full max-w-[360px] bg-card-dark border border-slate-800 rounded-[3rem] p-10 shadow-[0_50px_100px_rgba(0,0,0,0.6)] space-y-8 animate-in zoom-in duration-500">
            
            <div className="text-center space-y-4">
              <div className={`size-20 rounded-3xl bg-primary/10 flex items-center justify-center mx-auto border border-primary/20 shadow-inner ${isWithdrawing ? 'animate-pulse' : ''}`}>
                 <span className={`material-symbols-outlined text-4xl text-primary ${isWithdrawing ? 'animate-spin' : ''}`}>
                   {isWithdrawing ? 'sync' : 'lock_open'}
                 </span>
              </div>
              <h3 className="text-xl font-black text-white uppercase tracking-tight italic">
                {isWithdrawing ? 'Retirando Objeto...' : 'Autorizar Retiro'}
              </h3>
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest leading-relaxed">
                {isWithdrawing 
                  ? 'Estableciendo túnel de transporte seguro...' 
                  : `¿Confirmar la extracción de "${itemToWithdraw.file_name}" del nodo de seguridad?`}
              </p>
            </div>

            {isWithdrawing && (
              <div className="space-y-3">
                <div className="flex justify-between items-center px-2">
                   <span className="text-[8px] font-black text-primary uppercase tracking-[0.3em]">Neural Tunnel Progress</span>
                   <span className="text-[8px] font-mono text-primary">{withdrawalProgress}%</span>
                </div>
                <div className="h-2 w-full bg-slate-900 rounded-full overflow-hidden border border-white/5">
                   <div 
                    className="h-full bg-primary shadow-[0_0_20px_#136dec] transition-all duration-300"
                    style={{ width: `${withdrawalProgress}%` }}
                   ></div>
                </div>
              </div>
            )}

            {!isWithdrawing && (
              <div className="flex flex-col gap-3">
                <button 
                  onClick={executeWithdrawal}
                  className="w-full py-6 bg-primary text-white rounded-2xl font-black text-[12px] uppercase tracking-[0.25em] shadow-2xl shadow-primary/30 active:scale-95 transition-all flex items-center justify-center gap-3"
                >
                  Confirmar Retiro <span className="material-symbols-outlined text-base">cloud_download</span>
                </button>
                <button 
                  onClick={() => setItemToWithdraw(null)}
                  className="w-full py-4 text-slate-500 font-black text-[10px] uppercase tracking-widest hover:text-white transition-colors"
                >
                  Abortar Protocolo
                </button>
              </div>
            )}

            <div className="pt-4 border-t border-white/5 text-center">
               <p className="text-[8px] text-slate-800 font-black uppercase tracking-[0.4em]">SafeVault Retrieve Protocol v3.0</p>
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
};

export default Vault;
